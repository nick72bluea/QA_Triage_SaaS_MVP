"use client";

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { collection, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import Papa from 'papaparse';
import { db } from '@/lib/firebase';
import { TestRunData, TestStep } from '@/types';
import { useRouter } from 'next/navigation';

export default function PMHomeDashboard() {
  const router = useRouter();
  
  const [isMounted, setIsMounted] = useState(false);
  const [allRuns, setAllRuns] = useState<TestRunData[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [listFilter, setListFilter] = useState<'all' | 'need' | 'active' | 'done'>('all');
  const [toastMsg, setToastMsg] = useState('');
  const [greeting, setGreeting] = useState('Good morning');

  // ==========================================
  // WIZARD STATES
  // ==========================================
  const [wizOpen, setWizOpen] = useState(false);
  const [wizStep, setWizStep] = useState(1);
  const [wizSaved, setWizSaved] = useState(false);
  
  const [wizName, setWizName] = useState('');
  const [wizEnv, setWizEnv] = useState('');
  const [wizCycle, setWizCycle] = useState('');
  
  const [isDragging, setIsDragging] = useState(false);
  const [wizFile, setWizFile] = useState<File | null>(null);
  const [wizHeaders, setWizHeaders] = useState<string[]>([]);
  const [wizRawData, setWizRawData] = useState<any[]>([]);

  const [wizMap, setWizMap] = useState({ action: '', expectedResult: '', area: '', scenario: '', priority: '' });
  const [wizHoverCol, setWizHoverCol] = useState<string | null>(null);
  
  const [wizTesterInput, setWizTesterInput] = useState('');
  const [wizTesters, setWizTesters] = useState<{name: string, color: string}[]>([]);
  
  const [isLaunching, setIsLaunching] = useState(false);
  const confettiContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsMounted(true);
    
    const h = new Date().getHours();
    if (h >= 12 && h < 18) setGreeting('Good afternoon');
    else if (h >= 18) setGreeting('Good evening');

    const unsubscribe = onSnapshot(collection(db, 'testRuns'), (snapshot) => {
      const runsData = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as TestRunData[];
      setAllRuns(runsData);
    });
    return () => unsubscribe();
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(""), 2500);
  };

  // --- DATA AGGREGATION ---
  const projects = useMemo(() => {
    const grouped: Record<string, any> = {};
    allRuns.forEach(run => {
      if (!grouped[run.projectName]) {
        grouped[run.projectName] = {
          name: run.projectName, cycle: run.testCycle || 'N/A', environment: run.environment || 'N/A',
          runs: [], totalSteps: 0, completedSteps: 0,
          createdAt: run.createdAt?.toDate ? run.createdAt.toDate() : new Date(0) 
        };
      }
      grouped[run.projectName].runs.push(run);
      if (grouped[run.projectName].runs.length === 1) {
          grouped[run.projectName].totalSteps = run.steps?.length || 0;
      }
      if (run.testerName !== 'Unassigned') {
          grouped[run.projectName].completedSteps += Object.keys(run.results || {}).length;
      }
    });
    return Object.values(grouped).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }, [allRuns]);

  const activeTestersCount = new Set(allRuns.map(r => r.testerName).filter(n => n !== 'Unassigned')).size;
  const liveNowCount = allRuns.filter(r => r.testerName !== 'Unassigned' && !r.isCompleted && Object.keys(r.results || {}).length > 0).length;
  const uniqueTestersList = useMemo(() => Array.from(new Set(allRuns.map(r => r.testerName).filter(n => n !== 'Unassigned'))), [allRuns]);

  let totalStepsOverall = 0;
  let totalCompletedOverall = 0;
  projects.forEach(p => {
    const activeTesters = p.runs.filter((r: any) => r.testerName !== 'Unassigned').length;
    totalStepsOverall += (p.totalSteps * (activeTesters || 1));
    totalCompletedOverall += p.completedSteps;
  });
  const avgProgress = totalStepsOverall > 0 ? Math.round((totalCompletedOverall / totalStepsOverall) * 100) : 0;

  const processedProjects = projects.map(proj => {
    const activeTesters = proj.runs.filter((r: any) => r.testerName !== 'Unassigned');
    const testerCount = activeTesters.length;
    const totalPossibleSteps = proj.totalSteps * testerCount;
    const pct = totalPossibleSteps > 0 ? Math.round((proj.completedSteps / totalPossibleSteps) * 100) : 0;
    
    let status: 'need' | 'active' | 'done' = 'active';
    if (testerCount === 0) status = 'need';
    else if (pct === 100) status = 'done';
    
    const isMatch = proj.name.toLowerCase().includes(searchQuery.toLowerCase()) || activeTesters.some((t:any) => t.testerName.toLowerCase().includes(searchQuery.toLowerCase()));

    return { ...proj, testerCount, pct, status, activeTesters, isMatch };
  });

  const filteredProjects = processedProjects.filter(p => p.isMatch && (listFilter === 'all' || p.status === listFilter));
  const needsTesters = filteredProjects.filter(p => p.status === 'need');
  const inProgress = filteredProjects.filter(p => p.status === 'active');
  const complete = filteredProjects.filter(p => p.status === 'done');

  // Fake Live Feed
  const feedEvents = [
    { avatar: 'N', color: '#3d5a80', name: 'Nick', action: 'passed step 02 on', project: 'annabels8', status: 'pass', time: 'just now' },
    { avatar: 'K', color: '#a6421f', name: 'Kate', action: 'started', project: 'annabels10', status: 'info', time: '1m' },
    { avatar: 'J', color: '#a6421f', name: 'James', action: 'completed', project: 'annabels8', status: 'pass', time: '2h' },
    { avatar: 'N', color: '#3d5a80', name: 'Nick', action: 'reported issue on step 02 of', project: 'annabels8', status: 'fail', time: '3m' },
    { avatar: 'S', color: '#6a4a7c', name: 'Sarah', action: 'invited to', project: 'annabels5', status: 'info', time: '1h' },
  ];

  // --- WIZARD LOGIC ---
  const triggerSaved = () => { setWizSaved(true); setTimeout(() => setWizSaved(false), 1500); };

  const handleCsvUpload = (file: File) => {
    setWizFile(file);
    Papa.parse(file, {
      header: true, skipEmptyLines: true,
      complete: (results) => { 
        const headers = results.meta.fields || [];
        setWizHeaders(headers); setWizRawData(results.data); 
        
        const newMap = { action: '', expectedResult: '', area: '', scenario: '', priority: '' };
        headers.forEach(h => {
          const l = h.toLowerCase();
          if (l.includes('action') || l.includes('step')) newMap.action = h;
          if (l.includes('expect')) newMap.expectedResult = h;
          if (l.includes('module') || l.includes('area')) newMap.area = h;
          if (l.includes('scenario')) newMap.scenario = h;
          if (l.includes('prior') || l.includes('sever')) newMap.priority = h;
        });
        setWizMap(newMap); triggerSaved(); setWizStep(3);
      }
    });
  };

  const removeTester = (name: string) => { setWizTesters(prev => prev.filter(t => t.name !== name)); triggerSaved(); };

  const addTester = (nameOverride?: string) => {
    const name = (nameOverride || wizTesterInput).trim();
    if (!name) return;
    if (!wizTesters.some(t => t.name === name)) {
      const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
      const color = colors[wizTesters.length % colors.length];
      setWizTesters([...wizTesters, { name, color }]);
    }
    setWizTesterInput(''); triggerSaved();
  };

  const launchProject = async () => {
    setIsLaunching(true);
    try {
      const mappedSteps: TestStep[] = wizRawData.map((row: any, index: number) => ({
        id: `step_${index + 1}`,
        action: row[wizMap.action] || 'Missing Action',
        expectedResult: row[wizMap.expectedResult] || 'Missing Expected Result',
        area: wizMap.area ? row[wizMap.area] : '',
        scenario: wizMap.scenario ? row[wizMap.scenario] : '',
        priority: wizMap.priority ? row[wizMap.priority] : '',
        mediaUrls: [], referenceLinks: []
      }));

      const targetTesters = wizTesters.length > 0 ? wizTesters.map(t => t.name) : ['Unassigned'];
      const testRunsCollection = collection(db, 'testRuns');

      for (const name of targetTesters) {
        await addDoc(testRunsCollection, {
          projectName: wizName, testerName: name, environment: wizEnv,
          testCycle: wizCycle, steps: mappedSteps, createdAt: serverTimestamp(), results: {} 
        });
      }
      setWizStep(5);
      triggerConfetti();
    } catch (error) { alert("Failed to launch project."); } 
    finally { setIsLaunching(false); }
  };

  const triggerConfetti = () => {
    if (!confettiContainerRef.current) return;
    const colors = ['#4a7c59', '#3d5a80', '#b8860b', '#a6421f', '#6a4a7c'];
    const waves = [{ c: 25, d: 400 }, { c: 18, d: 1200 }, { c: 14, d: 2200 }];
    waves.forEach(w => {
      setTimeout(() => {
        for (let i = 0; i < w.c; i++) {
          const el = document.createElement('div');
          el.className = 'confetti fire';
          el.style.background = colors[Math.floor(Math.random() * colors.length)];
          el.style.left = 50 + (Math.random() - 0.5) * 90 + '%';
          el.style.top = '40px';
          el.style.width = 7 + Math.random() * 5 + 'px';
          el.style.height = 11 + Math.random() * 7 + 'px';
          el.style.animationDelay = Math.random() * 0.5 + 's';
          el.style.animationDuration = 3.5 + Math.random() * 2 + 's';
          confettiContainerRef.current?.appendChild(el);
          setTimeout(() => el.remove(), 6500);
        }
      }, w.d);
    });
  };

  const closeWizard = () => {
    setWizOpen(false);
    setTimeout(() => {
      setWizStep(1); setWizName(''); setWizEnv(''); setWizCycle('');
      setWizFile(null); setWizHeaders([]); setWizRawData([]); setWizTesters([]);
    }, 300);
  };

  const canAdvance = () => {
    if (wizStep === 1) return !!wizName;
    if (wizStep === 2) return !!wizFile;
    if (wizStep === 3) return !!wizMap.action && !!wizMap.expectedResult;
    return true;
  };

  const getAccentForCol = (colName: string) => {
    if (wizMap.action === colName) return 1;
    if (wizMap.expectedResult === colName) return 2;
    if (wizMap.area === colName) return 3;
    if (wizMap.scenario === colName) return 4;
    if (wizMap.priority === colName) return 5;
    return null;
  };

  if (!isMounted) return <div style={{ background: '#f4f3ef', minHeight: '100vh' }} />;

  return (
    <div className="qa-home-wrapper">
      <style dangerouslySetInnerHTML={{__html: `
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500;1,9..144,600&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        
        .qa-home-wrapper {
          position: fixed; inset: 0; z-index: 9999; overflow-y: auto;
          --bg: #f4f3ef; --surface: #ffffff; --surface-alt: #fafaf7;
          --ink: #1a1a1a; --ink-soft: #55524d; --ink-mute: #8a867f;
          --line: #e5e2db; --line-strong: #d4d0c7;
          --accent: #2d4a3e; --accent-soft: #e8f0eb; --accent-ink: #1d3329;
          --sidebar: #121a17; --sidebar-ink: #e5e2db; --sidebar-mute: #7a7a72;
          --rail: #121a17; --rail-ink: #e5e2db; --rail-mute: #7a7a72;
          --pass: #4a7c59; --pass-soft: #e8f0eb;
          --fail: #a6421f; --fail-soft: #f7e8e2;
          --warn: #b8860b; --warn-soft: #f9f0da;
          --info: #3d5a80; --info-soft: #e5ecf2;
          --purple: #6a4a7c; --purple-soft: rgba(106,74,124,0.12);
          --radius: 6px;
          --m1: #3d5a80; --m2: #a6421f; --m3: #b8860b; --m4: #6a4a7c; --m5: #4a7c59;
          background: var(--bg); font-family: 'IBM Plex Sans', system-ui, sans-serif; color: var(--ink); font-size: 14px; overflow-x: hidden;
        }
        
        .qa-home-wrapper * { box-sizing: border-box; }
        .qa-layout { display: grid; grid-template-columns: 240px 1fr; min-height: 100vh; }

        /* SIDEBAR */
        .qa-sidebar { background: var(--sidebar); color: var(--sidebar-ink); display: flex; flex-direction: column; padding: 20px 16px; position: sticky; top: 0; height: 100vh; z-index: 20; }
        .brand { display: flex; align-items: center; gap: 10px; padding: 4px 8px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px; }
        .brand-mark { width: 32px; height: 32px; background: var(--accent); border-radius: var(--radius); display: flex; align-items: center; justify-content: center; color: #fff; }
        .brand-name { font-family: 'Fraunces', serif; font-size: 17px; font-weight: 600; letter-spacing: -0.01em; }
        .nav { display: flex; flex-direction: column; gap: 2px; }
        .nav-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; color: var(--sidebar-mute); text-decoration: none; border-radius: var(--radius); font-size: 13px; font-weight: 500; cursor: pointer; transition: background 0.15s ease, color 0.15s ease; }
        .nav-item:hover { color: var(--sidebar-ink); background: rgba(255,255,255,0.04); }
        .nav-item.active { background: rgba(255,255,255,0.08); color: var(--sidebar-ink); }
        .sidebar-foot { margin-top: auto; display: flex; flex-direction: column; gap: 10px; }
        .issues-pill { display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px; background: var(--fail); color: #fff; border-radius: 999px; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 500; width: fit-content; }
        .user-card { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: rgba(255,255,255,0.04); border-radius: var(--radius); }
        .avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; color: #fff; }
        .user-name { font-size: 13px; font-weight: 500; color: var(--sidebar-ink); }
        .user-role { font-size: 10px; color: var(--sidebar-mute); font-family: 'JetBrains Mono', monospace; text-transform: uppercase; letter-spacing: 0.08em; }

        .qa-main { overflow-x: hidden; }

        /* HERO ZONE */
        .qa-hero { position: relative; padding: 40px 40px 32px; background: linear-gradient(180deg, #ebe8de 0%, #f0ede3 100%); border-bottom: 1px solid var(--line-strong); overflow: hidden; }
        .qa-hero::before { content: ''; position: absolute; inset: 0; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E"); pointer-events: none; opacity: 0.7; }
        .qa-hero::after { content: ''; position: absolute; top: -200px; right: -100px; width: 600px; height: 600px; background: radial-gradient(circle, rgba(45,74,62,0.08) 0%, transparent 60%); pointer-events: none; }
        
        .hero-head { position: relative; display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 28px; gap: 20px; z-index: 1; }
        .hero-eyebrow { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.16em; color: var(--ink-mute); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .hero-eyebrow .time-now { color: var(--accent); font-weight: 500; }
        .hero-title { font-family: 'Fraunces', serif; font-size: 44px; font-weight: 600; letter-spacing: -0.025em; margin: 0; line-height: 1.05; color: var(--ink); }
        .hero-title em { font-style: italic; font-weight: 500; color: var(--accent); }
        
        .hero-meta { display: flex; gap: 20px; align-items: center; font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-soft); }
        .hero-meta > div { display: flex; flex-direction: column; align-items: flex-end; }
        .hero-meta .hm-label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); }
        .hero-meta .hm-value { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 600; color: var(--ink); line-height: 1; margin-top: 2px; }

        .btn { height: 38px; padding: 0 16px; font-family: inherit; font-size: 13px; font-weight: 500; border-radius: var(--radius); cursor: pointer; transition: all 0.15s ease; border: 1px solid transparent; display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; }
        .btn-primary { background: var(--accent); color: #fff; }
        .btn-primary:hover:not(:disabled) { background: var(--accent-ink); }
        .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-ghost { background: transparent; border-color: var(--line-strong); color: var(--ink-soft); }
        .btn-ghost:hover:not(:disabled) { background: var(--surface); color: var(--ink); border-color: var(--ink-mute); }

        /* CURRENTLY STRIP */
        .currently { position: relative; z-index: 1; display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 14px; }
        .module { background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 18px 20px; position: relative; overflow: hidden; transition: all 0.2s ease; }
        .module:hover { box-shadow: 0 6px 16px rgba(0,0,0,0.06); transform: translateY(-1px); }
        .module-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 10px; display: flex; align-items: center; gap: 8px; font-weight: 500; }
        .module-label svg { color: var(--accent); }

        .resume-module { background: linear-gradient(135deg, #fafaf7 0%, #e8f0eb 120%); border-color: rgba(45,74,62,0.2); cursor: pointer; }
        .resume-module .module-label { color: var(--accent); }
        .resume-title { font-family: 'Fraunces', serif; font-size: 22px; font-weight: 600; letter-spacing: -0.01em; margin: 0 0 8px; color: var(--ink); }
        .resume-sub { font-size: 12px; color: var(--ink-soft); margin: 0 0 14px; line-height: 1.5; }
        .resume-sub b { color: var(--ink); font-weight: 500; }
        .resume-stats { display: flex; gap: 18px; margin-bottom: 14px; font-family: 'JetBrains Mono', monospace; font-size: 11px; }
        .resume-stat .rs-label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); }
        .resume-stat .rs-value { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; color: var(--ink); line-height: 1; margin-top: 2px; }
        .resume-action { display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; background: var(--accent); color: #fff; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.15s ease; border: none; font-family: inherit; }
        .resume-action:hover { background: var(--accent-ink); }

        .feed-module { display: flex; flex-direction: column; padding: 0; overflow: hidden; }
        .feed-module .module-label { padding: 16px 18px 8px; margin: 0; }
        .feed-module .module-label .live-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--pass); animation: livePulse 1.6s ease-in-out infinite; }
        .feed-list { flex: 1; overflow: hidden; padding: 0 18px 16px; position: relative; mask-image: linear-gradient(180deg, black 70%, transparent); }
        .feed-track { animation: feedScroll 20s linear infinite; }
        .feed-module:hover .feed-track { animation-play-state: paused; }
        @keyframes feedScroll { 0% { transform: translateY(0); } 100% { transform: translateY(-50%); } }
        .feed-item { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; border-bottom: 1px dashed var(--line); font-size: 12px; }
        .feed-item:last-child { border-bottom: none; }
        .feed-item .mini-avatar { width: 22px; height: 22px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 9px; font-weight: 600; font-family: 'JetBrains Mono', monospace; flex-shrink: 0; margin-top: 1px; }
        .feed-text { flex: 1; color: var(--ink-soft); line-height: 1.45; }
        .feed-text b { color: var(--ink); font-weight: 500; }
        .feed-text .project { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--accent); }
        .feed-text .status { display: inline-block; font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.08em; padding: 1px 5px; border-radius: 3px; font-weight: 500; margin: 0 2px; }
        .status.pass { background: var(--pass-soft); color: var(--pass); }
        .status.fail { background: var(--fail-soft); color: var(--fail); }
        .status.info { background: var(--info-soft); color: var(--info); }
        .feed-time { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); white-space: nowrap; margin-top: 1px; }

        .attention-module { background: linear-gradient(135deg, #fafaf7 0%, #f9f0da 140%); border-color: rgba(184,134,11,0.3); cursor: pointer; }
        .attention-module .module-label { color: var(--warn); }
        .attention-module .module-label svg { color: var(--warn); }
        .attention-number { font-family: 'Fraunces', serif; font-size: 48px; font-weight: 600; color: var(--warn); line-height: 1; margin-bottom: 4px; letter-spacing: -0.02em; }
        .attention-label { font-size: 13px; color: var(--ink); font-weight: 500; margin-bottom: 10px; }
        .attention-breakdown { display: flex; flex-direction: column; gap: 6px; font-size: 11px; color: var(--ink-soft); font-family: 'JetBrains Mono', monospace; }
        .attention-breakdown .ab-row { display: flex; justify-content: space-between; align-items: center; }
        .attention-breakdown .ab-row b { color: var(--warn); }

        /* LIST SECTION */
        .list-section { padding: 28px 40px 60px; max-width: 1400px; }
        .toolbar { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; }
        .search { position: relative; flex: 1; min-width: 240px; max-width: 440px; }
        .search input { width: 100%; height: 38px; padding: 0 12px 0 38px; border: 1px solid var(--line); border-radius: 6px; background: var(--surface); font-family: inherit; font-size: 13px; color: var(--ink); }
        .search input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(45,74,62,0.1); }
        .search svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--ink-mute); }

        .chip-filter { display: flex; gap: 6px; margin-left: auto; flex-wrap: wrap; }
        .filter-chip { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 6px 10px; border: 1px solid var(--line); background: var(--surface); color: var(--ink-soft); border-radius: 999px; cursor: pointer; }
        .filter-chip.active { background: var(--ink); color: #fff; border-color: var(--ink); }
        .filter-chip:hover:not(.active) { background: var(--surface-alt); }

        .section-heading { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin: 28px 0 12px; display: flex; align-items: center; gap: 10px; cursor: pointer; user-select: none; }
        .section-heading:first-child { margin-top: 0; }
        .section-heading::after { content: ''; flex: 1; height: 1px; background: var(--line); }
        .section-heading .count { background: var(--surface); border: 1px solid var(--line); padding: 2px 8px; border-radius: 999px; color: var(--ink-soft); font-weight: 500; }
        .section-group { display: flex; flex-direction: column; gap: 8px; }

        /* PROJECT ROW */
        .project-row { background: var(--surface); border: 1px solid var(--line); border-left: 3px solid var(--line-strong); border-radius: 8px; padding: 16px 20px; display: grid; grid-template-columns: auto 1fr 240px 180px auto; gap: 20px; align-items: center; cursor: pointer; transition: all 0.15s ease; position: relative; }
        .project-row:hover { box-shadow: 0 4px 10px rgba(0,0,0,0.05); border-color: var(--line-strong); }
        .project-row.status-need { border-left-color: var(--warn); }
        .project-row.status-active { border-left-color: var(--info); }
        .project-row.status-done { border-left-color: var(--pass); opacity: 0.85; }

        .row-number { width: 24px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-align: center; font-weight: 500; }
        .project-main { min-width: 0; }
        .project-name-row { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; flex-wrap: wrap; }
        .project-name { font-family: 'Fraunces', serif; font-size: 19px; font-weight: 600; letter-spacing: -0.01em; color: var(--ink); }
        .tag { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 2px 7px; border-radius: 3px; background: var(--info-soft); color: var(--info); }
        .tag.cycle { background: var(--purple-soft); color: var(--purple); }
        .tag.live { background: var(--pass-soft); color: var(--pass); display: inline-flex; align-items: center; gap: 4px; }
        .tag.live::before { content: ''; width: 5px; height: 5px; border-radius: 50%; background: var(--pass); animation: livePulse 1.6s ease-in-out infinite; }
        .project-story { font-size: 12px; color: var(--ink-mute); line-height: 1.5; }
        .project-story b { color: var(--ink-soft); font-weight: 500; }
        .project-story .dot-sep { opacity: 0.4; margin: 0 4px; }

        .avatar-block { display: flex; flex-direction: column; gap: 6px; }
        .avatar-block-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); }
        .avatar-stack { display: flex; align-items: center; gap: 8px; }
        .avatars { display: flex; }
        .avatars .mini-avatar { width: 28px; height: 28px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 600; font-family: 'JetBrains Mono', monospace; border: 2px solid var(--surface); margin-left: -6px; position: relative; transition: transform 0.2s ease; }
        .avatars .mini-avatar:first-child { margin-left: 0; }
        .avatars .mini-avatar:hover { transform: translateY(-2px); z-index: 3; }
        .avatars .mini-avatar.live::after { content: ''; position: absolute; bottom: -1px; right: -1px; width: 10px; height: 10px; border-radius: 50%; background: var(--pass); border: 2px solid var(--surface); animation: livePulse 1.6s ease-in-out infinite; }
        .avatars .more { background: var(--line); color: var(--ink-soft); font-size: 9px; }
        .avatar-empty { display: inline-flex; align-items: center; gap: 6px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--warn); text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 8px; background: var(--warn-soft); border-radius: 4px; font-weight: 500; }
        .avatar-empty::before { content: ''; width: 5px; height: 5px; border-radius: 50%; background: var(--warn); }

        .progress-block { display: flex; flex-direction: column; gap: 6px; }
        .progress-block-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); display: flex; justify-content: space-between; }
        .progress-block-label .val { color: var(--ink); font-weight: 500; }
        .progress-segmented { height: 6px; background: var(--line); border-radius: 999px; overflow: hidden; display: flex; }
        .progress-segmented .seg { height: 100%; }
        .seg.pass { background: var(--pass); }
        .seg.fail { background: var(--fail); }
        .seg.pend { background: var(--warn); }

        .row-actions { display: flex; gap: 4px; align-items: center; }
        .icon-btn { width: 34px; height: 34px; border: 1px solid var(--line); background: var(--surface); border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--ink-mute); transition: all 0.15s ease; position: relative; }
        .icon-btn:hover { background: var(--accent-soft); color: var(--accent); border-color: var(--accent); }

        /* Toast */
        .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%) translateY(100px); background: var(--ink); color: #fff; padding: 10px 16px; border-radius: 6px; font-size: 13px; display: flex; align-items: center; gap: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); transition: transform 0.3s cubic-bezier(.4,0,.2,1); z-index: 100; }
        .toast.show { transform: translateX(-50%) translateY(0); }
        .toast .check { color: var(--pass); }

        /* WIZARD STYLES (PURE HTML/CSS) */
        .wiz-modal-overlay { position: fixed; inset: 0; background: rgba(18,26,23,0.6); backdrop-filter: blur(4px); z-index: 9998; animation: fadeIn 0.2s ease; }
        .wiz-modal-container { position: fixed; inset: 0; z-index: 9999; display: flex; align-items: center; justify-content: center; pointer-events: none; padding: 24px; }
        .wiz-modal { pointer-events: auto; width: 720px; max-width: 100%; max-height: calc(100vh - 48px); background: var(--surface); border: 1px solid var(--line-strong); border-radius: 16px; box-shadow: 0 24px 60px rgba(0,0,0,0.3); display: grid; grid-template-columns: 200px 1fr; overflow: hidden; transition: width 0.4s cubic-bezier(.4,.0,.2,1); animation: modalIn 0.3s cubic-bezier(.4,0,.2,1); }
        .wiz-modal.expanded { width: 1180px; }
        @keyframes modalIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        @media (max-width: 900px) { .wiz-modal { grid-template-columns: 1fr; } .rail { display: none !important; } .step1-grid, .mapping-grid, .roster-grid { grid-template-columns: 1fr !important; } .wiz-modal.expanded { width: 100%; } }

        .rail { background: var(--rail); color: var(--rail-ink); padding: 24px 18px; display: flex; flex-direction: column; gap: 20px; position: relative; overflow: hidden; }
        .rail::after { content: ''; position: absolute; inset: 0; background: radial-gradient(circle at 20% 100%, rgba(74,124,89,0.15) 0, transparent 60%); pointer-events: none; }
        .rail-brand { font-family: 'Fraunces', serif; font-size: 16px; font-weight: 600; letter-spacing: -0.01em; position: relative; z-index: 1; }
        .rail-brand .eyebrow { display: block; font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--rail-mute); margin-bottom: 4px; font-weight: 500; }
        .rail-progress { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--rail-mute); text-transform: uppercase; letter-spacing: 0.12em; display: flex; justify-content: space-between; position: relative; z-index: 1; }
        .rail-bar { height: 2px; background: rgba(255,255,255,0.08); border-radius: 1px; overflow: hidden; position: relative; z-index: 1; }
        .rail-bar-fill { height: 100%; background: linear-gradient(90deg, var(--pass), #7ab28a); transition: width 0.4s cubic-bezier(.4,.0,.2,1); }
        .rail-steps { display: flex; flex-direction: column; gap: 2px; position: relative; z-index: 1; }
        .rail-step { display: flex; align-items: flex-start; gap: 10px; padding: 10px 8px; border-radius: 6px; cursor: pointer; transition: background 0.15s ease; }
        .rail-step:hover { background: rgba(255,255,255,0.04); }
        .rail-step.locked { cursor: not-allowed; opacity: 0.5; }
        .rail-step.locked:hover { background: transparent; }
        .step-dot { width: 22px; height: 22px; border-radius: 50%; background: rgba(255,255,255,0.08); color: var(--rail-mute); display: flex; align-items: center; justify-content: center; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 500; flex-shrink: 0; margin-top: 1px; transition: all 0.2s ease; }
        .rail-step.active .step-dot { background: var(--pass); color: #fff; box-shadow: 0 0 0 3px rgba(74,124,89,0.25); }
        .rail-step.done .step-dot { background: transparent; color: var(--pass); border: 1px solid var(--pass); }
        .step-text { min-width: 0; flex: 1; }
        .step-name { font-size: 12px; font-weight: 500; color: var(--rail-ink); }
        .rail-step.locked .step-name { color: var(--rail-mute); }
        .step-value { font-size: 11px; color: var(--rail-mute); margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-family: 'JetBrains Mono', monospace; }
        .rail-step.done .step-value { color: #9fb5a7; }
        .rail-foot { margin-top: auto; padding-top: 16px; border-top: 1px solid rgba(255,255,255,0.08); position: relative; z-index: 1; }
        .rail-tip { font-size: 11px; color: var(--rail-mute); line-height: 1.5; }
        .rail-tip kbd { display: inline-block; padding: 1px 5px; background: rgba(255,255,255,0.1); border-radius: 3px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--rail-ink); }

        .wiz-content { display: flex; flex-direction: column; overflow: hidden; min-height: 0; width: 100%; color: var(--ink); font-size: 14px; }
        .content-head { display: flex; align-items: flex-start; justify-content: space-between; padding: 22px 28px 14px; border-bottom: 1px solid var(--line); }
        .content-title { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 600; letter-spacing: -0.01em; margin: 0; }
        .content-title .eyebrow { display: block; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 4px; }
        .content-sub { color: var(--ink-mute); font-size: 13px; margin: 4px 0 0; }
        .content-body { flex: 1; padding: 24px 28px; overflow-y: auto; position: relative; }
        .content-body.launching { overflow: hidden; }

        .step-panel { display: none; animation: slideIn 0.3s cubic-bezier(.4,.0,.2,1); height: 100%; }
        .step-panel.active { display: block; }
        @keyframes slideIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

        .wiz-field { margin-bottom: 18px; }
        .wiz-field-label { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 500; color: var(--ink-soft); margin-bottom: 6px; }
        .wiz-field-label .optional { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; }
        .wiz-input { width: 100%; height: 40px; padding: 0 14px; font-family: inherit; font-size: 14px; color: var(--ink); background: var(--surface); border: 1px solid var(--line-strong); border-radius: 6px; transition: all 0.15s ease; }
        .wiz-input::placeholder { color: var(--ink-mute); }
        .wiz-input:hover { border-color: #b8b3a8; }
        .wiz-input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(45,74,62,0.12); }

        .step1-grid { display: grid; grid-template-columns: 1fr 280px; gap: 28px; align-items: flex-start; }
        .preview-card { background: linear-gradient(135deg, #fafaf7 0%, #f0ede4 100%); border: 1px solid var(--line-strong); border-radius: 8px; padding: 18px; position: relative; overflow: hidden; }
        .preview-card::before { content: ''; position: absolute; top: 0; right: 0; width: 80px; height: 80px; background: radial-gradient(circle, rgba(45,74,62,0.08) 0%, transparent 70%); border-radius: 50%; }
        .preview-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 8px; }
        .preview-name { font-family: 'Fraunces', serif; font-size: 20px; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 10px; min-height: 26px; color: var(--ink); word-break: break-word; }
        .preview-name.empty { color: var(--ink-mute); font-style: italic; font-weight: 500; }
        .preview-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 14px; min-height: 20px; }
        .preview-tag { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 3px 8px; border-radius: 4px; background: rgba(61,90,128,0.1); color: var(--info); }
        .preview-tag.cycle { background: rgba(106,74,124,0.1); color: #6a4a7c; }
        .preview-meta { font-size: 11px; color: var(--ink-mute); line-height: 1.5; font-family: 'JetBrains Mono', monospace; }
        .preview-meta .line { margin-bottom: 3px; }

        .dropzone { position: relative; border: 2px dashed var(--line-strong); border-radius: 10px; padding: 44px 24px; text-align: center; background: var(--surface-alt); transition: all 0.2s ease; overflow: hidden; }
        .dropzone.dragover { border-color: var(--accent); background: var(--accent-soft); }
        .dropzone.uploaded { border-style: solid; border-color: var(--pass); background: var(--surface); padding: 20px 24px; text-align: left; }
        .dz-icon { width: 56px; height: 56px; margin: 0 auto 14px; border-radius: 12px; background: var(--surface); border: 1px solid var(--line); display: flex; align-items: center; justify-content: center; color: var(--accent); position: relative; }
        .dz-title { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; margin-bottom: 4px; }
        .dz-sub { color: var(--ink-mute); font-size: 13px; margin-bottom: 14px; }
        .dz-hint { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; margin-top: 10px; }
        .file-info { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
        .file-icon { width: 40px; height: 40px; background: var(--accent-soft); color: var(--accent); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 600; flex-shrink: 0; }
        .file-name { font-weight: 500; color: var(--ink); margin-bottom: 2px; }
        .file-stat { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-mute); }
        .file-replace { margin-left: auto; font-size: 12px; color: var(--ink-mute); text-decoration: underline; cursor: pointer; }
        .file-replace:hover { color: var(--accent); }
        .preview-table { width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid var(--line); border-radius: 6px; overflow: hidden; }
        .preview-table th, .preview-table td { padding: 8px 10px; text-align: left; border-bottom: 1px solid var(--line); }
        .preview-table th { background: var(--surface-alt); font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; color: var(--ink-mute); }
        .preview-table tr:last-child td { border-bottom: none; }
        .preview-table td { color: var(--ink-soft); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .mapping-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 24px; height: 100%; }
        .csv-panel { background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; overflow: hidden; display: flex; flex-direction: column; }
        .csv-head { padding: 10px 14px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: center; background: var(--surface); }
        .csv-head-title { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); }
        .csv-table-wrap { overflow: auto; flex: 1; }
        .csv-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .csv-table th { position: sticky; top: 0; background: var(--surface); padding: 10px 12px; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; color: var(--ink-mute); border-bottom: 1px solid var(--line); text-align: left; transition: all 0.15s ease; }
        .csv-table th .col-letter { display: inline-block; width: 16px; height: 16px; border-radius: 3px; background: var(--line); color: var(--ink-mute); font-size: 9px; text-align: center; line-height: 16px; margin-right: 6px; transition: all 0.15s ease; }
        
        .csv-table th.mapped { background: var(--accent-soft); }
        .csv-table th.mapped .col-letter { color: #fff; }
        .csv-table th.mapped[data-accent="1"] { background: #e5ecf2; color: var(--m1); }
        .csv-table th.mapped[data-accent="1"] .col-letter { background: var(--m1); }
        .csv-table th.mapped[data-accent="2"] { background: #f7e8e2; color: var(--m2); }
        .csv-table th.mapped[data-accent="2"] .col-letter { background: var(--m2); }
        .csv-table th.mapped[data-accent="3"] { background: #f9f0da; color: var(--m3); }
        .csv-table th.mapped[data-accent="3"] .col-letter { background: var(--m3); }
        .csv-table th.mapped[data-accent="4"] { background: #f0e6f5; color: var(--m4); }
        .csv-table th.mapped[data-accent="4"] .col-letter { background: var(--m4); }
        .csv-table th.mapped[data-accent="5"] { background: #e8f0eb; color: var(--m5); }
        .csv-table th.mapped[data-accent="5"] .col-letter { background: var(--m5); }
        .csv-table th.highlight { box-shadow: inset 0 -2px 0 var(--accent); }
        .csv-table td { padding: 8px 12px; border-bottom: 1px solid var(--line); color: var(--ink-soft); white-space: nowrap; max-width: 180px; overflow: hidden; text-overflow: ellipsis; }
        .csv-table td[data-accent="1"] { background: rgba(61,90,128,0.06); }
        .csv-table td[data-accent="2"] { background: rgba(166,66,31,0.06); }
        .csv-table td[data-accent="3"] { background: rgba(184,134,11,0.06); }
        .csv-table td[data-accent="4"] { background: rgba(106,74,124,0.06); }
        .csv-table td[data-accent="5"] { background: rgba(74,124,89,0.06); }

        .mappers { display: flex; flex-direction: column; gap: 10px; }
        .mapper { background: var(--surface); border: 1px solid var(--line-strong); border-radius: 8px; padding: 12px 14px; cursor: pointer; transition: all 0.2s ease; position: relative; }
        .mapper:hover { border-color: var(--accent); }
        .mapper[data-accent="1"].mapped { border-left: 3px solid var(--m1); background: rgba(61,90,128,0.04); }
        .mapper[data-accent="2"].mapped { border-left: 3px solid var(--m2); background: rgba(166,66,31,0.04); }
        .mapper[data-accent="3"].mapped { border-left: 3px solid var(--m3); background: rgba(184,134,11,0.04); }
        .mapper[data-accent="4"].mapped { border-left: 3px solid var(--m4); background: rgba(106,74,124,0.04); }
        .mapper[data-accent="5"].mapped { border-left: 3px solid var(--m5); background: rgba(74,124,89,0.04); }
        .mapper-label { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
        .mapper-name { font-weight: 500; color: var(--ink); font-size: 13px; }
        .mapper-req { font-family: 'JetBrains Mono', monospace; font-size: 9px; padding: 2px 6px; border-radius: 3px; background: var(--fail); color: #fff; text-transform: uppercase; letter-spacing: 0.08em; }
        .mapper-opt { font-family: 'JetBrains Mono', monospace; font-size: 9px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; }
        .mapper-select { width: 100%; height: 32px; padding: 0 28px 0 0; font-family: inherit; font-size: 13px; color: var(--ink); background: transparent; border: none; cursor: pointer; appearance: none; background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2355524d' stroke-width='2'%3e%3cpolyline points='6 9 12 15 18 9'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 4px center; }
        .mapper-select:focus { outline: none; }
        .mapper-preview { margin-top: 4px; font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-mute); padding-top: 6px; border-top: 1px dashed var(--line); display: flex; gap: 6px; align-items: center; }
        .mapper-preview .arrow { color: var(--ink-mute); }
        .mapper-preview .sample { background: var(--surface-alt); padding: 2px 6px; border-radius: 3px; color: var(--ink-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 200px; }

        .roster-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .add-tester-row { display: flex; gap: 8px; margin-bottom: 14px; }
        .add-tester-row .input { flex: 1; }
        .recent-testers { margin-top: 14px; }
        .recent-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 8px; }
        .recent-chips { display: flex; flex-wrap: wrap; gap: 6px; }
        .recent-chip { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px 4px 4px; background: var(--surface-alt); border: 1px solid var(--line); border-radius: 999px; cursor: pointer; font-size: 12px; transition: all 0.15s ease; }
        .recent-chip:hover { border-color: var(--accent); background: var(--accent-soft); }
        .recent-chip .mini-avatar { width: 20px; height: 20px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 9px; font-weight: 600; font-family: 'JetBrains Mono', monospace; }
        .recent-chip .plus { color: var(--ink-mute); font-weight: 600; }
        .roster-panel { background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; padding: 16px; min-height: 280px; display: flex; flex-direction: column; }
        .roster-head { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 12px; display: flex; justify-content: space-between; }
        .roster-list { display: flex; flex-direction: column; gap: 8px; flex: 1; }
        .roster-empty { flex: 1; display: flex; align-items: center; justify-content: center; color: var(--ink-mute); font-size: 13px; text-align: center; padding: 20px; border: 1px dashed var(--line-strong); border-radius: 6px; min-height: 180px; }
        .roster-item { display: flex; align-items: center; gap: 10px; padding: 8px 12px; background: var(--surface); border: 1px solid var(--line); border-radius: 6px; animation: popIn 0.3s cubic-bezier(.4,0,.2,1); }
        @keyframes popIn { from { opacity: 0; transform: scale(0.95) translateY(-4px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        .roster-avatar { width: 28px; height: 28px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; flex-shrink: 0; font-family: 'JetBrains Mono', monospace; }
        .roster-name { flex: 1; font-size: 13px; font-weight: 500; }
        .roster-remove { width: 24px; height: 24px; border: none; background: transparent; color: var(--ink-mute); cursor: pointer; border-radius: 4px; display: flex; align-items: center; justify-content: center; }
        .roster-remove:hover { background: var(--fail); color: #fff; }

        .launch-celebration { text-align: center; padding: 10px 20px; position: relative; overflow: visible; }
        .launch-icon-wrap { width: 80px; height: 80px; margin: 0 auto 20px; border-radius: 50%; background: var(--accent-soft); display: flex; align-items: center; justify-content: center; position: relative; animation: scaleIn 0.5s cubic-bezier(.4,0,.2,1); }
        @keyframes scaleIn { from { transform: scale(0); } to { transform: scale(1); } }
        .launch-icon-wrap::before, .launch-icon-wrap::after { content: ''; position: absolute; inset: -6px; border-radius: 50%; border: 1px solid var(--accent); opacity: 0; animation: ripple 1.5s ease-out infinite; }
        .launch-icon-wrap::after { animation-delay: 0.5s; }
        @keyframes ripple { 0% { transform: scale(1); opacity: 0.6; } 100% { transform: scale(1.4); opacity: 0; } }
        .launch-title { font-family: 'Fraunces', serif; font-size: 30px; font-weight: 600; letter-spacing: -0.02em; margin: 0 0 8px; }
        .launch-sub { color: var(--ink-mute); font-size: 14px; margin: 0 auto 24px; max-width: 380px; }
        .launch-summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; padding: 16px; margin-bottom: 24px; text-align: left; }
        .launch-cell .lc-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 2px; }
        .launch-cell .lc-value { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; color: var(--ink); }
        
        .confetti { position: absolute; width: 8px; height: 14px; pointer-events: none; opacity: 0; border-radius: 1px; z-index: 2; }
        .confetti.fire { animation: fall 3.6s cubic-bezier(.2,.6,.4,1) forwards; }
        @keyframes fall { 0% { opacity: 0; transform: translateY(-20px) rotate(0); } 8% { opacity: 1; } 85% { opacity: 1; } 100% { opacity: 0; transform: translateY(420px) rotate(720deg); } }

        .content-foot { display: flex; justify-content: space-between; align-items: center; gap: 16px; padding: 16px 32px; border-top: 1px solid var(--line); background: var(--surface-alt); }
        .foot-hint { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; display: flex; align-items: center; gap: 8px; min-width: 0; overflow: hidden; }
        .foot-actions { display: flex; gap: 8px; align-items: center; flex-shrink: 0; }
        .content-foot.crowded .foot-hint span:not(.saved-indicator) { display: none; }
        .foot-hint kbd { background: var(--surface); border: 1px solid var(--line-strong); padding: 2px 6px; border-radius: 3px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-soft); }
        .saved-indicator { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; display: inline-flex; align-items: center; gap: 5px; margin-right: 10px; transition: opacity 0.2s; opacity: 0; }
        .saved-indicator.show { opacity: 1; }
        .saved-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--pass); }
      `}} />

      <div className="qa-layout">
        {/* SIDEBAR */}
        <aside className="qa-sidebar">
          <div className="brand">
            <div className="brand-mark">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
            </div>
            <div className="brand-name">QA Triage</div>
          </div>
          <nav className="nav">
            <a className="nav-item active" style={{cursor: 'default'}}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
              Home
            </a>
            <a className="nav-item" onClick={() => router.push('/admin')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l1-1"/></svg>
              Project Admin
            </a>
            <a className="nav-item" onClick={() => router.push('/pm')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 5-5"/></svg>
              Triage Board
            </a>
            <a className="nav-item" onClick={() => router.push('/admin/settings')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83 2.83l.06.06a1.65 1.65 0 001.82.33h0a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51h0a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82v0a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
              Workspace Settings
            </a>
          </nav>
          <div className="sidebar-foot">
            <div className="issues-pill">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><path d="M12 9v4M12 17h.01"/></svg>
              {needsTesters.length} Issues
            </div>
            <div className="user-card">
              <div className="avatar">JD</div>
              <div>
                <div className="user-name">John Doe</div>
                <div className="user-role">Admin</div>
              </div>
            </div>
          </div>
        </aside>

        <main className="qa-main">
          {/* HERO ZONE */}
          <section className="qa-hero">
            <div className="hero-head">
              <div>
                <div className="hero-eyebrow">
                  <span>Workspace · {projects.length} projects</span>
                  <span style={{ opacity: 0.5 }}>—</span>
                  <span className="time-now">{greeting}, John</span>
                </div>
                <h1 className="hero-title">Your <em>test cycles</em>,<br/>in one place.</h1>
              </div>
              <div className="hero-meta">
                <div style={{alignItems: 'flex-end', display: 'flex', flexDirection: 'column'}}>
                  <span className="hm-label">Active Testers</span>
                  <span className="hm-value">{activeTestersCount}</span>
                </div>
                <div style={{alignItems: 'flex-end', display: 'flex', flexDirection: 'column'}}>
                  <span className="hm-label">Live Now</span>
                  <span className="hm-value" style={{ color: 'var(--pass)' }}>{liveNowCount}</span>
                </div>
                <div style={{alignItems: 'flex-end', display: 'flex', flexDirection: 'column'}}>
                  <span className="hm-label">Avg Progress</span>
                  <span className="hm-value">{avgProgress}%</span>
                </div>
                <div style={{alignItems: 'flex-end', display: 'flex', flexDirection: 'column', paddingLeft: '16px', borderLeft: '1px solid var(--line)'}}>
                  <button className="btn btn-primary" onClick={() => setWizOpen(true)} style={{height: '44px', padding: '0 20px', borderRadius: '8px', fontSize: '14px'}}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" style={{marginRight: '6px'}}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Create New Project
                  </button>
                </div>
              </div>
            </div>

            <div className="currently">
              <div className="module resume-module" onClick={() => projects[0] && router.push('/admin')}>
                <div className="module-label">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  Pick up where you left off
                </div>
                <h2 className="resume-title">{projects[0]?.name || 'No projects'}</h2>
                <p className="resume-sub">Jump directly into your most recently active testing cycle.</p>
                <div className="resume-stats">
                  <div className="resume-stat">
                    <div className="rs-label">Steps</div>
                    <div className="rs-value">{projects[0]?.totalSteps || 0}</div>
                  </div>
                  <div className="resume-stat">
                    <div className="rs-label">Testers</div>
                    <div className="rs-value">{projects[0]?.runs?.filter((r:any) => r.testerName !== 'Unassigned').length || 0}</div>
                  </div>
                  <div className="resume-stat">
                    <div className="rs-label">Progress</div>
                    <div className="rs-value">{projects[0]?.pct || 0}%</div>
                  </div>
                </div>
                <button className="resume-action">
                  Manage Project
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </button>
              </div>

              <div className="module feed-module">
                <div className="module-label">
                  <span className="live-dot"></span> Live activity
                </div>
                <div className="feed-list">
                  <div className="feed-track">
                    {[...feedEvents, ...feedEvents].map((e, i) => (
                      <div className="feed-item" key={i}>
                        <div className="mini-avatar" style={{background: e.color}}>{e.avatar}</div>
                        <div className="feed-text">
                          <b>{e.name}</b> {e.action} <span className="project">{e.project}</span>
                          <div style={{marginTop: '2px'}}>
                            <span className={`status ${e.status}`}>{e.status === 'pass' ? 'PASS' : e.status === 'fail' ? 'FAIL' : 'EVENT'}</span>
                          </div>
                        </div>
                        <div className="feed-time">{e.time}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="module attention-module" onClick={() => { setListFilter('need'); showToast('Filtered to projects needing attention'); }}>
                <div className="module-label">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                  Needs attention
                </div>
                <div className="attention-number">{needsTesters.length}</div>
                <div className="attention-label">Projects waiting on you</div>
                <div className="attention-breakdown">
                  <div className="ab-row"><span>No testers assigned</span><b>{needsTesters.length}</b></div>
                </div>
              </div>
            </div>
          </section>

          {/* LIST SECTION */}
          <section className="list-section">
            <div className="toolbar">
              <div className="search">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" placeholder="Search projects, testers, scenarios..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              
              <div className="chip-filter">
                <button className={`filter-chip ${listFilter === 'all' ? 'active' : ''}`} onClick={() => setListFilter('all')}>All · {processedProjects.length}</button>
                <button className={`filter-chip ${listFilter === 'active' ? 'active' : ''}`} onClick={() => setListFilter('active')}>Active · {inProgress.length}</button>
                <button className={`filter-chip ${listFilter === 'need' ? 'active' : ''}`} onClick={() => setListFilter('need')}>Needs testers · {needsTesters.length}</button>
                <button className={`filter-chip ${listFilter === 'done' ? 'active' : ''}`} onClick={() => setListFilter('done')}>Complete · {complete.length}</button>
              </div>
            </div>

            <div id="project-list">
              
              {needsTesters.length > 0 && (
                <>
                  <h3 className="section-heading">Needs Testers <span className="count">{needsTesters.length}</span></h3>
                  <div className="section-group">
                    {needsTesters.map((p, idx) => (
                      <div className="project-row status-need" key={p.name} onClick={() => router.push('/admin')}>
                        <div className="row-number">{(idx + 1).toString().padStart(2, '0')}</div>
                        <div className="project-main">
                          <div className="project-name-row">
                            <span className="project-name">{p.name}</span>
                            {p.cycle && <span className="tag cycle">{p.cycle}</span>}
                            {p.environment && <span className="tag">{p.environment}</span>}
                          </div>
                          <div className="project-story">Created <b>{p.createdAt.toLocaleDateString()}</b> <span className="dot-sep">·</span> {p.totalSteps} test steps <span className="dot-sep">·</span> Ready to provision</div>
                        </div>
                        <div className="avatar-block">
                          <div className="avatar-block-label">Testers</div>
                          <div className="avatar-empty">No testers</div>
                        </div>
                        <div className="progress-block">
                          <div className="progress-block-label"><span>Progress</span><span className="val">0%</span></div>
                          <div className="progress-segmented"></div>
                        </div>
                        <div className="row-actions">
                          <button className="icon-btn" onClick={(e) => { e.stopPropagation(); router.push('/admin'); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {inProgress.length > 0 && (
                <>
                  <h3 className="section-heading" style={{ marginTop: needsTesters.length ? 28 : 0 }}>In Progress <span className="count">{inProgress.length}</span></h3>
                  <div className="section-group">
                    {inProgress.map((p, idx) => {
                      const isLive = p.activeTesters.some((t: any) => !t.isCompleted && Object.keys(t.results || {}).length > 0);
                      return (
                        <div className="project-row status-active" key={p.name} onClick={() => router.push('/admin')}>
                          <div className="row-number">{(needsTesters.length + idx + 1).toString().padStart(2, '0')}</div>
                          <div className="project-main">
                            <div className="project-name-row">
                              <span className="project-name">{p.name}</span>
                              {isLive && <span className="tag live">Live</span>}
                            </div>
                            <div className="project-story">In progress <span className="dot-sep">·</span> {p.totalSteps} steps</div>
                          </div>
                          <div className="avatar-block">
                            <div className="avatar-block-label">Testers {isLive ? '· Live' : ''}</div>
                            <div className="avatar-stack">
                              <div className="avatars">
                                {p.activeTesters.slice(0, 3).map((t: any, i: number) => {
                                  const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
                                  const c = colors[t.testerName.length % colors.length];
                                  const testerIsLive = !t.isCompleted && Object.keys(t.results || {}).length > 0;
                                  return <div key={i} className={`mini-avatar ${testerIsLive ? 'live' : ''}`} style={{background: c}} title={t.testerName}>{t.testerName.charAt(0).toUpperCase()}</div>
                                })}
                                {p.testerCount > 3 && <div className="mini-avatar more">+{p.testerCount - 3}</div>}
                              </div>
                            </div>
                          </div>
                          <div className="progress-block">
                            <div className="progress-block-label"><span>Progress</span><span className="val">{p.pct}%</span></div>
                            <div className="progress-segmented">
                              <div className="seg pass" style={{ flex: p.pct }}></div>
                              <div style={{ flex: 100 - p.pct }}></div>
                            </div>
                          </div>
                          <div className="row-actions">
                            <button className="icon-btn" onClick={(e) => { e.stopPropagation(); router.push('/admin'); }}>
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              {complete.length > 0 && (
                <>
                  <h3 className="section-heading" style={{ marginTop: (needsTesters.length || inProgress.length) ? 28 : 0 }}>Complete <span className="count">{complete.length}</span></h3>
                  <div className="section-group">
                    {complete.map((p, idx) => (
                      <div className="project-row status-done" key={p.name} onClick={() => router.push('/admin')}>
                        <div className="row-number">{(needsTesters.length + inProgress.length + idx + 1).toString().padStart(2, '0')}</div>
                        <div className="project-main">
                          <div className="project-name-row">
                            <span className="project-name">{p.name}</span>
                          </div>
                          <div className="project-story">Completed <span className="dot-sep">·</span> 100% passed</div>
                        </div>
                        <div className="avatar-block">
                          <div className="avatar-block-label">Testers</div>
                          <div className="avatar-stack">
                            <div className="avatars">
                              {p.activeTesters.slice(0, 3).map((t: any, i: number) => {
                                const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
                                const c = colors[t.testerName.length % colors.length];
                                return <div key={i} className="mini-avatar" style={{background: c}} title={t.testerName}>{t.testerName.charAt(0).toUpperCase()}</div>
                              })}
                            </div>
                          </div>
                        </div>
                        <div className="progress-block">
                          <div className="progress-block-label"><span>Progress</span><span className="val">100%</span></div>
                          <div className="progress-segmented"><div className="seg pass" style={{ flex: 100 }}></div></div>
                        </div>
                        <div className="row-actions">
                          <button className="icon-btn" onClick={(e) => { e.stopPropagation(); router.push('/admin'); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
              
            </div>
          </section>
        </main>

        <div className={`toast ${toastMsg ? 'show' : ''}`}>
          <svg className="check" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
          <span>{toastMsg}</span>
        </div>
      </div>

      {/* --- NEW PROJECT WIZARD MODAL --- */}
      {wizOpen && (
        <>
          <div className="wiz-modal-overlay" onClick={closeWizard}></div>
          <div className="wiz-modal-container">
            <div className={`wiz-modal ${wizStep === 3 ? 'expanded' : ''}`}>
              
              <aside className="rail">
                <div className="rail-brand"><span className="eyebrow">QA Triage</span>New Project</div>
                <div>
                  <div className="rail-progress"><span>Step {wizStep} / 5</span><span className="time">{wizStep === 5 ? 'Done' : `~${[45,30,25,15,0][wizStep-1]}s left`}</span></div>
                  <div className="rail-bar" style={{marginTop: '6px'}}><div className="rail-bar-fill" style={{ width: (wizStep / 5) * 100 + '%' }}></div></div>
                </div>
                <nav className="rail-steps">
                  <div className={`rail-step ${wizStep === 1 ? 'active' : wizStep > 1 ? 'done' : 'locked'}`} onClick={() => wizStep > 1 && setWizStep(1)}>
                    <div className="step-dot">{wizStep > 1 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '1'}</div>
                    <div className="step-text"><div className="step-name">Details</div><div className="step-value">{wizName || '—'}</div></div>
                  </div>
                  <div className={`rail-step ${wizStep === 2 ? 'active' : wizStep > 2 ? 'done' : 'locked'}`} onClick={() => wizStep > 2 && setWizStep(2)}>
                    <div className="step-dot">{wizStep > 2 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '2'}</div>
                    <div className="step-text"><div className="step-name">Script</div><div className="step-value">{wizFile ? `${wizRawData.length} tests` : 'Upload CSV'}</div></div>
                  </div>
                  <div className={`rail-step ${wizStep === 3 ? 'active' : wizStep > 3 ? 'done' : 'locked'}`} onClick={() => wizStep > 3 && setWizStep(3)}>
                    <div className="step-dot">{wizStep > 3 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '3'}</div>
                    <div className="step-text"><div className="step-name">Map Columns</div><div className="step-value">{Object.values(wizMap).filter(Boolean).length} mapped</div></div>
                  </div>
                  <div className={`rail-step ${wizStep === 4 ? 'active' : wizStep > 4 ? 'done' : 'locked'}`}>
                    <div className="step-dot">{wizStep > 4 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '4'}</div>
                    <div className="step-text"><div className="step-name">Assign</div><div className="step-value">{wizTesters.length ? `${wizTesters.length} added` : 'Optional'}</div></div>
                  </div>
                  <div className={`rail-step ${wizStep === 5 ? 'active' : 'locked'}`}>
                    <div className="step-dot">5</div>
                    <div className="step-text"><div className="step-name">Launch</div><div className="step-value">—</div></div>
                  </div>
                </nav>
                <div className="rail-foot"><div className="rail-tip">Press <kbd>Enter</kbd> to continue, <kbd>Esc</kbd> to close. Your progress is saved automatically.</div></div>
              </aside>

              <div className="wiz-content">
                <header className="content-head">
                  <div>
                    <h1 className="content-title"><span className="eyebrow">Step {wizStep} of 5</span>
                      {wizStep === 1 ? 'Project Parameters' : wizStep === 2 ? 'Upload Test Script' : wizStep === 3 ? 'Map Your Columns' : wizStep === 4 ? 'Assign Testers' : 'All Set'}
                    </h1>
                    <p className="content-sub">
                      {wizStep === 1 ? 'Give your project a name and context. You can edit these later.' : wizStep === 2 ? 'Drop a CSV of your test cases. We\'ll detect columns automatically.' : wizStep === 3 ? 'Confirm how your CSV columns map to project fields.' : wizStep === 4 ? 'Build your team. Skip to create an unassigned project for later.' : 'Review what was just created.'}
                    </p>
                  </div>
                  <button className="close-btn" onClick={closeWizard}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
                </header>

                <div className={`content-body ${wizStep === 5 ? 'launching' : ''}`}>
                  
                  {wizStep === 1 && (
                    <div className="step-panel active">
                      <div className="step1-grid">
                        <div>
                          <div className="wiz-field">
                            <div className="wiz-field-label"><span>Project Name *</span></div>
                            <input className="wiz-input" type="text" value={wizName} onChange={e => {setWizName(e.target.value); triggerSaved();}} placeholder="e.g. Checkout v3 UAT" />
                          </div>
                          <div className="wiz-field">
                            <div className="wiz-field-label"><span>Target Environment</span><span className="optional">Optional</span></div>
                            <input className="wiz-input" type="text" value={wizEnv} onChange={e => {setWizEnv(e.target.value); triggerSaved();}} placeholder="Staging, Production, Dev..." />
                          </div>
                          <div className="wiz-field">
                            <div className="wiz-field-label"><span>Test Cycle</span><span className="optional">Optional</span></div>
                            <input className="wiz-input" type="text" value={wizCycle} onChange={e => {setWizCycle(e.target.value); triggerSaved();}} placeholder="Sprint 42, Release 2.1..." />
                          </div>
                        </div>
                        <div>
                          <div className="preview-card">
                            <div className="preview-label">Live Preview</div>
                            <div className={`preview-name ${!wizName ? 'empty' : ''}`}>{wizName || 'Untitled project'}</div>
                            <div className="preview-tags">
                              {wizEnv && <span className="preview-tag">{wizEnv}</span>}
                              {wizCycle && <span className="preview-tag cycle">{wizCycle}</span>}
                            </div>
                            <div className="preview-meta">
                              <div className="line">Created · just now</div>
                              <div className="line">Owner · Admin</div>
                              <div className="line">Tests · —</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {wizStep === 2 && (
                    <div className="step-panel active">
                      <div className={`dropzone ${isDragging ? 'dragover' : ''} ${wizFile ? 'uploaded' : ''}`}
                        onDragOver={e => {e.preventDefault(); setIsDragging(true);}}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={e => {e.preventDefault(); setIsDragging(false); if(e.dataTransfer.files?.[0]) handleCsvUpload(e.dataTransfer.files[0]); }}
                      >
                        {!wizFile ? (
                          <>
                            <div className="dz-icon">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                            </div>
                            <div className="dz-title">Drop your test script here</div>
                            <div className="dz-sub">We'll preview the file and map columns on the next step.</div>
                            <label className="btn btn-primary" style={{cursor: 'pointer'}}>
                              Browse Files
                              <input type="file" accept=".csv" hidden onChange={e => e.target.files?.[0] && handleCsvUpload(e.target.files[0])} />
                            </label>
                            <div className="dz-hint">CSV, TSV · max 10 MB</div>
                          </>
                        ) : (
                          <>
                            <div className="file-info">
                              <div className="file-icon">CSV</div>
                              <div>
                                <div className="file-name">{wizFile.name}</div>
                                <div className="file-stat">{wizRawData.length} rows · {wizHeaders.length} columns</div>
                              </div>
                              <label className="file-replace">
                                Replace file
                                <input type="file" accept=".csv" hidden onChange={e => e.target.files?.[0] && handleCsvUpload(e.target.files[0])} />
                              </label>
                            </div>
                            <table className="preview-table">
                              <thead><tr>{wizHeaders.slice(0, 5).map(h => <th key={h}>{h}</th>)}</tr></thead>
                              <tbody>
                                {wizRawData.slice(0, 4).map((row, i) => (
                                  <tr key={i}>{wizHeaders.slice(0, 5).map(h => <td key={h}>{row[h]}</td>)}</tr>
                                ))}
                              </tbody>
                            </table>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  {wizStep === 3 && (
                    <div className="step-panel active">
                      <div className="mapping-grid">
                        <div className="csv-panel">
                          <div className="csv-head">
                            <span className="csv-head-title">{wizFile?.name} · {wizRawData.length} rows</span>
                          </div>
                          <div className="csv-table-wrap">
                            <table className="csv-table">
                              <thead>
                                <tr>
                                  {wizHeaders.map((h, i) => {
                                    const acc = getAccentForCol(h);
                                    return (
                                      <th key={h} className={`${acc ? 'mapped' : ''} ${wizHoverCol === h ? 'highlight' : ''}`} data-accent={acc || undefined}>
                                        <span className="col-letter">{String.fromCharCode(65 + i)}</span>{h}
                                      </th>
                                    );
                                  })}
                                </tr>
                              </thead>
                              <tbody>
                                {wizRawData.slice(0, 6).map((row, idx) => (
                                  <tr key={idx}>
                                    {wizHeaders.map(h => (
                                      <td key={h} data-accent={getAccentForCol(h) || undefined}>{row[h]}</td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        <div className="mappers">
                          {[
                            { k: 'action', label: 'Action Column', req: true, v: wizMap.action },
                            { k: 'expectedResult', label: 'Expected Result', req: true, v: wizMap.expectedResult },
                            { k: 'area', label: 'Area / Module', req: false, v: wizMap.area },
                            { k: 'scenario', label: 'Scenario', req: false, v: wizMap.scenario },
                            { k: 'priority', label: 'Priority', req: false, v: wizMap.priority },
                          ].map((m, idx) => (
                            <div key={m.k} 
                                 className={`mapper ${m.v ? 'mapped' : ''}`} 
                                 data-accent={idx + 1}
                                 onMouseEnter={() => setWizHoverCol(m.v)}
                                 onMouseLeave={() => setWizHoverCol(null)}
                            >
                              <div className="mapper-label">
                                <span className="mapper-name">{m.label}</span>
                                {m.req ? <span className="mapper-req">Required</span> : <span className="mapper-opt">Optional</span>}
                              </div>
                              <select 
                                className="mapper-select" 
                                value={m.v} 
                                onChange={e => { setWizMap({...wizMap, [m.k as keyof typeof wizMap]: e.target.value}); triggerSaved(); }}
                              >
                                <option value="">— Not mapped —</option>
                                {wizHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                              </select>
                              {m.v && wizRawData.length > 0 && (
                                <div className="mapper-preview">
                                  <span className="arrow">↳</span><span className="sample">{wizRawData[0][m.v]}</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {wizStep === 4 && (
                    <div className="step-panel active">
                      <div className="roster-grid">
                        <div>
                          <div className="wiz-field">
                            <div className="wiz-field-label"><span>Add Tester</span><span className="optional">Press Enter</span></div>
                            <div className="add-tester-row">
                              <input className="wiz-input" type="text" placeholder="Name or email..." value={wizTesterInput} onChange={e => setWizTesterInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && addTester()} />
                              <button className="btn btn-primary" onClick={() => addTester()}>Add</button>
                            </div>
                          </div>
                          
                          {uniqueTestersList.length > 0 && (
                            <div className="recent-testers">
                              <div className="recent-label">Recently on your team</div>
                              <div className="recent-chips">
                                {uniqueTestersList.slice(0, 6).map((t, i) => {
                                  const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
                                  const c = colors[i % colors.length];
                                  return (
                                    <span key={t} className="recent-chip" onClick={() => addTester(t)}>
                                      <span className="mini-avatar" style={{background: c}}>{t.charAt(0)}</span>
                                      {t} <span className="plus">+</span>
                                    </span>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="roster-panel">
                          <div className="roster-head"><span>Team Roster</span><span>{wizTesters.length} added</span></div>
                          <div className="roster-list">
                            {wizTesters.length === 0 ? (
                              <div className="roster-empty">No testers yet — you can also skip this and assign later from the project page.</div>
                            ) : (
                              wizTesters.map(t => (
                                <div className="roster-item" key={t.name}>
                                  <div className="roster-avatar" style={{background: t.color}}>{t.name.charAt(0).toUpperCase()}</div>
                                  <div className="roster-name">{t.name}</div>
                                  <button className="roster-remove" onClick={() => removeTester(t.name)}>
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                                  </button>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {wizStep === 5 && (
                    <div className="step-panel active">
                      <div className="launch-celebration" id="confetti-root" ref={confettiContainerRef}>
                        <div className="launch-icon-wrap">
                          <svg className="launch-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <h2 className="launch-title">Project Launched</h2>
                        <p className="launch-sub">Your UAT cycle is ready. Testers will see it in their dashboard shortly.</p>
                        <div className="launch-summary">
                          <div className="launch-cell"><div className="lc-label">Project</div><div className="lc-value">{wizName}</div></div>
                          <div className="launch-cell"><div className="lc-label">Tests</div><div className="lc-value">{wizRawData.length}</div></div>
                          <div className="launch-cell"><div className="lc-label">Testers</div><div className="lc-value">{wizTesters.length || '—'}</div></div>
                          <div className="launch-cell"><div className="lc-label">Status</div><div className="lc-value" style={{color: 'var(--pass)'}}>Ready</div></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {wizStep < 5 ? (
                  <footer className={`content-foot ${wizStep === 4 ? 'crowded' : ''}`}>
                    <div className="foot-hint">
                      <span className={`saved-indicator ${wizSaved ? 'show' : ''}`}><span className="saved-dot"></span> Saved</span>
                      <span><kbd>Enter</kbd> continue</span>
                      <span><kbd>Esc</kbd> close</span>
                    </div>
                    <div className="foot-actions">
                      <button className="btn btn-ghost" onClick={() => setWizStep(prev => prev - 1)} style={{visibility: wizStep > 1 ? 'visible' : 'hidden'}}>← Back</button>
                      {wizStep === 4 && <button className="btn btn-ghost" onClick={launchProject} disabled={isLaunching}>Skip</button>}
                      <button 
                        className="btn btn-primary" 
                        disabled={!canAdvance() || isLaunching}
                        onClick={() => wizStep === 4 ? launchProject() : setWizStep(prev => prev + 1)}
                      >
                        {isLaunching ? 'Creating...' : wizStep === 4 ? 'Launch Project' : 'Next Step →'}
                      </button>
                    </div>
                  </footer>
                ) : (
                  <footer className="content-foot" style={{justifyContent: 'center'}}>
                    <button className="btn btn-primary" onClick={() => { closeWizard(); router.push('/admin'); }}>View Links & Dashboard →</button>
                  </footer>
                )}
              </div>
            </div>
          </div>
        </>
      )}

    </div>
  );
}