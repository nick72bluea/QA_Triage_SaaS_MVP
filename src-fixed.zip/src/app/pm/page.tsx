"use client";

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Box, Dialog, DialogTitle, DialogContent, DialogActions, Button, 
  Typography, TextField, CircularProgress, Chip, IconButton
} from '@mui/material';
import { QRCodeSVG } from 'qrcode.react';
import { collection, onSnapshot, doc, updateDoc, deleteDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/lib/firebase';
import { TestStep, TestResult, TestRunData } from '@/types';
import Papa from 'papaparse';

interface ExtendedTestResult extends TestResult { isTriaged?: boolean; }

const getMediaType = (url: string) => {
  const lowerUrl = url.toLowerCase();
  if (lowerUrl.match(/\.(mp4|webm|ogg|mov)(?=\?|$)/i)) return 'video';
  if (lowerUrl.match(/\.(pdf)(?=\?|$)/i)) return 'pdf';
  return 'image'; 
};

export default function PMTriageDashboard() {
  const [testRuns, setTestRuns] = useState<TestRunData[]>([]);
  const [reviews, setReviews] = useState<Record<string, 'Approved' | 'Rejected' | 'Pending'>>({});
  const [uploadingStep, setUploadingStep] = useState<string | null>(null);

  // Filters
  const [filterProject, setFilterProject] = useState<string>('All projects');
  const [filterCycle, setFilterCycle] = useState<string>('All cycles');
  const [filterTester, setFilterTester] = useState<string>('All testers');
  const [panelFilter, setPanelFilter] = useState<'All' | 'Failed' | 'Pending' | 'Passed'>('All');

  // Viewers & Modals
  const [activeRun, setActiveRun] = useState<TestRunData | null>(null);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [activeMediaUrls, setActiveMediaUrls] = useState<string[]>([]);
  const [activeMediaIndex, setActiveMediaIndex] = useState<number>(0);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [uploadToken, setUploadToken] = useState('');
  const [uploadUrl, setUploadUrl] = useState('');
  const [qrTarget, setQrTarget] = useState<{runId: string, stepId: string, currentResult: ExtendedTestResult | undefined} | null>(null);

  const [selectedBugs, setSelectedBugs] = useState<string[]>([]);
  const [jiraModalOpen, setJiraModalOpen] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [jiraDrafts, setJiraDrafts] = useState<any[]>([]);

  // ==========================================
  // NEW WIZARD STATES
  // ==========================================
  const [wizOpen, setWizOpen] = useState(false);
  const [wizStep, setWizStep] = useState(1);
  const [wizSaved, setWizSaved] = useState(false);
  
  const [wizName, setWizName] = useState('');
  const [wizEnv, setWizEnv] = useState('');
  const [wizCycle, setWizCycle] = useState('');
  
  const [isDragging, setIsDragging] = useState(false);
  const [wizFile, setWizFile] = useState<File | null>(null);
  const [wizHeaders, setWizHeaders] = useState<string[]>([]);
  const [wizRawData, setWizRawData] = useState<any[]>([]);

  const [wizMap, setWizMap] = useState({ action: '', expectedResult: '', area: '', scenario: '', priority: '' });
  const [wizHoverCol, setWizHoverCol] = useState<string | null>(null);
  
  const [wizTesterInput, setWizTesterInput] = useState('');
  const [wizTesters, setWizTesters] = useState<{name: string, color: string}[]>([]);
  
  const [isLaunching, setIsLaunching] = useState(false);
  const confettiContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'testRuns'), (snapshot) => {
      const runsData = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as TestRunData[];
      runsData.sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));
      setTestRuns(runsData);
      setActiveRun(prev => prev ? runsData.find(r => r.id === prev.id) || null : null);
    });
    return () => unsubscribe();
  }, []);

  const uniqueTestersList = useMemo(() => Array.from(new Set(testRuns.map(r => r.testerName).filter(n => n !== 'Unassigned'))), [testRuns]);

  // --- WIZARD LOGIC ---
  const triggerSaved = () => {
    setWizSaved(true);
    setTimeout(() => setWizSaved(false), 1500);
  };

  const handleCsvUpload = (file: File) => {
    setWizFile(file);
    Papa.parse(file, {
      header: true, skipEmptyLines: true,
      complete: (results) => { 
        const headers = results.meta.fields || [];
        setWizHeaders(headers); 
        setWizRawData(results.data); 
        
        // Auto-detect attempt
        const newMap = { action: '', expectedResult: '', area: '', scenario: '', priority: '' };
        headers.forEach(h => {
          const l = h.toLowerCase();
          if (l.includes('action') || l.includes('step')) newMap.action = h;
          if (l.includes('expect')) newMap.expectedResult = h;
          if (l.includes('module') || l.includes('area')) newMap.area = h;
          if (l.includes('scenario')) newMap.scenario = h;
          if (l.includes('prior') || l.includes('sever')) newMap.priority = h;
        });
        setWizMap(newMap);
        triggerSaved();
        setWizStep(3); // Auto advance
      }
    });
  };

  const removeTester = (name: string) => {
    setWizTesters(prev => prev.filter(t => t.name !== name));
    triggerSaved();
  };

  const addTester = (nameOverride?: string) => {
    const name = (nameOverride || wizTesterInput).trim();
    if (!name) return;
    if (!wizTesters.some(t => t.name === name)) {
      const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
      const color = colors[wizTesters.length % colors.length];
      setWizTesters([...wizTesters, { name, color }]);
    }
    setWizTesterInput('');
    triggerSaved();
  };

  const launchProject = async () => {
    setIsLaunching(true);
    try {
      const mappedSteps: TestStep[] = wizRawData.map((row: any, index: number) => ({
        id: `step_${index + 1}`,
        action: row[wizMap.action] || 'Missing Action',
        expectedResult: row[wizMap.expectedResult] || 'Missing Expected Result',
        area: wizMap.area ? row[wizMap.area] : '',
        scenario: wizMap.scenario ? row[wizMap.scenario] : '',
        priority: wizMap.priority ? row[wizMap.priority] : '',
        mediaUrls: [], referenceLinks: []
      }));

      const targetTesters = wizTesters.length > 0 ? wizTesters.map(t => t.name) : ['Unassigned'];
      const testRunsCollection = collection(db, 'testRuns');

      for (const name of targetTesters) {
        await addDoc(testRunsCollection, {
          projectName: wizName, testerName: name, environment: wizEnv,
          testCycle: wizCycle, steps: mappedSteps, createdAt: serverTimestamp(), results: {} 
        });
      }
      
      setWizStep(5);
      triggerConfetti();
    } catch (error) {
      alert("Failed to launch project.");
    } finally {
      setIsLaunching(false);
    }
  };

  const triggerConfetti = () => {
    if (!confettiContainerRef.current) return;
    const colors = ['#4a7c59', '#3d5a80', '#b8860b', '#a6421f', '#6a4a7c'];
    const waves = [{ c: 25, d: 400 }, { c: 18, d: 1200 }, { c: 14, d: 2200 }];
    
    waves.forEach(w => {
      setTimeout(() => {
        for (let i = 0; i < w.c; i++) {
          const el = document.createElement('div');
          el.className = 'confetti fire';
          el.style.background = colors[Math.floor(Math.random() * colors.length)];
          el.style.left = 50 + (Math.random() - 0.5) * 90 + '%';
          el.style.top = '40px';
          el.style.width = 7 + Math.random() * 5 + 'px';
          el.style.height = 11 + Math.random() * 7 + 'px';
          el.style.animationDelay = Math.random() * 0.5 + 's';
          el.style.animationDuration = 3.5 + Math.random() * 2 + 's';
          confettiContainerRef.current?.appendChild(el);
          setTimeout(() => el.remove(), 6500);
        }
      }, w.d);
    });
  };

  const closeWizard = () => {
    setWizOpen(false);
    setTimeout(() => {
      setWizStep(1); setWizName(''); setWizEnv(''); setWizCycle('');
      setWizFile(null); setWizHeaders([]); setWizRawData([]); setWizTesters([]);
    }, 300);
  };

  const canAdvance = () => {
    if (wizStep === 1) return !!wizName;
    if (wizStep === 2) return !!wizFile;
    if (wizStep === 3) return !!wizMap.action && !!wizMap.expectedResult;
    return true;
  };

  const getAccentForCol = (colName: string) => {
    if (wizMap.action === colName) return 1;
    if (wizMap.expectedResult === colName) return 2;
    if (wizMap.area === colName) return 3;
    if (wizMap.scenario === colName) return 4;
    if (wizMap.priority === colName) return 5;
    return null;
  };

  // --- PM ACTIONS ---
  const handleReview = (runId: string, stepId: string, decision: 'Approved' | 'Rejected') => setReviews(prev => ({ ...prev, [`${runId}_${stepId}`]: decision }));
  const handleBatchAction = (decision: 'Approved' | 'Rejected') => {
    const newReviews = { ...reviews };
    selectedBugs.forEach(key => { newReviews[key] = decision; });
    setReviews(newReviews); setSelectedBugs([]); 
  };
  const toggleSelection = (key: string) => setSelectedBugs(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]);

  const handlePMFileUpload = async (runId: string, stepId: string, currentResult: ExtendedTestResult | undefined, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingStep(`${runId}_${stepId}`);
    try {
      const storageRef = ref(storage, `pm_evidence/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);
      await updateDoc(doc(db, 'testRuns', runId), { [`results.${stepId}.evidenceUrls`]: [...(currentResult?.evidenceUrls || []), downloadURL] });
    } catch (error) { alert("Failed to attach file."); } finally { setUploadingStep(null); }
  };

  const openPMQrScanner = (runId: string, stepId: string, currentResult: ExtendedTestResult | undefined) => {
    const token = Math.random().toString(36).substring(2, 15);
    setUploadToken(token); setQrTarget({ runId, stepId, currentResult });
    setUploadUrl(`${window.location.origin}/mobile-upload/${token}`); setQrModalOpen(true);
  };

  useEffect(() => {
    if (!qrModalOpen || !uploadToken || !qrTarget) return;
    const docRef = doc(db, 'mobileUploads', uploadToken);
    const unsubscribe = onSnapshot(docRef, async (docSnap) => {
      if (docSnap.exists() && docSnap.data().url) {
        try { await updateDoc(doc(db, 'testRuns', qrTarget.runId), { [`results.${qrTarget.stepId}.evidenceUrls`]: [...(qrTarget.currentResult?.evidenceUrls || []), docSnap.data().url] }); } catch (err) {}
        deleteDoc(docRef).catch(console.error); setQrModalOpen(false); setQrTarget(null);
      }
    });
    return () => unsubscribe();
  }, [qrModalOpen, uploadToken, qrTarget]);

  const prepareJiraDrafts = () => {
    const drafts = [];
    for (const [key, decision] of Object.entries(reviews)) {
      if (decision === 'Approved') {
        const [runId, stepId] = key.split('_');
        const run = testRuns.find(r => r.id === runId);
        const step = run?.steps.find(s => s.id === stepId);
        const result = run?.results?.[stepId] as ExtendedTestResult;
        if (run && step && result && !result.isTriaged) {
          drafts.push({
            id: key, runId, stepId, projectName: run.projectName, action: step.action, notes: result.notes || '', 
            expectedResult: step.expectedResult, evidenceUrls: result.evidenceUrls,
            environment: run.deviceInfo ? `${run.deviceInfo.device} - ${run.deviceInfo.browser}` : 'Unknown'
          });
        }
      }
    }
    setJiraDrafts(drafts); setJiraModalOpen(true);
  };

  const confirmPushToJira = async () => {
    setIsPushing(true);
    try {
      const response = await fetch('/api/jira', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bugs: jiraDrafts }) });
      if (response.ok) { 
        for (const draft of jiraDrafts) { await updateDoc(doc(db, 'testRuns', draft.runId), { [`results.${draft.stepId}.isTriaged`]: true }); }
        alert(`Successfully pushed bugs to Jira!`); setReviews({}); setJiraModalOpen(false); setActiveRun(null);
      } 
    } catch (error) { alert("Network error occurred."); } finally { setIsPushing(false); }
  };

  const openViewer = (urls: string[], startIndex: number) => { setActiveMediaUrls(urls); setActiveMediaIndex(startIndex); setViewerOpen(true); };

  // --- DATA AGGREGATION ---
  const uniqueProjects = useMemo(() => ['All projects', ...Array.from(new Set(testRuns.map(r => r.projectName)))], [testRuns]);
  const uniqueCycles = useMemo(() => ['All cycles', ...Array.from(new Set(testRuns.map(r => r.testCycle).filter(Boolean)))], [testRuns]);
  const uniqueTesters = useMemo(() => ['All testers', ...Array.from(new Set(testRuns.map(r => r.testerName)))], [testRuns]);

  const filteredRuns = useMemo(() => {
    return testRuns.filter(run => 
      (filterProject === 'All projects' || run.projectName === filterProject) && 
      (filterCycle === 'All cycles' || run.testCycle === filterCycle) &&
      (filterTester === 'All testers' || run.testerName === filterTester)
    );
  }, [testRuns, filterProject, filterCycle, filterTester]);

  const stats = useMemo(() => {
    let projectsCount = new Set(filteredRuns.map(r => r.projectName)).size;
    let inProgressProjects = new Set(filteredRuns.filter(r => !r.isCompleted).map(r => r.projectName)).size;
    let completeProjects = new Set(filteredRuns.filter(r => r.isCompleted).map(r => r.projectName)).size;
    
    let totalSteps = 0, completedSteps = 0, passed = 0, failed = 0, pendingTriage = 0;
    filteredRuns.forEach(run => {
      totalSteps += (run.steps?.length || 0);
      run.steps?.forEach(step => {
        const result = run.results?.[step.id] as ExtendedTestResult;
        if (result) {
          completedSteps++;
          if (result.status === 'Passed') passed++;
          if (result.status === 'Failed') { failed++; if (!result.isTriaged) pendingTriage++; }
        }
      });
    });

    const completionPct = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;
    const passedPct = totalSteps > 0 ? (passed / totalSteps) * 100 : 0;
    const failedPct = totalSteps > 0 ? (failed / totalSteps) * 100 : 0;
    const pendingPct = totalSteps > 0 ? ((totalSteps - completedSteps) / totalSteps) * 100 : 0;

    return { 
      projectsCount, inProgressProjects, completeProjects, 
      totalSteps, completedSteps, remainingSteps: totalSteps - completedSteps, 
      passed, failed, pendingTriage, completionPct, passedPct, failedPct, pendingPct 
    };
  }, [filteredRuns]);

  const runsNeedsAttention = filteredRuns.filter(run => run.steps.some(s => run.results?.[s.id]?.status === 'Failed' && !(run.results?.[s.id] as ExtendedTestResult)?.isTriaged));
  const runsInProgress = filteredRuns.filter(run => !run.isCompleted && !runsNeedsAttention.includes(run));
  const runsCompleted = filteredRuns.filter(run => run.isCompleted && !runsNeedsAttention.includes(run));

  const renderRow = (run: TestRunData, statusClass: string, statusLabel: string) => {
    const comp = Object.keys(run.results || {}).length;
    const tot = run.steps?.length || 0;
    const pct = tot > 0 ? (comp / tot) * 100 : 0;
    const failedCount = run.steps.filter(s => run.results?.[s.id]?.status === 'Failed' && !(run.results?.[s.id] as ExtendedTestResult)?.isTriaged).length;

    return (
      <div key={run.id} className={`project-row ${statusClass}`} onClick={() => setActiveRun(run)}>
        <div className="project-left">
          <div className="project-head">
            <span className="project-name">{run.projectName}</span>
            {run.testCycle && <span className="tag">{run.testCycle}</span>}
            {!run.deviceInfo && <span className="tag muted">Device pending</span>}
          </div>
          <div className="project-meta">
            <span><strong>{run.testerName}</strong></span>
            {run.deviceInfo ? <span>{run.deviceInfo.device} · {run.deviceInfo.os} · {run.deviceInfo.browser}</span> : <span>Device specs pending</span>}
            {failedCount > 0 && <span>{failedCount} failure{failedCount > 1 ? 's' : ''}</span>}
          </div>
        </div>
        <div className="project-right">
          <span className={`status-badge ${statusClass}`}><span className="pulse"></span> {statusLabel}</span>
          <div className="progress-row">
            <div className="progress-track">
              <div className="progress-fill" style={{ width: '100%' }}>
                <div className={statusClass === 'status-fail' ? 'bar-fail' : statusClass === 'status-pass' ? 'bar-pass' : 'bar-info'} style={{ flex: pct }}></div>
                <div style={{ flex: 100 - pct, background: 'transparent' }}></div>
              </div>
            </div>
            <span className="progress-label">{comp} / {tot}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Box className="triage-v2">
      {/* CRITICAL FIX: By applying these variables to :root, they survive the React Portal teleportation! 
        This guarantees the Dialog modal gets access to your exact colors, radii, and layouts.
      */}
      <style dangerouslySetInnerHTML={{__html: `
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        
        :root, .triage-v2, .wiz-modal-wrapper {
          --bg: #f4f3ef; --surface: #ffffff; --surface-alt: #fafaf7;
          --ink: #1a1a1a; --ink-soft: #55524d; --ink-mute: #8a867f;
          --line: #e5e2db; --line-strong: #d4d0c7;
          --accent: #2d4a3e; --accent-soft: #e8f0eb; --accent-ink: #1d3329;
          --sidebar: #121a17; --sidebar-ink: #e5e2db; --sidebar-mute: #7a7a72;
          --rail: #121a17; --rail-ink: #e5e2db; --rail-mute: #7a7a72;
          --pass: #4a7c59; --pass-soft: #e8f0eb;
          --fail: #a6421f; --fail-soft: #f7e8e2;
          --warn: #b8860b; --warn-soft: #f9f0da;
          --info: #3d5a80; --info-soft: #e5ecf2;
          --radius: 6px;
          --m1: #3d5a80; --m2: #a6421f; --m3: #b8860b; --m4: #6a4a7c; --m5: #4a7c59;
        }

        .triage-v2, .wiz-modal-wrapper {
          font-family: 'IBM Plex Sans', system-ui, sans-serif;
          color: var(--ink); font-size: 14px;
        }
        
        .triage-v2 * { box-sizing: border-box; }
        .app { display: grid; grid-template-columns: 240px 1fr; min-height: 100vh; }

        /* ---------- SIDEBAR ---------- */
        .sidebar { background: var(--sidebar); color: var(--sidebar-ink); display: flex; flex-direction: column; padding: 20px 16px; position: sticky; top: 0; height: 100vh; z-index: 10; }
        .brand { display: flex; align-items: center; gap: 10px; padding: 4px 8px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px; }
        .brand-mark { width: 32px; height: 32px; background: var(--accent); border-radius: var(--radius); display: flex; align-items: center; justify-content: center; color: #fff; }
        .brand-name { font-family: 'Fraunces', serif; font-size: 17px; font-weight: 600; letter-spacing: -0.01em; }
        .nav { display: flex; flex-direction: column; gap: 2px; }
        .nav-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; color: var(--sidebar-mute); text-decoration: none; border-radius: var(--radius); font-size: 13px; font-weight: 500; cursor: pointer; transition: background 0.15s ease, color 0.15s ease; }
        .nav-item:hover { color: var(--sidebar-ink); background: rgba(255,255,255,0.04); }
        .nav-item.active { background: rgba(255,255,255,0.08); color: var(--sidebar-ink); }
        .nav-item svg { flex-shrink: 0; }
        .sidebar-foot { margin-top: auto; display: flex; flex-direction: column; gap: 10px; }
        .issues-pill { display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px; background: var(--fail); color: #fff; border-radius: 999px; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 500; width: fit-content; }
        .user-card { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: rgba(255,255,255,0.04); border-radius: var(--radius); }
        .avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; color: #fff; }
        .user-name { font-size: 13px; font-weight: 500; color: var(--sidebar-ink); }
        .user-role { font-size: 10px; color: var(--sidebar-mute); font-family: 'JetBrains Mono', monospace; text-transform: uppercase; letter-spacing: 0.08em; }

        /* ---------- MAIN CONTENT ---------- */
        .main { padding: 32px 40px; max-width: 1400px; width: 100%; margin: 0 auto; }
        .page-head { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; gap: 20px; }
        .page-title { font-family: 'Fraunces', serif; font-size: 32px; font-weight: 600; letter-spacing: -0.02em; margin: 0 0 4px; color: var(--ink); }
        .page-sub { color: var(--ink-mute); font-size: 13px; margin: 0; }
        .page-eyebrow { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 6px; }

        .head-actions { display: flex; gap: 8px; }
        .btn { height: 38px; padding: 0 16px; font-family: inherit; font-size: 13px; font-weight: 500; border-radius: var(--radius); cursor: pointer; transition: all 0.15s ease; border: 1px solid transparent; display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; }
        .btn-ghost { background: transparent; border-color: var(--line-strong); color: var(--ink-soft); }
        .btn-ghost:hover:not(:disabled) { background: var(--surface); color: var(--ink); }
        .btn-ghost:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-primary { background: var(--accent); color: #fff; }
        .btn-primary:hover:not(:disabled) { background: var(--accent-ink); }
        .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-secondary { background: var(--surface); border-color: var(--line-strong); color: var(--ink-soft); }
        .btn-secondary:hover { background: var(--surface-alt); color: var(--ink); }

        .stats-row { display: grid; grid-template-columns: 1.5fr 1fr 1fr; gap: 12px; margin-bottom: 24px; }
        @media (max-width: 1100px) { .stats-row { grid-template-columns: 1fr; } }
        .stat-card { background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius); padding: 18px 20px; }
        .stat-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 10px; }
        .stat-big { display: flex; align-items: baseline; gap: 6px; }
        .stat-value { font-family: 'Fraunces', serif; font-size: 34px; font-weight: 600; line-height: 1; letter-spacing: -0.02em; color: var(--ink); }
        .stat-unit { font-size: 12px; color: var(--ink-mute); }
        
        .stat-results .segmented-bar { display: flex; height: 8px; border-radius: 999px; overflow: hidden; background: var(--line); margin-top: 14px; margin-bottom: 12px; }
        .segmented-bar > span { display: block; height: 100%; transition: width 0.5s ease; }
        .seg-pass { background: var(--pass); } .seg-fail { background: var(--fail); } .seg-pend { background: var(--line-strong); }
        .legend { display: flex; gap: 16px; font-size: 12px; }
        .legend-item { display: flex; align-items: center; gap: 6px; color: var(--ink-soft); }
        .legend-dot { width: 8px; height: 8px; border-radius: 50%; }
        .dot-pass { background: var(--pass); } .dot-fail { background: var(--fail); } .dot-pend { background: var(--line-strong); }
        .legend-item b { font-weight: 600; color: var(--ink); font-variant-numeric: tabular-nums; }

        .stat-breakdown { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-top: 14px; }
        .breakdown-item .bd-label { font-size: 11px; color: var(--ink-mute); margin-bottom: 2px; }
        .breakdown-item .bd-value { font-family: 'Fraunces', serif; font-size: 20px; font-weight: 600; font-variant-numeric: tabular-nums; color: var(--ink); }

        .toolbar { display: flex; align-items: center; gap: 12px; background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius); padding: 10px 14px; margin-bottom: 20px; flex-wrap: wrap; }
        .toolbar-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); font-weight: 500; }
        .search { position: relative; flex: 1; min-width: 220px; }
        .search input { width: 100%; height: 34px; padding: 0 12px 0 34px; border: 1px solid var(--line); border-radius: var(--radius); background: var(--surface-alt); font-family: inherit; font-size: 13px; color: var(--ink); }
        .search input:focus { outline: none; border-color: var(--accent); background: var(--surface); box-shadow: 0 0 0 3px rgba(45,74,62,0.1); }
        .search svg { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); color: var(--ink-mute); }
        .select-compact { height: 34px; padding: 0 28px 0 12px; font-family: inherit; font-size: 13px; color: var(--ink-soft); background: var(--surface-alt); border: 1px solid var(--line); border-radius: var(--radius); cursor: pointer; appearance: none; background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2355524d' stroke-width='2'%3e%3cpolyline points='6 9 12 15 18 9'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 10px center; }
        .select-compact:focus { outline: none; border-color: var(--accent); }

        .project-list { display: flex; flex-direction: column; gap: 8px; margin-bottom: 32px; }
        .section-heading { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin: 0 0 12px; display: flex; align-items: center; gap: 10px; }
        .section-heading::after { content: ''; flex: 1; height: 1px; background: var(--line); }
        .section-heading .count { background: var(--surface); border: 1px solid var(--line); padding: 2px 8px; border-radius: 999px; color: var(--ink-soft); }

        .project-row { background: var(--surface); border: 1px solid var(--line); border-left: 3px solid var(--line-strong); border-radius: var(--radius); padding: 16px 20px; display: grid; grid-template-columns: 1fr auto; gap: 20px; align-items: center; cursor: pointer; transition: border-color 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease; }
        .project-row:hover { border-color: var(--line-strong); box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
        .project-row.status-pass { border-left-color: var(--pass); }
        .project-row.status-fail { border-left-color: var(--fail); }
        .project-row.status-pend { border-left-color: var(--warn); }
        .project-row.status-run  { border-left-color: var(--info); }
        
        .project-left { min-width: 0; }
        .project-head { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; flex-wrap: wrap; }
        .project-name { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; letter-spacing: -0.01em; color: var(--ink); }
        .tag { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 2px 8px; border-radius: 4px; background: var(--info-soft); color: var(--info); }
        .tag.muted { background: var(--line); color: var(--ink-mute); }
        .project-meta { display: flex; gap: 14px; color: var(--ink-mute); font-size: 12px; flex-wrap: wrap; }
        .project-meta > span { display: inline-flex; align-items: center; gap: 5px; }
        .project-meta strong { font-weight: 500; color: var(--ink-soft); }

        .project-right { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; min-width: 180px; }
        .status-badge { display: inline-flex; align-items: center; gap: 6px; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.1em; padding: 4px 10px; border-radius: 999px; }
        .status-pass  { background: var(--pass-soft); color: var(--pass); }
        .status-fail  { background: var(--fail-soft); color: var(--fail); }
        .status-pend  { background: var(--warn-soft); color: var(--warn); }
        .status-run   { background: var(--info-soft); color: var(--info); }
        .status-badge .pulse { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }

        .progress-row { display: flex; align-items: center; gap: 10px; width: 220px; }
        .progress-track { flex: 1; height: 6px; background: var(--line); border-radius: 999px; overflow: hidden; display: flex; }
        .progress-fill { height: 100%; display: flex; }
        .progress-fill .bar-pass { background: var(--pass); }
        .progress-fill .bar-fail { background: var(--fail); }
        .progress-fill .bar-pend { background: var(--warn); }
        .progress-fill .bar-info { background: var(--info); }
        .progress-label { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-soft); font-variant-numeric: tabular-nums; }

        /* ---------- EXPANDED SIDE PANEL LOGIC ---------- */
        .panel-overlay { position: fixed; inset: 0; background: rgba(20, 20, 20, 0.4); opacity: 0; pointer-events: none; transition: opacity 0.2s ease; z-index: 1200; }
        .panel-overlay.open { opacity: 1; pointer-events: auto; }
        
        .side-panel { 
          position: fixed; top: 0; right: 0; height: 100vh; 
          width: 50vw; min-width: 600px; max-width: 1000px;
          background: var(--surface); border-left: 1px solid var(--line-strong); 
          box-shadow: -12px 0 40px rgba(0,0,0,0.08); 
          transform: translateX(100%); transition: transform 0.25s cubic-bezier(.4,.0,.2,1); 
          display: flex; flex-direction: column; z-index: 1300; 
        }
        .side-panel.open { transform: translateX(0); }
        @media (max-width: 900px) { .side-panel { width: 100vw; min-width: 100vw; } .app { grid-template-columns: 1fr; } .sidebar { display: none; } }

        .panel-head { padding: 20px 24px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; }
        .panel-title { font-family: 'Fraunces', serif; font-size: 22px; font-weight: 600; margin: 0 0 4px; letter-spacing: -0.01em; color: var(--ink); }
        .panel-sub { color: var(--ink-mute); font-size: 12px; margin: 0; display: flex; gap: 10px; flex-wrap: wrap; }
        .close-btn { width: 32px; height: 32px; border: 1px solid var(--line); background: var(--surface); border-radius: var(--radius); cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--ink-soft); }
        .close-btn:hover { background: var(--bg); color: var(--ink); }

        .panel-summary { padding: 16px 24px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; border-bottom: 1px solid var(--line); background: var(--surface-alt); }
        .summary-cell .sc-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 2px; }
        .summary-cell .sc-value { font-family: 'Fraunces', serif; font-size: 20px; font-weight: 600; font-variant-numeric: tabular-nums; color: var(--ink); }
        .sc-value.pass { color: var(--pass); } .sc-value.fail { color: var(--fail); } .sc-value.pend { color: var(--warn); }

        .panel-toolbar { padding: 12px 24px; display: flex; gap: 10px; align-items: center; border-bottom: 1px solid var(--line); flex-wrap: wrap; }
        .filter-chip { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 5px 10px; border: 1px solid var(--line-strong); background: var(--surface); color: var(--ink-soft); border-radius: 999px; cursor: pointer; transition: all 0.1s ease; }
        .filter-chip.active { background: var(--ink); color: #fff; border-color: var(--ink); }
        .filter-chip:hover:not(.active) { background: var(--bg); }

        .panel-body { flex: 1; overflow-y: auto; padding: 8px 0; }
        .test-item { padding: 16px 24px; border-bottom: 1px solid var(--line); display: grid; grid-template-columns: auto 1fr auto auto; gap: 14px; align-items: flex-start; }
        .test-item:hover { background: var(--surface-alt); }

        .test-checkbox { width: 16px; height: 16px; border: 1.5px solid var(--line-strong); border-radius: 3px; margin-top: 3px; cursor: pointer; background: var(--surface); }
        .test-checkbox.checked { background: var(--accent); border-color: var(--accent); position: relative; }
        .test-checkbox.checked::after { content: ''; position: absolute; left: 4px; top: 1px; width: 4px; height: 8px; border: solid white; border-width: 0 2px 2px 0; transform: rotate(45deg); }

        .test-content .test-id { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 4px; }
        .test-action { font-size: 14px; font-weight: 500; color: var(--ink); margin-bottom: 4px; }
        .test-expected { font-size: 12px; color: var(--ink-mute); display: flex; gap: 6px; }
        .test-expected::before { content: '→'; color: var(--ink-mute); font-family: 'JetBrains Mono', monospace; }
        .test-note { margin-top: 8px; padding: 8px 10px; background: var(--fail-soft); border-left: 2px solid var(--fail); border-radius: 3px; font-size: 12px; color: var(--ink-soft); }

        .test-status { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; min-width: 100px; }
        .evidence-row { display: flex; gap: 6px; align-items: center; }
        .evidence-chip { display: inline-flex; align-items: center; gap: 4px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-soft); background: var(--bg); padding: 3px 7px; border-radius: 4px; border: 1px solid var(--line); cursor: pointer; }
        .evidence-chip:hover { border-color: var(--accent); }
        .evidence-add { font-size: 11px; color: var(--ink-mute); text-decoration: underline; text-underline-offset: 2px; cursor: pointer; }
        .evidence-add:hover { color: var(--accent); }

        .triage-actions { display: flex; gap: 4px; }
        .triage-btn { width: 28px; height: 28px; border: 1px solid var(--line-strong); background: var(--surface); border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--ink-mute); transition: all 0.15s ease; }
        .triage-btn:hover.approve { background: var(--pass-soft); color: var(--pass); border-color: var(--pass); }
        .triage-btn:hover.reject { background: var(--fail-soft); color: var(--fail); border-color: var(--fail); }

        .panel-foot { padding: 14px 24px; border-top: 1px solid var(--line); background: var(--surface-alt); display: flex; justify-content: space-between; align-items: center; }
        .bulk-label { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-mute); }

        /* ==========================================
           WIZARD STYLES (PORTAL-SAFE)
           ========================================== */
        .wiz-modal-wrapper * { box-sizing: border-box; }
        .wiz-modal { width: 720px; max-width: 100%; max-height: calc(100vh - 48px); background: var(--surface); border: 1px solid var(--line-strong); border-radius: 10px; box-shadow: 0 30px 60px -12px rgba(0,0,0,0.25), 0 2px 4px rgba(0,0,0,0.04); display: grid; grid-template-columns: 200px 1fr; overflow: hidden; transition: width 0.4s cubic-bezier(.4,.0,.2,1); }
        .wiz-modal.expanded { width: 1180px; }
        @media (max-width: 900px) { .wiz-modal { grid-template-columns: 1fr; } .rail { display: none !important; } .step1-grid, .mapping-grid, .roster-grid { grid-template-columns: 1fr !important; } .wiz-modal.expanded { width: 100%; } }

        .rail { background: var(--rail); color: var(--rail-ink); padding: 24px 18px; display: flex; flex-direction: column; gap: 20px; position: relative; overflow: hidden; }
        .rail::after { content: ''; position: absolute; inset: 0; background: radial-gradient(circle at 20% 100%, rgba(74,124,89,0.15) 0, transparent 60%); pointer-events: none; }
        .rail-brand { font-family: 'Fraunces', serif; font-size: 16px; font-weight: 600; letter-spacing: -0.01em; position: relative; z-index: 1; }
        .rail-brand .eyebrow { display: block; font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--rail-mute); margin-bottom: 4px; font-weight: 500; }
        .rail-progress { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--rail-mute); text-transform: uppercase; letter-spacing: 0.12em; display: flex; justify-content: space-between; position: relative; z-index: 1; }
        .rail-bar { height: 2px; background: rgba(255,255,255,0.08); border-radius: 1px; overflow: hidden; position: relative; z-index: 1; }
        .rail-bar-fill { height: 100%; background: linear-gradient(90deg, var(--pass), #7ab28a); transition: width 0.4s cubic-bezier(.4,.0,.2,1); }
        .rail-steps { display: flex; flex-direction: column; gap: 2px; position: relative; z-index: 1; }
        .rail-step { display: flex; align-items: flex-start; gap: 10px; padding: 10px 8px; border-radius: 6px; cursor: pointer; transition: background 0.15s ease; }
        .rail-step:hover { background: rgba(255,255,255,0.04); }
        .rail-step.locked { cursor: not-allowed; opacity: 0.5; }
        .rail-step.locked:hover { background: transparent; }
        .step-dot { width: 22px; height: 22px; border-radius: 50%; background: rgba(255,255,255,0.08); color: var(--rail-mute); display: flex; align-items: center; justify-content: center; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 500; flex-shrink: 0; margin-top: 1px; transition: all 0.2s ease; }
        .rail-step.active .step-dot { background: var(--pass); color: #fff; box-shadow: 0 0 0 3px rgba(74,124,89,0.25); }
        .rail-step.done .step-dot { background: transparent; color: var(--pass); border: 1px solid var(--pass); }
        .step-text { min-width: 0; flex: 1; }
        .step-name { font-size: 12px; font-weight: 500; color: var(--rail-ink); }
        .rail-step.locked .step-name { color: var(--rail-mute); }
        .step-value { font-size: 11px; color: var(--rail-mute); margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-family: 'JetBrains Mono', monospace; }
        .rail-step.done .step-value { color: #9fb5a7; }
        .rail-foot { margin-top: auto; padding-top: 16px; border-top: 1px solid rgba(255,255,255,0.08); position: relative; z-index: 1; }
        .rail-tip { font-size: 11px; color: var(--rail-mute); line-height: 1.5; }
        .rail-tip kbd { display: inline-block; padding: 1px 5px; background: rgba(255,255,255,0.1); border-radius: 3px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--rail-ink); }

        .wiz-content { display: flex; flex-direction: column; overflow: hidden; min-height: 0; width: 100%; }
        .content-head { display: flex; align-items: flex-start; justify-content: space-between; padding: 22px 28px 14px; border-bottom: 1px solid var(--line); }
        .content-title { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 600; letter-spacing: -0.01em; margin: 0; }
        .content-title .eyebrow { display: block; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 4px; }
        .content-sub { color: var(--ink-mute); font-size: 13px; margin: 4px 0 0; }
        .content-body { flex: 1; padding: 24px 28px; overflow-y: auto; position: relative; }
        .content-body.launching { overflow: hidden; }

        .step-panel { display: none; animation: slideIn 0.3s cubic-bezier(.4,.0,.2,1); height: 100%; }
        .step-panel.active { display: block; }
        @keyframes slideIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

        .wiz-field { margin-bottom: 18px; }
        .wiz-field-label { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 500; color: var(--ink-soft); margin-bottom: 6px; }
        .wiz-field-label .optional { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; }
        .wiz-input { width: 100%; height: 40px; padding: 0 14px; font-family: inherit; font-size: 14px; color: var(--ink); background: var(--surface); border: 1px solid var(--line-strong); border-radius: 6px; transition: all 0.15s ease; }
        .wiz-input::placeholder { color: var(--ink-mute); }
        .wiz-input:hover { border-color: #b8b3a8; }
        .wiz-input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(45,74,62,0.12); }

        .step1-grid { display: grid; grid-template-columns: 1fr 280px; gap: 28px; align-items: flex-start; }
        .preview-card { background: linear-gradient(135deg, #fafaf7 0%, #f0ede4 100%); border: 1px solid var(--line-strong); border-radius: 8px; padding: 18px; position: relative; overflow: hidden; }
        .preview-card::before { content: ''; position: absolute; top: 0; right: 0; width: 80px; height: 80px; background: radial-gradient(circle, rgba(45,74,62,0.08) 0, transparent 70%); border-radius: 50%; }
        .preview-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 8px; }
        .preview-name { font-family: 'Fraunces', serif; font-size: 20px; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 10px; min-height: 26px; color: var(--ink); word-break: break-word; }
        .preview-name.empty { color: var(--ink-mute); font-style: italic; font-weight: 500; }
        .preview-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 14px; min-height: 20px; }
        .preview-tag { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 3px 8px; border-radius: 4px; background: rgba(61,90,128,0.1); color: var(--info); }
        .preview-tag.cycle { background: rgba(106,74,124,0.1); color: #6a4a7c; }
        .preview-meta { font-size: 11px; color: var(--ink-mute); line-height: 1.5; font-family: 'JetBrains Mono', monospace; }
        .preview-meta .line { margin-bottom: 3px; }

        .dropzone { position: relative; border: 2px dashed var(--line-strong); border-radius: 10px; padding: 44px 24px; text-align: center; background: var(--surface-alt); transition: all 0.2s ease; overflow: hidden; }
        .dropzone.dragover { border-color: var(--accent); background: var(--accent-soft); }
        .dropzone.uploaded { border-style: solid; border-color: var(--pass); background: var(--surface); padding: 20px 24px; text-align: left; }
        .dz-icon { width: 56px; height: 56px; margin: 0 auto 14px; border-radius: 12px; background: var(--surface); border: 1px solid var(--line); display: flex; align-items: center; justify-content: center; color: var(--accent); position: relative; }
        .dz-title { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; margin-bottom: 4px; }
        .dz-sub { color: var(--ink-mute); font-size: 13px; margin-bottom: 14px; }
        .dz-hint { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; margin-top: 10px; }
        .file-info { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
        .file-icon { width: 40px; height: 40px; background: var(--accent-soft); color: var(--accent); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 600; flex-shrink: 0; }
        .file-name { font-weight: 500; color: var(--ink); margin-bottom: 2px; }
        .file-stat { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-mute); }
        .file-replace { margin-left: auto; font-size: 12px; color: var(--ink-mute); text-decoration: underline; cursor: pointer; }
        .file-replace:hover { color: var(--accent); }
        .preview-table { width: 100%; border-collapse: collapse; font-size: 12px; border: 1px solid var(--line); border-radius: 6px; overflow: hidden; }
        .preview-table th, .preview-table td { padding: 8px 10px; text-align: left; border-bottom: 1px solid var(--line); }
        .preview-table th { background: var(--surface-alt); font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; color: var(--ink-mute); }
        .preview-table tr:last-child td { border-bottom: none; }
        .preview-table td { color: var(--ink-soft); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .mapping-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 24px; height: 100%; }
        .csv-panel { background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; overflow: hidden; display: flex; flex-direction: column; }
        .csv-head { padding: 10px 14px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: center; background: var(--surface); }
        .csv-head-title { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); }
        .csv-table-wrap { overflow: auto; flex: 1; }
        .csv-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .csv-table th { position: sticky; top: 0; background: var(--surface); padding: 10px 12px; font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; color: var(--ink-mute); border-bottom: 1px solid var(--line); text-align: left; transition: all 0.15s ease; }
        .csv-table th .col-letter { display: inline-block; width: 16px; height: 16px; border-radius: 3px; background: var(--line); color: var(--ink-mute); font-size: 9px; text-align: center; line-height: 16px; margin-right: 6px; transition: all 0.15s ease; }
        
        /* Auto-mapped dynamic coloring */
        .csv-table th.mapped { background: var(--accent-soft); }
        .csv-table th.mapped .col-letter { color: #fff; }
        .csv-table th.mapped[data-accent="1"] { background: #e5ecf2; color: var(--m1); }
        .csv-table th.mapped[data-accent="1"] .col-letter { background: var(--m1); }
        .csv-table th.mapped[data-accent="2"] { background: #f7e8e2; color: var(--m2); }
        .csv-table th.mapped[data-accent="2"] .col-letter { background: var(--m2); }
        .csv-table th.mapped[data-accent="3"] { background: #f9f0da; color: var(--m3); }
        .csv-table th.mapped[data-accent="3"] .col-letter { background: var(--m3); }
        .csv-table th.mapped[data-accent="4"] { background: #f0e6f5; color: var(--m4); }
        .csv-table th.mapped[data-accent="4"] .col-letter { background: var(--m4); }
        .csv-table th.mapped[data-accent="5"] { background: #e8f0eb; color: var(--m5); }
        .csv-table th.mapped[data-accent="5"] .col-letter { background: var(--m5); }
        .csv-table th.highlight { box-shadow: inset 0 -2px 0 var(--accent); }
        .csv-table td { padding: 8px 12px; border-bottom: 1px solid var(--line); color: var(--ink-soft); white-space: nowrap; max-width: 180px; overflow: hidden; text-overflow: ellipsis; }
        .csv-table td[data-accent="1"] { background: rgba(61,90,128,0.06); }
        .csv-table td[data-accent="2"] { background: rgba(166,66,31,0.06); }
        .csv-table td[data-accent="3"] { background: rgba(184,134,11,0.06); }
        .csv-table td[data-accent="4"] { background: rgba(106,74,124,0.06); }
        .csv-table td[data-accent="5"] { background: rgba(74,124,89,0.06); }

        .mappers { display: flex; flex-direction: column; gap: 10px; }
        .mapper { background: var(--surface); border: 1px solid var(--line-strong); border-radius: 8px; padding: 12px 14px; cursor: pointer; transition: all 0.2s ease; position: relative; }
        .mapper:hover { border-color: var(--accent); }
        .mapper[data-accent="1"].mapped { border-left: 3px solid var(--m1); background: rgba(61,90,128,0.04); }
        .mapper[data-accent="2"].mapped { border-left: 3px solid var(--m2); background: rgba(166,66,31,0.04); }
        .mapper[data-accent="3"].mapped { border-left: 3px solid var(--m3); background: rgba(184,134,11,0.04); }
        .mapper[data-accent="4"].mapped { border-left: 3px solid var(--m4); background: rgba(106,74,124,0.04); }
        .mapper[data-accent="5"].mapped { border-left: 3px solid var(--m5); background: rgba(74,124,89,0.04); }
        .mapper-label { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
        .mapper-name { font-weight: 500; color: var(--ink); font-size: 13px; }
        .mapper-req { font-family: 'JetBrains Mono', monospace; font-size: 9px; padding: 2px 6px; border-radius: 3px; background: var(--fail); color: #fff; text-transform: uppercase; letter-spacing: 0.08em; }
        .mapper-opt { font-family: 'JetBrains Mono', monospace; font-size: 9px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; }
        .mapper-select { width: 100%; height: 32px; padding: 0 28px 0 0; font-family: inherit; font-size: 13px; color: var(--ink); background: transparent; border: none; cursor: pointer; appearance: none; background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2355524d' stroke-width='2'%3e%3cpolyline points='6 9 12 15 18 9'/%3e%3c/svg%3e"); background-repeat: no-repeat; background-position: right 4px center; }
        .mapper-select:focus { outline: none; }
        .mapper-preview { margin-top: 4px; font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-mute); padding-top: 6px; border-top: 1px dashed var(--line); display: flex; gap: 6px; align-items: center; }
        .mapper-preview .arrow { color: var(--ink-mute); }
        .mapper-preview .sample { background: var(--surface-alt); padding: 2px 6px; border-radius: 3px; color: var(--ink-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 200px; }

        .roster-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .add-tester-row { display: flex; gap: 8px; margin-bottom: 14px; }
        .add-tester-row .input { flex: 1; }
        .recent-testers { margin-top: 14px; }
        .recent-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 8px; }
        .recent-chips { display: flex; flex-wrap: wrap; gap: 6px; }
        .recent-chip { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px 4px 4px; background: var(--surface-alt); border: 1px solid var(--line); border-radius: 999px; cursor: pointer; font-size: 12px; transition: all 0.15s ease; }
        .recent-chip:hover { border-color: var(--accent); background: var(--accent-soft); }
        .recent-chip .mini-avatar { width: 20px; height: 20px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 9px; font-weight: 600; font-family: 'JetBrains Mono', monospace; }
        .recent-chip .plus { color: var(--ink-mute); font-weight: 600; }
        .roster-panel { background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; padding: 16px; min-height: 280px; display: flex; flex-direction: column; }
        .roster-head { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 12px; display: flex; justify-content: space-between; }
        .roster-list { display: flex; flex-direction: column; gap: 8px; flex: 1; }
        .roster-empty { flex: 1; display: flex; align-items: center; justify-content: center; color: var(--ink-mute); font-size: 13px; text-align: center; padding: 20px; border: 1px dashed var(--line-strong); border-radius: 6px; min-height: 180px; }
        .roster-item { display: flex; align-items: center; gap: 10px; padding: 8px 12px; background: var(--surface); border: 1px solid var(--line); border-radius: 6px; animation: popIn 0.3s cubic-bezier(.4,0,.2,1); }
        @keyframes popIn { from { opacity: 0; transform: scale(0.95) translateY(-4px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        .roster-avatar { width: 28px; height: 28px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; flex-shrink: 0; font-family: 'JetBrains Mono', monospace; }
        .roster-name { flex: 1; font-size: 13px; font-weight: 500; }
        .roster-remove { width: 24px; height: 24px; border: none; background: transparent; color: var(--ink-mute); cursor: pointer; border-radius: 4px; display: flex; align-items: center; justify-content: center; }
        .roster-remove:hover { background: var(--fail); color: #fff; }

        .launch-celebration { text-align: center; padding: 10px 20px; position: relative; overflow: visible; }
        .launch-icon-wrap { width: 80px; height: 80px; margin: 0 auto 20px; border-radius: 50%; background: var(--accent-soft); display: flex; align-items: center; justify-content: center; position: relative; animation: scaleIn 0.5s cubic-bezier(.4,0,.2,1); }
        @keyframes scaleIn { from { transform: scale(0); } to { transform: scale(1); } }
        .launch-icon-wrap::before, .launch-icon-wrap::after { content: ''; position: absolute; inset: -6px; border-radius: 50%; border: 1px solid var(--accent); opacity: 0; animation: ripple 1.5s ease-out infinite; }
        .launch-icon-wrap::after { animation-delay: 0.5s; }
        @keyframes ripple { 0% { transform: scale(1); opacity: 0.6; } 100% { transform: scale(1.4); opacity: 0; } }
        .launch-title { font-family: 'Fraunces', serif; font-size: 30px; font-weight: 600; letter-spacing: -0.02em; margin: 0 0 8px; }
        .launch-sub { color: var(--ink-mute); font-size: 14px; margin: 0 auto 24px; max-width: 380px; }
        .launch-summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; background: var(--surface-alt); border: 1px solid var(--line); border-radius: 8px; padding: 16px; margin-bottom: 24px; text-align: left; }
        .launch-cell .lc-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); margin-bottom: 2px; }
        .launch-cell .lc-value { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; color: var(--ink); }
        
        .confetti { position: absolute; width: 8px; height: 14px; pointer-events: none; opacity: 0; border-radius: 1px; z-index: 2; }
        .confetti.fire { animation: fall 3.6s cubic-bezier(.2,.6,.4,1) forwards; }
        @keyframes fall { 0% { opacity: 0; transform: translateY(-20px) rotate(0); } 8% { opacity: 1; } 85% { opacity: 1; } 100% { opacity: 0; transform: translateY(420px) rotate(720deg); } }

        .content-foot { display: flex; justify-content: space-between; align-items: center; gap: 16px; padding: 16px 32px; border-top: 1px solid var(--line); background: var(--surface-alt); }
        .foot-hint { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; display: flex; align-items: center; gap: 8px; min-width: 0; overflow: hidden; }
        .foot-actions { display: flex; gap: 8px; align-items: center; flex-shrink: 0; }
        .content-foot.crowded .foot-hint span:not(.saved-indicator) { display: none; }
        .foot-hint kbd { background: var(--surface); border: 1px solid var(--line-strong); padding: 2px 6px; border-radius: 3px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-soft); }
        .saved-indicator { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.08em; display: inline-flex; align-items: center; gap: 5px; margin-right: 10px; transition: opacity 0.2s; opacity: 0; }
        .saved-indicator.show { opacity: 1; }
        .saved-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--pass); }
      `}} />

      {/* DASHBOARD HEADER */}
      <div className="app">
        <aside className="sidebar">
          <div className="brand">
            <div className="brand-mark">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
            </div>
            <div className="brand-name">QA Triage</div>
          </div>
          <nav className="nav">
            <a className="nav-item active" href="/pm">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 5-5"/></svg>
              PM Dashboard
            </a>
            <a className="nav-item" href="/admin">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l1-1"/></svg>
              Link Generator
            </a>
            <a className="nav-item" href="/admin/settings">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33h0a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51h0a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82v0a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
              Workspace Settings
            </a>
          </nav>
          <div className="sidebar-foot">
            <div className="issues-pill">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 9v4"/><path d="M12 17h.01"/><circle cx="12" cy="12" r="10"/></svg>
              {stats.pendingTriage} Issues
            </div>
            <div className="user-card">
              <div className="avatar">JD</div>
              <div>
                <div className="user-name">John Doe</div>
                <div className="user-role">Admin</div>
              </div>
            </div>
          </div>
        </aside>

        <main className="main">
          <div className="page-head">
            <div>
              <div className="page-eyebrow">Workspace · 2026</div>
              <h1 className="page-title">PM Triage Dashboard</h1>
              <p className="page-sub">Real-time overview of your testing operations.</p>
            </div>
            <div className="head-actions">
              <button className="btn btn-ghost" disabled={!Object.values(reviews).includes('Approved')} onClick={prepareJiraDrafts}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Review & Push Jira
              </button>
              <button className="btn btn-primary" onClick={() => setWizOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                Create Project
              </button>
            </div>
          </div>

          <div className="stats-row">
            <div className="stat-card stat-results">
              <div className="stat-label">Test Results · {stats.totalSteps} Total</div>
              <div className="segmented-bar">
                <span className="seg-pass" style={{ width: stats.passedPct + '%' }}></span>
                <span className="seg-fail" style={{ width: stats.failedPct + '%' }}></span>
                <span className="seg-pend" style={{ width: stats.pendingPct + '%' }}></span>
              </div>
              <div className="legend">
                <div className="legend-item"><span className="legend-dot dot-pass"></span> Passed <b>{stats.passed}</b></div>
                <div className="legend-item"><span className="legend-dot dot-fail"></span> Failed <b>{stats.failed}</b></div>
                <div className="legend-item"><span className="legend-dot dot-pend"></span> Pending <b>{stats.remainingSteps}</b></div>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Active Projects</div>
              <div className="stat-big"><span className="stat-value">{stats.projectsCount}</span><span className="stat-unit">projects</span></div>
              <div className="stat-breakdown" style={{ gridTemplateColumns: '1fr 1fr' }}>
                <div className="breakdown-item"><div className="bd-label">In progress</div><div className="bd-value">{stats.inProgressProjects}</div></div>
                <div className="breakdown-item"><div className="bd-label">Complete</div><div className="bd-value">{stats.completeProjects}</div></div>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Completion</div>
              <div className="stat-big"><span className="stat-value">{stats.completionPct}%</span></div>
              <div className="stat-breakdown" style={{ gridTemplateColumns: '1fr 1fr' }}>
                <div className="breakdown-item"><div className="bd-label">Completed</div><div className="bd-value">{stats.completedSteps}</div></div>
                <div className="breakdown-item"><div className="bd-label">Remaining</div><div className="bd-value">{stats.remainingSteps}</div></div>
              </div>
            </div>
          </div>

          <div className="toolbar">
            <div className="search">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" placeholder="Search operations..." />
            </div>
            <span className="toolbar-label">Filter</span>
            <select className="select-compact" value={filterProject} onChange={e => setFilterProject(e.target.value)}>
              {uniqueProjects.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
            <select className="select-compact" value={filterCycle} onChange={e => setFilterCycle(e.target.value)}>
              {uniqueCycles.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select className="select-compact" value={filterTester} onChange={e => setFilterTester(e.target.value)}>
              {uniqueTesters.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div className="project-list">
            {runsNeedsAttention.length > 0 && (
              <>
                <h3 className="section-heading">Needs Attention <span className="count">{runsNeedsAttention.length}</span></h3>
                {runsNeedsAttention.map(run => renderRow(run, 'status-fail', `${run.steps.filter(s => run.results?.[s.id]?.status === 'Failed' && !(run.results?.[s.id] as ExtendedTestResult)?.isTriaged).length} Failed`))}
              </>
            )}
            
            {runsInProgress.length > 0 && (
              <>
                <h3 className="section-heading" style={{ marginTop: runsNeedsAttention.length ? 20 : 0 }}>In Progress <span className="count">{runsInProgress.length}</span></h3>
                {runsInProgress.map(run => renderRow(run, 'status-run', 'In Progress'))}
              </>
            )}

            {runsCompleted.length > 0 && (
              <>
                <h3 className="section-heading" style={{ marginTop: (runsNeedsAttention.length || runsInProgress.length) ? 20 : 0 }}>Completed <span className="count">{runsCompleted.length}</span></h3>
                {runsCompleted.map(run => renderRow(run, 'status-pass', 'Complete'))}
              </>
            )}
          </div>
        </main>
      </div>

      {/* --- SIDE PANEL TRIAGE --- */}
      <div className={`panel-overlay ${activeRun ? 'open' : ''}`} onClick={() => setActiveRun(null)}></div>
      <aside className={`side-panel ${activeRun ? 'open' : ''}`}>
        {activeRun && (() => {
          const runComp = Object.keys(activeRun.results || {}).length;
          const runTot = activeRun.steps?.length || 0;
          let runPass = 0, runFail = 0, runPend = runTot - runComp;
          activeRun.steps.forEach(s => {
            if (activeRun.results?.[s.id]?.status === 'Passed') runPass++;
            if (activeRun.results?.[s.id]?.status === 'Failed') runFail++;
          });

          const panelSteps = activeRun.steps.filter(s => {
            const stat = activeRun.results?.[s.id]?.status;
            if (panelFilter === 'Passed') return stat === 'Passed';
            if (panelFilter === 'Failed') return stat === 'Failed';
            if (panelFilter === 'Pending') return !stat;
            return true;
          });

          return (
            <>
              <header className="panel-head">
                <div>
                  <h2 className="panel-title">{activeRun.projectName}</h2>
                  <p className="panel-sub">
                    <span>Tester · <strong style={{color: 'var(--ink)'}}>{activeRun.testerName}</strong></span>
                    {activeRun.deviceInfo && <><span>·</span><span>{activeRun.deviceInfo.device} · {activeRun.deviceInfo.os} · {activeRun.deviceInfo.browser}</span></>}
                    <span>·</span><span>{activeRun.isCompleted ? 'Run complete' : 'In progress'}</span>
                  </p>
                </div>
                <button className="close-btn" onClick={() => setActiveRun(null)} aria-label="Close">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
              </header>

              <div className="panel-summary">
                <div className="summary-cell"><div className="sc-label">Total</div><div className="sc-value">{runTot}</div></div>
                <div className="summary-cell"><div className="sc-label">Passed</div><div className="sc-value pass">{runPass}</div></div>
                <div className="summary-cell"><div className="sc-label">Failed</div><div className="sc-value fail">{runFail}</div></div>
                <div className="summary-cell"><div className="sc-label">Pending</div><div className="sc-value pend">{runPend}</div></div>
              </div>

              <div className="panel-toolbar">
                <button className={`filter-chip ${panelFilter === 'All' ? 'active' : ''}`} onClick={() => setPanelFilter('All')}>All · {runTot}</button>
                <button className={`filter-chip ${panelFilter === 'Failed' ? 'active' : ''}`} onClick={() => setPanelFilter('Failed')}>Failed · {runFail}</button>
                <button className={`filter-chip ${panelFilter === 'Pending' ? 'active' : ''}`} onClick={() => setPanelFilter('Pending')}>Pending · {runPend}</button>
                <button className={`filter-chip ${panelFilter === 'Passed' ? 'active' : ''}`} onClick={() => setPanelFilter('Passed')}>Passed · {runPass}</button>
              </div>

              <div className="panel-body">
                {panelSteps.map((step, idx) => {
                  const result = activeRun.results?.[step.id] as ExtendedTestResult;
                  const reviewKey = `${activeRun.id}_${step.id}`;
                  const isFailed = result?.status === 'Failed';
                  const isUploading = uploadingStep === reviewKey;
                  const isChecked = selectedBugs.includes(reviewKey);

                  return (
                    <div className="test-item" key={step.id}>
                      {isFailed && !result?.isTriaged ? (
                        <div className={`test-checkbox ${isChecked ? 'checked' : ''}`} onClick={() => toggleSelection(reviewKey)}></div>
                      ) : <div></div>}
                      
                      <div className="test-content">
                        <div className="test-id">Test {String(idx + 1).padStart(2, '0')} {step.area ? `· ${step.area}` : ''}</div>
                        <div className="test-action">{step.action}</div>
                        <div className="test-expected">{step.expectedResult}</div>
                        {isFailed && result?.notes && (
                          <div className="test-note"><strong>Tester note:</strong> {result.notes}</div>
                        )}
                      </div>

                      <div className="test-status">
                        {result ? (
                          <span className={`status-badge status-${result.status === 'Passed' ? 'pass' : 'fail'}`}>{result.status}</span>
                        ) : (
                          <span className="status-badge status-pend">Pending</span>
                        )}
                        
                        <div className="evidence-row">
                          {result?.evidenceUrls?.map((url, i) => (
                            <span className="evidence-chip" key={i} onClick={() => openViewer(result.evidenceUrls!, i)}>
                              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                              {i + 1}
                            </span>
                          ))}
                          {result && !result.isTriaged && (
                            <>
                              <label className="evidence-add">
                                {isUploading ? 'Uploading...' : '+ Desktop'}
                                <input type="file" hidden onChange={(e) => handlePMFileUpload(activeRun.id, step.id, result, e)} />
                              </label>
                              <span className="evidence-add" onClick={() => openPMQrScanner(activeRun.id, step.id, result)}>+ Phone</span>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="triage-actions">
                        {result?.isTriaged ? (
                           <Chip label="Triaged" size="small" variant="outlined" sx={{ height: 20, fontSize: 10, mt: 0.5 }} />
                        ) : isFailed ? (
                          <>
                            <button className="triage-btn approve" title="Approve" onClick={() => handleReview(activeRun.id, step.id, 'Approved')} style={reviews[reviewKey] === 'Approved' ? { background: 'var(--pass-soft)', color: 'var(--pass)', borderColor: 'var(--pass)' } : {}}>
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                            </button>
                            <button className="triage-btn reject" title="Reject" onClick={() => handleReview(activeRun.id, step.id, 'Rejected')} style={reviews[reviewKey] === 'Rejected' ? { background: 'var(--fail-soft)', color: 'var(--fail)', borderColor: 'var(--fail)' } : {}}>
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                            </button>
                          </>
                        ) : null}
                      </div>
                    </div>
                  );
                })}
              </div>

              <footer className="panel-foot">
                {selectedBugs.length > 0 ? (
                  <>
                    <span className="bulk-label">{selectedBugs.length} test{selectedBugs.length > 1 ? 's' : ''} selected</span>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button className="btn btn-ghost" style={{color: 'var(--pass)'}} onClick={() => {
                        const newReviews = { ...reviews };
                        selectedBugs.forEach(key => { newReviews[key] = 'Approved'; });
                        setReviews(newReviews); setSelectedBugs([]); 
                      }}>Approve</button>
                      <button className="btn btn-ghost" style={{color: 'var(--fail)'}} onClick={() => {
                        const newReviews = { ...reviews };
                        selectedBugs.forEach(key => { newReviews[key] = 'Rejected'; });
                        setReviews(newReviews); setSelectedBugs([]); 
                      }}>Reject</button>
                    </div>
                  </>
                ) : (
                  <>
                    <span className="bulk-label">Select tests to bulk-triage</span>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button className="btn btn-primary" onClick={prepareJiraDrafts} disabled={!Object.values(reviews).includes('Approved')}>Push to Jira</button>
                    </div>
                  </>
                )}
              </footer>
            </>
          );
        })()}
      </aside>

      {/* --- NEW: PROJECT CREATION WIZARD --- */}
      <Dialog 
        open={wizOpen} 
        onClose={closeWizard}
        maxWidth={wizStep === 3 ? "lg" : "md"} 
        fullWidth 
        PaperProps={{ 
          className: 'wiz-modal-wrapper',
          style: { backgroundColor: 'transparent', boxShadow: 'none', margin: 0, width: '100%', maxWidth: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' } 
        }}
      >
        <div className={`wiz-modal ${wizStep === 3 ? 'expanded' : ''}`}>
          
          <aside className="rail">
            <div className="rail-brand"><span className="eyebrow">QA Triage</span>New Project</div>
            <div>
              <div className="rail-progress"><span>Step {wizStep} / 5</span><span className="time">{wizStep === 5 ? 'Done' : `~${[45,30,25,15,0][wizStep-1]}s left`}</span></div>
              <div className="rail-bar" style={{marginTop: '6px'}}><div className="rail-bar-fill" style={{ width: (wizStep / 5) * 100 + '%' }}></div></div>
            </div>
            <nav className="rail-steps">
              <div className={`rail-step ${wizStep === 1 ? 'active' : wizStep > 1 ? 'done' : 'locked'}`} onClick={() => wizStep > 1 && setWizStep(1)}>
                <div className="step-dot">{wizStep > 1 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '1'}</div>
                <div className="step-text"><div className="step-name">Details</div><div className="step-value">{wizName || '—'}</div></div>
              </div>
              <div className={`rail-step ${wizStep === 2 ? 'active' : wizStep > 2 ? 'done' : 'locked'}`} onClick={() => wizStep > 2 && setWizStep(2)}>
                <div className="step-dot">{wizStep > 2 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '2'}</div>
                <div className="step-text"><div className="step-name">Script</div><div className="step-value">{wizFile ? `${wizRawData.length} tests` : 'Upload CSV'}</div></div>
              </div>
              <div className={`rail-step ${wizStep === 3 ? 'active' : wizStep > 3 ? 'done' : 'locked'}`} onClick={() => wizStep > 3 && setWizStep(3)}>
                <div className="step-dot">{wizStep > 3 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '3'}</div>
                <div className="step-text"><div className="step-name">Map Columns</div><div className="step-value">{Object.values(wizMap).filter(Boolean).length} mapped</div></div>
              </div>
              <div className={`rail-step ${wizStep === 4 ? 'active' : wizStep > 4 ? 'done' : 'locked'}`}>
                <div className="step-dot">{wizStep > 4 ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg> : '4'}</div>
                <div className="step-text"><div className="step-name">Assign</div><div className="step-value">{wizTesters.length ? `${wizTesters.length} added` : 'Optional'}</div></div>
              </div>
              <div className={`rail-step ${wizStep === 5 ? 'active' : 'locked'}`}>
                <div className="step-dot">5</div>
                <div className="step-text"><div className="step-name">Launch</div><div className="step-value">—</div></div>
              </div>
            </nav>
            <div className="rail-foot"><div className="rail-tip">Press <kbd>Enter</kbd> to continue, <kbd>Esc</kbd> to close. Your progress is saved automatically.</div></div>
          </aside>

          <div className="wiz-content">
            <header className="content-head">
              <div>
                <h1 className="content-title"><span className="eyebrow">Step {wizStep} of 5</span>
                  {wizStep === 1 ? 'Project Parameters' : wizStep === 2 ? 'Upload Test Script' : wizStep === 3 ? 'Map Your Columns' : wizStep === 4 ? 'Assign Testers' : 'All Set'}
                </h1>
                <p className="content-sub">
                  {wizStep === 1 ? 'Give your project a name and context. You can edit these later.' : wizStep === 2 ? 'Drop a CSV of your test cases. We\'ll detect columns automatically.' : wizStep === 3 ? 'Confirm how your CSV columns map to project fields.' : wizStep === 4 ? 'Build your team. Skip to create an unassigned project for later.' : 'Review what was just created.'}
                </p>
              </div>
              <button className="close-btn" onClick={closeWizard}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
            </header>

            <main className={`content-body ${wizStep === 5 ? 'launching' : ''}`}>
              
              {wizStep === 1 && (
                <div className="step-panel active">
                  <div className="step1-grid">
                    <div>
                      <div className="wiz-field">
                        <div className="wiz-field-label"><span>Project Name *</span></div>
                        <input className="wiz-input" type="text" value={wizName} onChange={e => {setWizName(e.target.value); triggerSaved();}} placeholder="e.g. Checkout v3 UAT" />
                      </div>
                      <div className="wiz-field">
                        <div className="wiz-field-label"><span>Target Environment</span><span className="optional">Optional</span></div>
                        <input className="wiz-input" type="text" value={wizEnv} onChange={e => {setWizEnv(e.target.value); triggerSaved();}} placeholder="Staging, Production, Dev..." />
                      </div>
                      <div className="wiz-field">
                        <div className="wiz-field-label"><span>Test Cycle</span><span className="optional">Optional</span></div>
                        <input className="wiz-input" type="text" value={wizCycle} onChange={e => {setWizCycle(e.target.value); triggerSaved();}} placeholder="Sprint 42, Release 2.1..." />
                      </div>
                    </div>
                    <div>
                      <div className="preview-card">
                        <div className="preview-label">Live Preview</div>
                        <div className={`preview-name ${!wizName ? 'empty' : ''}`}>{wizName || 'Untitled project'}</div>
                        <div className="preview-tags">
                          {wizEnv && <span className="preview-tag">{wizEnv}</span>}
                          {wizCycle && <span className="preview-tag cycle">{wizCycle}</span>}
                        </div>
                        <div className="preview-meta">
                          <div className="line">Created · just now</div>
                          <div className="line">Owner · Admin</div>
                          <div className="line">Tests · —</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {wizStep === 2 && (
                <div className="step-panel active">
                  <div className={`dropzone ${isDragging ? 'dragover' : ''} ${wizFile ? 'uploaded' : ''}`}
                    onDragOver={e => {e.preventDefault(); setIsDragging(true);}}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={e => {e.preventDefault(); setIsDragging(false); if(e.dataTransfer.files[0]) handleCsvUpload(e.dataTransfer.files[0]); }}
                  >
                    {!wizFile ? (
                      <>
                        <div className="dz-icon">
                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        </div>
                        <div className="dz-title">Drop your test script here</div>
                        <div className="dz-sub">We'll preview the file and map columns on the next step.</div>
                        <label className="btn btn-primary" style={{cursor: 'pointer'}}>
                          Browse Files
                          <input type="file" accept=".csv" hidden onChange={e => e.target.files?.[0] && handleCsvUpload(e.target.files[0])} />
                        </label>
                        <div className="dz-hint">CSV, TSV · max 10 MB</div>
                      </>
                    ) : (
                      <>
                        <div className="file-info">
                          <div className="file-icon">CSV</div>
                          <div>
                            <div className="file-name">{wizFile.name}</div>
                            <div className="file-stat">{wizRawData.length} rows · {wizHeaders.length} columns</div>
                          </div>
                          <label className="file-replace">
                            Replace file
                            <input type="file" accept=".csv" hidden onChange={e => e.target.files?.[0] && handleCsvUpload(e.target.files[0])} />
                          </label>
                        </div>
                        <table className="preview-table">
                          <thead><tr>{wizHeaders.slice(0, 5).map(h => <th key={h}>{h}</th>)}</tr></thead>
                          <tbody>
                            {wizRawData.slice(0, 4).map((row, i) => (
                              <tr key={i}>{wizHeaders.slice(0, 5).map(h => <td key={h}>{row[h]}</td>)}</tr>
                            ))}
                          </tbody>
                        </table>
                      </>
                    )}
                  </div>
                </div>
              )}

              {wizStep === 3 && (
                <div className="step-panel active">
                  <div className="mapping-grid">
                    <div className="csv-panel">
                      <div className="csv-head">
                        <span className="csv-head-title">{wizFile?.name} · {wizRawData.length} rows</span>
                      </div>
                      <div className="csv-table-wrap">
                        <table className="csv-table">
                          <thead>
                            <tr>
                              {wizHeaders.map((h, i) => {
                                const acc = getAccentForCol(h);
                                return (
                                  <th key={h} className={`${acc ? 'mapped' : ''} ${wizHoverCol === h ? 'highlight' : ''}`} data-accent={acc || undefined}>
                                    <span className="col-letter">{String.fromCharCode(65 + i)}</span>{h}
                                  </th>
                                );
                              })}
                            </tr>
                          </thead>
                          <tbody>
                            {wizRawData.slice(0, 6).map((row, idx) => (
                              <tr key={idx}>
                                {wizHeaders.map(h => (
                                  <td key={h} data-accent={getAccentForCol(h) || undefined}>{row[h]}</td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="mappers">
                      {[
                        { k: 'action', label: 'Action Column', req: true, v: wizMap.action },
                        { k: 'expectedResult', label: 'Expected Result', req: true, v: wizMap.expectedResult },
                        { k: 'area', label: 'Area / Module', req: false, v: wizMap.area },
                        { k: 'scenario', label: 'Scenario', req: false, v: wizMap.scenario },
                        { k: 'priority', label: 'Priority', req: false, v: wizMap.priority },
                      ].map((m, idx) => (
                        <div key={m.k} 
                             className={`mapper ${m.v ? 'mapped' : ''}`} 
                             data-accent={idx + 1}
                             onMouseEnter={() => setWizHoverCol(m.v)}
                             onMouseLeave={() => setWizHoverCol(null)}
                        >
                          <div className="mapper-label">
                            <span className="mapper-name">{m.label}</span>
                            {m.req ? <span className="mapper-req">Required</span> : <span className="mapper-opt">Optional</span>}
                          </div>
                          <select 
                            className="mapper-select" 
                            value={m.v} 
                            onChange={e => { setWizMap({...wizMap, [m.k as keyof typeof wizMap]: e.target.value}); triggerSaved(); }}
                          >
                            <option value="">— Not mapped —</option>
                            {wizHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                          </select>
                          {m.v && wizRawData.length > 0 && (
                            <div className="mapper-preview">
                              <span className="arrow">↳</span><span className="sample">{wizRawData[0][m.v]}</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {wizStep === 4 && (
                <div className="step-panel active">
                  <div className="roster-grid">
                    <div>
                      <div className="wiz-field">
                        <div className="wiz-field-label"><span>Add Tester</span><span className="optional">Press Enter</span></div>
                        <div className="add-tester-row">
                          <input className="wiz-input" type="text" placeholder="Name or email..." value={wizTesterInput} onChange={e => setWizTesterInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && addTester()} />
                          <button className="btn btn-primary" onClick={() => addTester()}>Add</button>
                        </div>
                      </div>
                      
                      {uniqueTestersList.length > 0 && (
                        <div className="recent-testers">
                          <div className="recent-label">Recently on your team</div>
                          <div className="recent-chips">
                            {uniqueTestersList.slice(0, 6).map((t, i) => {
                              const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
                              const c = colors[i % colors.length];
                              return (
                                <span key={t} className="recent-chip" onClick={() => addTester(t)}>
                                  <span className="mini-avatar" style={{background: c}}>{t.charAt(0)}</span>
                                  {t} <span className="plus">+</span>
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="roster-panel">
                      <div className="roster-head"><span>Team Roster</span><span>{wizTesters.length} added</span></div>
                      <div className="roster-list">
                        {wizTesters.length === 0 ? (
                          <div className="roster-empty">No testers yet — you can also skip this and assign later from the project page.</div>
                        ) : (
                          wizTesters.map(t => (
                            <div className="roster-item" key={t.name}>
                              <div className="roster-avatar" style={{background: t.color}}>{t.name.charAt(0).toUpperCase()}</div>
                              <div className="roster-name">{t.name}</div>
                              <button className="roster-remove" onClick={() => removeTester(t.name)}>
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                              </button>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {wizStep === 5 && (
                <div className="step-panel active">
                  <div className="launch-celebration" id="confetti-root" ref={confettiContainerRef}>
                    <div className="launch-icon-wrap">
                      <svg className="launch-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    </div>
                    <h2 className="launch-title">Project Launched</h2>
                    <p className="launch-sub">Your UAT cycle is ready. Testers will see it in their dashboard shortly.</p>
                    <div className="launch-summary">
                      <div className="launch-cell"><div className="lc-label">Project</div><div className="lc-value">{wizName}</div></div>
                      <div className="launch-cell"><div className="lc-label">Tests</div><div className="lc-value">{wizRawData.length}</div></div>
                      <div className="launch-cell"><div className="lc-label">Testers</div><div className="lc-value">{wizTesters.length || '—'}</div></div>
                      <div className="launch-cell"><div className="lc-label">Status</div><div className="lc-value" style={{color: 'var(--pass)'}}>Ready</div></div>
                    </div>
                  </div>
                </div>
              )}
            </main>

            {wizStep < 5 ? (
              <footer className={`content-foot ${wizStep === 4 ? 'crowded' : ''}`}>
                <div className="foot-hint">
                  <span className={`saved-indicator ${wizSaved ? 'show' : ''}`}><span className="saved-dot"></span> Saved</span>
                  <span><kbd>Enter</kbd> continue</span>
                  <span><kbd>Esc</kbd> close</span>
                </div>
                <div className="foot-actions">
                  <button className="btn btn-ghost" onClick={() => setWizStep(prev => prev - 1)} style={{visibility: wizStep > 1 ? 'visible' : 'hidden'}}>← Back</button>
                  {wizStep === 4 && <button className="btn btn-ghost" onClick={launchProject} disabled={isLaunching}>Skip</button>}
                  <button 
                    className="btn btn-primary" 
                    disabled={!canAdvance() || isLaunching}
                    onClick={() => wizStep === 4 ? launchProject() : setWizStep(prev => prev + 1)}
                  >
                    {isLaunching ? 'Creating...' : wizStep === 4 ? 'Launch Project' : 'Next Step →'}
                  </button>
                </div>
              </footer>
            ) : (
              <footer className="content-foot" style={{justifyContent: 'center'}}>
                <button className="btn btn-primary" onClick={() => { closeWizard(); window.location.href = '/admin'; }}>View Links & Dashboard →</button>
              </footer>
            )}
          </div>
        </div>
      </Dialog>

    </Box>
  );
}