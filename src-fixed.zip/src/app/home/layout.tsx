// Home route owns its own sidebar, so no wrapper layout is needed.
import React from 'react';

export default function HomeLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
