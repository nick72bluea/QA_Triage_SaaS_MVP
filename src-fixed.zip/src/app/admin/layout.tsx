// Admin routes own their own sidebar, so no wrapper layout is needed.
import React from 'react';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
