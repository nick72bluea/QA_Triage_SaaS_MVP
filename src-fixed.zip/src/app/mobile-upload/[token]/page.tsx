"use client";

import React, { useState, use } from 'react';
import { Container, Typography, Box, Button, CircularProgress, Paper } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { doc, setDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/lib/firebase';

export default function MobileUploadPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params);
  const [isUploading, setIsUploading] = useState(false);
  const [isDone, setIsDone] = useState(false);

  const handleMobileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      // 1. Upload the photo from the phone to Firebase Storage
      const uniqueFileName = `mobile_evidence/${Date.now()}_${file.name}`;
      const storageRef = ref(storage, uniqueFileName);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);

      // 2. Drop the URL into the temporary Firebase "mailbox" for the desktop to find
      await setDoc(doc(db, 'mobileUploads', token), {
        url: downloadURL,
        timestamp: new Date()
      });

      setIsDone(true);
    } catch (error) {
      console.error("Mobile upload failed:", error);
      alert("Upload failed. Please try again.");
      setIsUploading(false);
    }
  };

  if (isDone) {
    return (
      <Container maxWidth="sm" sx={{ height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', bgcolor: '#f0fdf4' }}>
        <CheckCircleIcon color="success" sx={{ fontSize: 80, mb: 2 }} />
        <Typography variant="h5" fontWeight="bold">Upload Complete!</Typography>
        <Typography color="text.secondary" sx={{ mt: 1 }}>Look back at your computer screen.</Typography>
        <Typography color="text.secondary">You can close this tab on your phone.</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="sm" sx={{ height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', p: 3, bgcolor: '#f5f7fa' }}>
      <Paper elevation={3} sx={{ p: 4, textAlign: 'center', borderRadius: 4 }}>
        <Typography variant="h5" fontWeight="bold" gutterBottom>Upload Evidence</Typography>
        <Typography color="text.secondary" sx={{ mb: 4 }}>
          Take a photo or choose an image from your phone to attach to your current test step.
        </Typography>

        <Button
          component="label"
          variant="contained"
          size="large"
          disabled={isUploading}
          startIcon={isUploading ? <CircularProgress size={24} color="inherit" /> : <CloudUploadIcon />}
          sx={{ py: 2, px: 4, borderRadius: 8, width: '100%', fontSize: '1.1rem' }}
        >
          {isUploading ? 'Uploading...' : 'Take Photo / Upload'}
          {/* capture="environment" encourages the phone to open the back camera directly */}
          <input type="file" accept="image/*" capture="environment" hidden onChange={handleMobileUpload} />
        </Button>
      </Paper>
    </Container>
  );
}