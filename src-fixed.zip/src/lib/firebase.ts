import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Firebase Web SDK config. These NEXT_PUBLIC_ vars are shipped to the client,
// which is fine for Firebase Web SDK *provided* your Firestore and Storage rules
// are properly locked down. Double-check your rules in the Firebase Console.
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Helpful dev-mode warning if env vars are missing
if (process.env.NODE_ENV !== 'production' && !firebaseConfig.apiKey) {
  console.warn(
    '[firebase] Missing NEXT_PUBLIC_FIREBASE_* environment variables. ' +
    'Copy .env.example to .env.local and fill in your Firebase project values.'
  );
}

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

const db = getFirestore(app);
const storage = getStorage(app);

export { db, storage };
