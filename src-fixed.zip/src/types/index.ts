import { Timestamp } from 'firebase/firestore';

export type Orientation = 'portrait' | 'landscape';

export interface TestStep {
  id: string;
  action: string;
  expectedResult: string;
  visualAidUrl?: string; // Legacy single URL
  orientation?: Orientation;

  area?: string;
  scenario?: string;
  objective?: string;
  preConditions?: string;
  testType?: string;
  priority?: string;

  // Arrays to hold Admin uploads and reference links
  mediaUrls?: string[];
  referenceLinks?: string[];
}

export interface TestResult {
  stepId?: string;
  status: 'Passed' | 'Failed';
  notes?: string;
  evidenceUrls?: string[];
  isTriaged?: boolean;
}

export interface DeviceInfo {
  device: string;
  os: string;
  browser: string;
}

/**
 * The full testRuns/{id} document shape as written by the app.
 * `id` is injected client-side when reading from a snapshot — it's not stored in the doc.
 */
export interface TestRunData {
  id: string;
  projectName: string;
  testerName: string;
  testCycle?: string;
  environment?: string;
  steps: TestStep[];
  results?: Record<string, TestResult>;
  isCompleted?: boolean;
  completedAt?: Timestamp;
  createdAt?: Timestamp;
  deviceInfo?: DeviceInfo;
  cumulativeTimeMs?: number;
}
