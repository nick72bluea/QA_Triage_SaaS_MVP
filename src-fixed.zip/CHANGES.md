# Tier 1 fixes applied

Surgical fixes to the QA Triage codebase. All changes are in-place edits to your
existing files — no rewrites from scratch. The app architecture, Firebase wiring,
and all your logic are preserved exactly as they were.

## What changed

### 1. Type system: `TestRunData` is now properly defined
- **File:** `src/types/index.ts`
- Added `TestRunData` interface covering all fields referenced across the app
  (projectName, testerName, steps, results, deviceInfo, cumulativeTimeMs, etc.)
- Added `DeviceInfo` interface
- Moved `isTriaged` onto `TestResult` itself (the existing `ExtendedTestResult`
  pattern in `/admin` and `/pm` still works — just becomes a no-op extension)

### 2. Dead files deleted
- `src/app/page.tsx` — Next.js starter template (replaced with redirect to `/home`)
- `src/app/page.module.css` — orphaned after above
- `src/app/tester/page.tsx` — Next.js starter template
- `src/app/api/page.tsx` — invalid, `/api` should be route handlers only
- `src/app/jira/route.ts` — duplicate of `src/app/api/jira/route.ts`
- `src/components/Layout/DashboardLayout.tsx` — 170 lines, never imported
- `src/components/TesterUI/TestCard.tsx` — 220 lines of MUI, never imported
- `src/components/PM/ReviewTable.tsx` — Next.js starter template masquerading as a component

### 3. Root route now redirects correctly
- **File:** `src/app/page.tsx` (new, 4 lines)
- Visiting `/` now redirects to `/home` instead of showing the Next.js starter page

### 4. Firebase credentials moved to environment variables
- **Files:** `src/lib/firebase.ts`, `.env.example`, `.env.local` (new), `.gitignore` (new)
- Your existing Firebase project values are pre-populated in `.env.local` so the
  app works immediately. `.env.local` is gitignored.
- In production, set these env vars in your hosting platform (Vercel, etc.)
- **You should rotate the Firebase API key at some point** — it was previously
  committed to source.

### 5. Tester welcome rendering bug fixed
- **File:** `src/app/tester/[testRunId]/page.tsx`
- The project name in "You've been invited to test **annabels9**" was previously
  rendering literal `<b>annabels9</b>` text (angle brackets visible). Now renders
  as proper JSX with bold formatting.

### 6. Tester "Copy link" button: no more native alert
- **File:** `src/app/tester/[testRunId]/page.tsx`
- Replaced `alert("Link copied!")` with inline button state animation
  ("✓ Link copied" for 2 seconds). Matches the rest of the tester UX.

### 7. Sidebar navigation now complete everywhere
- **Files:** `src/app/pm/page.tsx`, `src/app/admin/page.tsx`
- Both `/pm` and `/admin` sidebars now include the Workspace Settings link.
  Previously you could land on these pages and have no way to navigate to settings.

### 8. Accessible navigation on `/home` and `/admin/settings`
- **Files:** `src/app/home/page.tsx`, `src/app/admin/settings/page.tsx`
- Replaced `<a onClick={router.push}>` with Next.js `<Link>` components
- This restores:
  - Cmd+click / middle-click → "Open in new tab"
  - Right-click context menu
  - Hover preview of destination URL
  - Screen reader navigation

### 9. Cmd+S keyboard shortcut fixed
- **File:** `src/app/admin/settings/page.tsx`
- Previously re-registered the keydown listener on every render (missing dep array)
- Also had a subtle stale-closure bug where pressing Cmd+S could save stale form data
- Fixed by using refs to track current formData/isDirty, with a stable listener
  that runs once on mount.

### 10. Unused MUI imports removed
- **File:** `src/app/pm/page.tsx`
- Removed unused `CloseIcon` and `BugReportIcon` imports

### 11. Layout files cleaned up
- **Files:** `src/app/home/layout.tsx`, `src/app/pm/layout.tsx`, `src/app/admin/layout.tsx`
- Removed dead comments referencing the deleted DashboardLayout

### 12. Dead code cleanup in tester route
- **File:** `src/app/tester/[testRunId]/page.tsx`
- Removed dead `params?.id` fallback — the folder is `[testRunId]` so only
  `params.testRunId` is ever defined
- Removed unused `TestResult` import in `/home/page.tsx`

## What wasn't changed (Tier 2 / Tier 3 — for a later pass)

- MUI is still a dependency. The PM wizard still uses MUI `<Dialog>` and `<Chip>`.
  Ripping it out requires rebuilding those in native CSS.
- The sidebar is still duplicated across 4 files. Extracting to a shared
  `<AppShell>` would be a proper refactor.
- **The Jira push confirmation modal is still missing.** You have a button that
  calls `prepareJiraDrafts()` which sets `jiraModalOpen=true`, but nothing
  renders when it's true. `confirmPushToJira()` is defined but never called from
  the UI. This means your Jira integration can't be triggered by users right now.
- The `contentEditable` fields in the admin script editor can race with Firestore
  snapshots. Works in practice but cursor can jump during quick typing.
- The mobile upload page (`/mobile-upload/[token]`) is still styled in MUI blue,
  inconsistent with the tester flow.

## How to use this

1. Unzip into your project root, replacing the existing `src/` directory.
2. The new `.env.local` has your existing Firebase values already populated —
   you shouldn't need to do anything for local dev.
3. Run `npm run dev` as usual.
4. If you run into TypeScript errors, they'll most likely be places where adding
   the real `TestRunData` type has surfaced a field access that was previously
   silently typed as `any`. Those are real bugs that now show up — fix each
   one by checking whether the field is optional or needs a default.
