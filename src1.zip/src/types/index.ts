export type Orientation = 'portrait' | 'landscape';

export interface TestStep {
  id: string;
  action: string;
  expectedResult: string;
  visualAidUrl?: string; // Legacy single URL
  orientation?: Orientation;
  
  area?: string;
  scenario?: string;
  objective?: string;
  preConditions?: string;
  testType?: string;
  priority?: string;

  // NEW: Arrays to hold Admin uploads and reference links
  mediaUrls?: string[];
  referenceLinks?: string[];
}

export interface TestResult {
  stepId: string;
  status: 'Passed' | 'Failed';
  notes?: string;
  evidenceUrls?: string[]; 
}