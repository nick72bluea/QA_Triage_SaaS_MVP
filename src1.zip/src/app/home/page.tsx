"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { TestRunData, TestResult } from '@/types';
import { useRouter } from 'next/navigation';

export default function PMHomeDashboard() {
  const router = useRouter();
  
  const [allRuns, setAllRuns] = useState<TestRunData[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [listFilter, setListFilter] = useState<'all' | 'need' | 'active' | 'done'>('all');
  const [toastMsg, setToastMsg] = useState('');
  
  // Safe Hydration: Initialize with a static string for SSR, update on client
  const [greeting, setGreeting] = useState('Good morning');

  useEffect(() => {
    // Client-side only time check
    const h = new Date().getHours();
    if (h >= 12 && h < 18) setGreeting('Good afternoon');
    else if (h >= 18) setGreeting('Good evening');

    const unsubscribe = onSnapshot(collection(db, 'testRuns'), (snapshot) => {
      const runsData = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as TestRunData[];
      setAllRuns(runsData);
    });
    return () => unsubscribe();
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(""), 2500);
  };

  // --- DATA AGGREGATION ---
  const projects = useMemo(() => {
    const grouped: Record<string, any> = {};
    allRuns.forEach(run => {
      if (!grouped[run.projectName]) {
        grouped[run.projectName] = {
          name: run.projectName, cycle: run.testCycle || 'N/A', environment: run.environment || 'N/A',
          runs: [], totalSteps: 0, completedSteps: 0,
          createdAt: run.createdAt?.toDate ? run.createdAt.toDate() : new Date(0) 
        };
      }
      grouped[run.projectName].runs.push(run);
      if (grouped[run.projectName].runs.length === 1) {
          grouped[run.projectName].totalSteps = run.steps?.length || 0;
      }
      if (run.testerName !== 'Unassigned') {
          grouped[run.projectName].completedSteps += Object.keys(run.results || {}).length;
      }
    });
    return Object.values(grouped).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }, [allRuns]);

  // Global Stats
  const activeTestersCount = new Set(allRuns.map(r => r.testerName).filter(n => n !== 'Unassigned')).size;
  const liveNowCount = allRuns.filter(r => r.testerName !== 'Unassigned' && !r.isCompleted && Object.keys(r.results || {}).length > 0).length;
  
  let totalStepsOverall = 0;
  let totalCompletedOverall = 0;
  projects.forEach(p => {
    const activeTesters = p.runs.filter((r: any) => r.testerName !== 'Unassigned').length;
    totalStepsOverall += (p.totalSteps * (activeTesters || 1));
    totalCompletedOverall += p.completedSteps;
  });
  const avgProgress = totalStepsOverall > 0 ? Math.round((totalCompletedOverall / totalStepsOverall) * 100) : 0;

  // Processed List for UI
  const processedProjects = projects.map(proj => {
    const activeTesters = proj.runs.filter((r: any) => r.testerName !== 'Unassigned');
    const testerCount = activeTesters.length;
    const totalPossibleSteps = proj.totalSteps * testerCount;
    const pct = totalPossibleSteps > 0 ? Math.round((proj.completedSteps / totalPossibleSteps) * 100) : 0;
    
    let status: 'need' | 'active' | 'done' = 'active';
    if (testerCount === 0) status = 'need';
    else if (pct === 100) status = 'done';
    
    const isMatch = proj.name.toLowerCase().includes(searchQuery.toLowerCase()) || activeTesters.some((t:any) => t.testerName.toLowerCase().includes(searchQuery.toLowerCase()));

    return { ...proj, testerCount, pct, status, activeTesters, isMatch };
  });

  const filteredProjects = processedProjects.filter(p => p.isMatch && (listFilter === 'all' || p.status === listFilter));
  const needsTesters = filteredProjects.filter(p => p.status === 'need');
  const inProgress = filteredProjects.filter(p => p.status === 'active');
  const complete = filteredProjects.filter(p => p.status === 'done');

  // Fake Live Feed
  const feedEvents = [
    { avatar: 'N', color: '#3d5a80', name: 'Nick', action: 'passed step 02 on', project: 'annabels8', status: 'pass', time: 'just now' },
    { avatar: 'K', color: '#a6421f', name: 'Kate', action: 'started', project: 'annabels10', status: 'info', time: '1m' },
    { avatar: 'J', color: '#a6421f', name: 'James', action: 'completed', project: 'annabels8', status: 'pass', time: '2h' },
    { avatar: 'N', color: '#3d5a80', name: 'Nick', action: 'reported issue on step 02 of', project: 'annabels8', status: 'fail', time: '3m' },
    { avatar: 'S', color: '#6a4a7c', name: 'Sarah', action: 'invited to', project: 'annabels5', status: 'info', time: '1h' },
  ];

  return (
    <div className="qa-home-wrapper">
      <style dangerouslySetInnerHTML={{__html: `
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500;1,9..144,600&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        
        .qa-home-wrapper {
          position: fixed; 
          inset: 0; 
          z-index: 9999; 
          overflow-y: auto;
          --bg: #f4f3ef; --surface: #ffffff; --surface-alt: #fafaf7;
          --ink: #1a1a1a; --ink-soft: #55524d; --ink-mute: #8a867f;
          --line: #e5e2db; --line-strong: #d4d0c7;
          --accent: #2d4a3e; --accent-soft: #e8f0eb; --accent-ink: #1d3329;
          --sidebar: #121a17; --sidebar-ink: #e5e2db; --sidebar-mute: #7a7a72;
          --pass: #4a7c59; --pass-soft: #e8f0eb;
          --fail: #a6421f; --fail-soft: #f7e8e2;
          --warn: #b8860b; --warn-soft: #f9f0da;
          --info: #3d5a80; --info-soft: #e5ecf2;
          --purple: #6a4a7c; --purple-soft: rgba(106,74,124,0.12);
          --radius: 6px;
          background: var(--bg); 
          font-family: 'IBM Plex Sans', system-ui, sans-serif; 
          color: var(--ink); 
          font-size: 14px; 
          overflow-x: hidden;
        }
        
        .qa-home-wrapper * { box-sizing: border-box; }
        
        /* ESCAPE HATCH NAMESPACING: Swapped .app to .qa-layout */
        .qa-layout { display: grid; grid-template-columns: 240px 1fr; min-height: 100vh; }

        /* SIDEBAR */
        .qa-sidebar { background: var(--sidebar); color: var(--sidebar-ink); display: flex; flex-direction: column; padding: 20px 16px; position: sticky; top: 0; height: 100vh; z-index: 20; }
        .brand { display: flex; align-items: center; gap: 10px; padding: 4px 8px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px; }
        .brand-mark { width: 32px; height: 32px; background: var(--accent); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #fff; }
        .brand-name { font-family: 'Fraunces', serif; font-size: 17px; font-weight: 600; letter-spacing: -0.01em; }
        .nav { display: flex; flex-direction: column; gap: 2px; }
        .nav-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; color: var(--sidebar-mute); text-decoration: none; border-radius: 6px; font-size: 13px; font-weight: 500; cursor: pointer; transition: background 0.15s ease, color 0.15s ease; }
        .nav-item:hover { color: var(--sidebar-ink); background: rgba(255,255,255,0.04); }
        .nav-item.active { background: rgba(255,255,255,0.08); color: var(--sidebar-ink); }
        .sidebar-foot { margin-top: auto; display: flex; flex-direction: column; gap: 10px; }
        .issues-pill { display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px; background: var(--fail); color: #fff; border-radius: 999px; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 500; width: fit-content; }
        .user-card { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: rgba(255,255,255,0.04); border-radius: 6px; }
        .avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; color: #fff; }
        .user-name { font-size: 13px; font-weight: 500; color: var(--sidebar-ink); }
        .user-role { font-size: 10px; color: var(--sidebar-mute); font-family: 'JetBrains Mono', monospace; text-transform: uppercase; letter-spacing: 0.08em; }

        .qa-main { overflow-x: hidden; }

        /* HERO ZONE */
        .qa-hero { position: relative; padding: 40px 40px 32px; background: linear-gradient(180deg, #ebe8de 0%, #f0ede3 100%); border-bottom: 1px solid var(--line-strong); overflow: hidden; }
        .qa-hero::before { content: ''; position: absolute; inset: 0; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E"); pointer-events: none; opacity: 0.7; }
        .qa-hero::after { content: ''; position: absolute; top: -200px; right: -100px; width: 600px; height: 600px; background: radial-gradient(circle, rgba(45,74,62,0.08) 0%, transparent 60%); pointer-events: none; }
        
        .hero-head { position: relative; display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 28px; gap: 20px; z-index: 1; }
        .hero-eyebrow { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.16em; color: var(--ink-mute); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .hero-eyebrow .time-now { color: var(--accent); font-weight: 500; }
        .hero-title { font-family: 'Fraunces', serif; font-size: 44px; font-weight: 600; letter-spacing: -0.025em; margin: 0; line-height: 1.05; color: var(--ink); }
        .hero-title em { font-style: italic; font-weight: 500; color: var(--accent); }
        
        .hero-meta { display: flex; gap: 20px; font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-soft); }
        .hero-meta > div { display: flex; flex-direction: column; align-items: flex-end; }
        .hero-meta .hm-label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); }
        .hero-meta .hm-value { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 600; color: var(--ink); line-height: 1; margin-top: 2px; }

        /* CURRENTLY STRIP */
        .currently { position: relative; z-index: 1; display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 14px; }
        .module { background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 18px 20px; position: relative; overflow: hidden; transition: all 0.2s ease; }
        .module:hover { box-shadow: 0 6px 16px rgba(0,0,0,0.06); transform: translateY(-1px); }
        .module-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 10px; display: flex; align-items: center; gap: 8px; font-weight: 500; }
        .module-label svg { color: var(--accent); }

        .resume-module { background: linear-gradient(135deg, #fafaf7 0%, #e8f0eb 120%); border-color: rgba(45,74,62,0.2); cursor: pointer; }
        .resume-module .module-label { color: var(--accent); }
        .resume-title { font-family: 'Fraunces', serif; font-size: 22px; font-weight: 600; letter-spacing: -0.01em; margin: 0 0 8px; color: var(--ink); }
        .resume-sub { font-size: 12px; color: var(--ink-soft); margin: 0 0 14px; line-height: 1.5; }
        .resume-sub b { color: var(--ink); font-weight: 500; }
        .resume-stats { display: flex; gap: 18px; margin-bottom: 14px; font-family: 'JetBrains Mono', monospace; font-size: 11px; }
        .resume-stat .rs-label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); }
        .resume-stat .rs-value { font-family: 'Fraunces', serif; font-size: 18px; font-weight: 600; color: var(--ink); line-height: 1; margin-top: 2px; }
        .resume-action { display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; background: var(--accent); color: #fff; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.15s ease; border: none; font-family: inherit; }
        .resume-action:hover { background: var(--accent-ink); }

        .feed-module { display: flex; flex-direction: column; padding: 0; overflow: hidden; }
        .feed-module .module-label { padding: 16px 18px 8px; margin: 0; }
        .feed-module .module-label .live-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--pass); animation: livePulse 1.6s ease-in-out infinite; }
        .feed-list { flex: 1; overflow: hidden; padding: 0 18px 16px; position: relative; mask-image: linear-gradient(180deg, black 70%, transparent); }
        .feed-track { animation: feedScroll 20s linear infinite; }
        .feed-module:hover .feed-track { animation-play-state: paused; }
        @keyframes feedScroll { 0% { transform: translateY(0); } 100% { transform: translateY(-50%); } }
        .feed-item { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; border-bottom: 1px dashed var(--line); font-size: 12px; }
        .feed-item:last-child { border-bottom: none; }
        .feed-item .mini-avatar { width: 22px; height: 22px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 9px; font-weight: 600; font-family: 'JetBrains Mono', monospace; flex-shrink: 0; margin-top: 1px; }
        .feed-text { flex: 1; color: var(--ink-soft); line-height: 1.45; }
        .feed-text b { color: var(--ink); font-weight: 500; }
        .feed-text .project { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--accent); }
        .feed-text .status { display: inline-block; font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.08em; padding: 1px 5px; border-radius: 3px; font-weight: 500; margin: 0 2px; }
        .status.pass { background: var(--pass-soft); color: var(--pass); }
        .status.fail { background: var(--fail-soft); color: var(--fail); }
        .status.info { background: var(--info-soft); color: var(--info); }
        .feed-time { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); white-space: nowrap; margin-top: 1px; }

        .attention-module { background: linear-gradient(135deg, #fafaf7 0%, #f9f0da 140%); border-color: rgba(184,134,11,0.3); cursor: pointer; }
        .attention-module .module-label { color: var(--warn); }
        .attention-module .module-label svg { color: var(--warn); }
        .attention-number { font-family: 'Fraunces', serif; font-size: 48px; font-weight: 600; color: var(--warn); line-height: 1; margin-bottom: 4px; letter-spacing: -0.02em; }
        .attention-label { font-size: 13px; color: var(--ink); font-weight: 500; margin-bottom: 10px; }
        .attention-breakdown { display: flex; flex-direction: column; gap: 6px; font-size: 11px; color: var(--ink-soft); font-family: 'JetBrains Mono', monospace; }
        .attention-breakdown .ab-row { display: flex; justify-content: space-between; align-items: center; }
        .attention-breakdown .ab-row b { color: var(--warn); }

        /* LIST SECTION */
        .list-section { padding: 28px 40px 60px; max-width: 1400px; }
        .toolbar { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; }
        .search { position: relative; flex: 1; min-width: 240px; max-width: 440px; }
        .search input { width: 100%; height: 38px; padding: 0 12px 0 38px; border: 1px solid var(--line); border-radius: 6px; background: var(--surface); font-family: inherit; font-size: 13px; color: var(--ink); }
        .search input:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(45,74,62,0.1); }
        .search svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--ink-mute); }

        .chip-filter { display: flex; gap: 6px; margin-left: auto; flex-wrap: wrap; }
        .filter-chip { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 6px 10px; border: 1px solid var(--line); background: var(--surface); color: var(--ink-soft); border-radius: 999px; cursor: pointer; }
        .filter-chip.active { background: var(--ink); color: #fff; border-color: var(--ink); }
        .filter-chip:hover:not(.active) { background: var(--surface-alt); }

        .section-heading { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin: 28px 0 12px; display: flex; align-items: center; gap: 10px; cursor: pointer; user-select: none; }
        .section-heading:first-child { margin-top: 0; }
        .section-heading::after { content: ''; flex: 1; height: 1px; background: var(--line); }
        .section-heading .count { background: var(--surface); border: 1px solid var(--line); padding: 2px 8px; border-radius: 999px; color: var(--ink-soft); font-weight: 500; }
        .section-group { display: flex; flex-direction: column; gap: 8px; }

        /* PROJECT ROW */
        .project-row { background: var(--surface); border: 1px solid var(--line); border-left: 3px solid var(--line-strong); border-radius: 8px; padding: 16px 20px; display: grid; grid-template-columns: auto 1fr 240px 180px auto; gap: 20px; align-items: center; cursor: pointer; transition: all 0.15s ease; position: relative; }
        .project-row:hover { box-shadow: 0 4px 10px rgba(0,0,0,0.05); border-color: var(--line-strong); }
        .project-row.status-need { border-left-color: var(--warn); }
        .project-row.status-active { border-left-color: var(--info); }
        .project-row.status-done { border-left-color: var(--pass); opacity: 0.85; }

        .row-number { width: 24px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-align: center; font-weight: 500; }
        .project-main { min-width: 0; }
        .project-name-row { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; flex-wrap: wrap; }
        .project-name { font-family: 'Fraunces', serif; font-size: 19px; font-weight: 600; letter-spacing: -0.01em; color: var(--ink); }
        .tag { font-family: 'JetBrains Mono', monospace; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; padding: 2px 7px; border-radius: 3px; background: var(--info-soft); color: var(--info); }
        .tag.cycle { background: var(--purple-soft); color: var(--purple); }
        .tag.live { background: var(--pass-soft); color: var(--pass); display: inline-flex; align-items: center; gap: 4px; }
        .tag.live::before { content: ''; width: 5px; height: 5px; border-radius: 50%; background: var(--pass); animation: livePulse 1.6s ease-in-out infinite; }
        .project-story { font-size: 12px; color: var(--ink-mute); line-height: 1.5; }
        .project-story b { color: var(--ink-soft); font-weight: 500; }
        .project-story .dot-sep { opacity: 0.4; margin: 0 4px; }

        .avatar-block { display: flex; flex-direction: column; gap: 6px; }
        .avatar-block-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); }
        .avatar-stack { display: flex; align-items: center; gap: 8px; }
        .avatars { display: flex; }
        .avatars .mini-avatar { width: 28px; height: 28px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 600; font-family: 'JetBrains Mono', monospace; border: 2px solid var(--surface); margin-left: -6px; position: relative; transition: transform 0.2s ease; }
        .avatars .mini-avatar:first-child { margin-left: 0; }
        .avatars .mini-avatar:hover { transform: translateY(-2px); z-index: 3; }
        .avatars .mini-avatar.live::after { content: ''; position: absolute; bottom: -1px; right: -1px; width: 10px; height: 10px; border-radius: 50%; background: var(--pass); border: 2px solid var(--surface); animation: livePulse 1.6s ease-in-out infinite; }
        .avatars .more { background: var(--line); color: var(--ink-soft); font-size: 9px; }
        .avatar-empty { display: inline-flex; align-items: center; gap: 6px; font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--warn); text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 8px; background: var(--warn-soft); border-radius: 4px; font-weight: 500; }
        .avatar-empty::before { content: ''; width: 5px; height: 5px; border-radius: 50%; background: var(--warn); }

        .progress-block { display: flex; flex-direction: column; gap: 6px; }
        .progress-block-label { font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); display: flex; justify-content: space-between; }
        .progress-block-label .val { color: var(--ink); font-weight: 500; }
        .progress-segmented { height: 6px; background: var(--line); border-radius: 999px; overflow: hidden; display: flex; }
        .progress-segmented .seg { height: 100%; }
        .seg.pass { background: var(--pass); }
        .seg.fail { background: var(--fail); }
        .seg.pend { background: var(--warn); }

        .row-actions { display: flex; gap: 4px; align-items: center; }
        .icon-btn { width: 34px; height: 34px; border: 1px solid var(--line); background: var(--surface); border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--ink-mute); transition: all 0.15s ease; position: relative; }
        .icon-btn:hover { background: var(--accent-soft); color: var(--accent); border-color: var(--accent); }

        /* Toast */
        .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%) translateY(100px); background: var(--ink); color: #fff; padding: 10px 16px; border-radius: 6px; font-size: 13px; display: flex; align-items: center; gap: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); transition: transform 0.3s cubic-bezier(.4,0,.2,1); z-index: 100; }
        .toast.show { transform: translateX(-50%) translateY(0); }
        .toast .check { color: var(--pass); }

        @media (max-width: 1200px) { .currently { grid-template-columns: 1fr 1fr; } .feed-module { grid-column: 1 / -1; } }
        @media (max-width: 900px) {
          .qa-layout { grid-template-columns: 1fr; } .qa-sidebar { display: none; }
          .qa-hero { padding: 28px 20px 24px; } .hero-title { font-size: 32px; }
          .currently { grid-template-columns: 1fr; } .list-section { padding: 20px; }
          .project-row { grid-template-columns: 1fr; gap: 10px; } .row-number { display: none; }
        }
      `}} />

      <div className="qa-layout">
        {/* SIDEBAR */}
        <aside className="qa-sidebar">
          <div className="brand">
            <div className="brand-mark">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
            </div>
            <div className="brand-name">QA Triage</div>
          </div>
          <nav className="nav">
            <a className="nav-item active" style={{cursor: 'default'}}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 5-5"/></svg>
              PM Dashboard
            </a>
            <a className="nav-item" onClick={() => router.push('/admin')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l1-1"/></svg>
              Link Generator
            </a>
            <a className="nav-item" onClick={() => router.push('/admin/settings')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82v0a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
              Workspace Settings
            </a>
          </nav>
          <div className="sidebar-foot">
            <div className="issues-pill">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><path d="M12 9v4M12 17h.01"/></svg>
              {needsTesters.length} Issues
            </div>
            <div className="user-card">
              <div className="avatar">JD</div>
              <div>
                <div className="user-name">John Doe</div>
                <div className="user-role">Admin</div>
              </div>
            </div>
          </div>
        </aside>

        <main className="qa-main">
          {/* HERO ZONE */}
          <section className="qa-hero">
            <div className="hero-head">
              <div>
                <div className="hero-eyebrow">
                  <span>Workspace · {projects.length} projects</span>
                  <span style={{ opacity: 0.5 }}>—</span>
                  <span className="time-now">{greeting}, John</span>
                </div>
                <h1 className="hero-title">Your <em>test cycles</em>,<br/>in one place.</h1>
              </div>
              <div className="hero-meta">
                <div>
                  <span className="hm-label">Active Testers</span>
                  <span className="hm-value">{activeTestersCount}</span>
                </div>
                <div>
                  <span className="hm-label">Live Now</span>
                  <span className="hm-value" style={{ color: 'var(--pass)' }}>{liveNowCount}</span>
                </div>
                <div>
                  <span className="hm-label">Avg Progress</span>
                  <span className="hm-value">{avgProgress}%</span>
                </div>
              </div>
            </div>

            <div className="currently">
              <div className="module resume-module" onClick={() => projects[0] && router.push('/admin')}>
                <div className="module-label">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  Pick up where you left off
                </div>
                <h2 className="resume-title">{projects[0]?.name || 'No projects'}</h2>
                <p className="resume-sub">Jump directly into your most recently active testing cycle.</p>
                <div className="resume-stats">
                  <div className="resume-stat">
                    <div className="rs-label">Steps</div>
                    <div className="rs-value">{projects[0]?.totalSteps || 0}</div>
                  </div>
                  <div className="resume-stat">
                    <div className="rs-label">Testers</div>
                    <div className="rs-value">{projects[0]?.runs?.filter((r:any) => r.testerName !== 'Unassigned').length || 0}</div>
                  </div>
                  <div className="resume-stat">
                    <div className="rs-label">Progress</div>
                    <div className="rs-value">{projects[0]?.pct || 0}%</div>
                  </div>
                </div>
                <button className="resume-action">
                  Manage Project
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </button>
              </div>

              <div className="module feed-module">
                <div className="module-label">
                  <span className="live-dot"></span> Live activity
                </div>
                <div className="feed-list">
                  <div className="feed-track">
                    {[...feedEvents, ...feedEvents].map((e, i) => (
                      <div className="feed-item" key={i}>
                        <div className="mini-avatar" style={{background: e.color}}>{e.avatar}</div>
                        <div className="feed-text">
                          <b>{e.name}</b> {e.action} <span className="project">{e.project}</span>
                          <div style={{marginTop: '2px'}}>
                            <span className={`status ${e.status}`}>{e.status === 'pass' ? 'PASS' : e.status === 'fail' ? 'FAIL' : 'EVENT'}</span>
                          </div>
                        </div>
                        <div className="feed-time">{e.time}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="module attention-module" onClick={() => { setListFilter('need'); showToast('Filtered to projects needing attention'); }}>
                <div className="module-label">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                  Needs attention
                </div>
                <div className="attention-number">{needsTesters.length}</div>
                <div className="attention-label">Projects waiting on you</div>
                <div className="attention-breakdown">
                  <div className="ab-row"><span>No testers assigned</span><b>{needsTesters.length}</b></div>
                </div>
              </div>
            </div>
          </section>

          {/* LIST SECTION */}
          <section className="list-section">
            <div className="toolbar">
              <div className="search">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                <input type="text" placeholder="Search projects, testers, scenarios..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
              </div>
              
              <div className="chip-filter">
                <button className={`filter-chip ${listFilter === 'all' ? 'active' : ''}`} onClick={() => setListFilter('all')}>All · {processedProjects.length}</button>
                <button className={`filter-chip ${listFilter === 'active' ? 'active' : ''}`} onClick={() => setListFilter('active')}>Active · {inProgress.length}</button>
                <button className={`filter-chip ${listFilter === 'need' ? 'active' : ''}`} onClick={() => setListFilter('need')}>Needs testers · {needsTesters.length}</button>
                <button className={`filter-chip ${listFilter === 'done' ? 'active' : ''}`} onClick={() => setListFilter('done')}>Complete · {complete.length}</button>
              </div>
            </div>

            <div id="project-list">
              
              {needsTesters.length > 0 && (
                <>
                  <h3 className="section-heading">Needs Testers <span className="count">{needsTesters.length}</span></h3>
                  <div className="section-group">
                    {needsTesters.map((p, idx) => (
                      <div className="project-row status-need" key={p.name} onClick={() => router.push('/admin')}>
                        <div className="row-number">{(idx + 1).toString().padStart(2, '0')}</div>
                        <div className="project-main">
                          <div className="project-name-row">
                            <span className="project-name">{p.name}</span>
                            {p.cycle && <span className="tag cycle">{p.cycle}</span>}
                            {p.environment && <span className="tag">{p.environment}</span>}
                          </div>
                          <div className="project-story">Created <b>{p.createdAt.toLocaleDateString()}</b> <span className="dot-sep">·</span> {p.totalSteps} test steps <span className="dot-sep">·</span> Ready to provision</div>
                        </div>
                        <div className="avatar-block">
                          <div className="avatar-block-label">Testers</div>
                          <div className="avatar-empty">No testers</div>
                        </div>
                        <div className="progress-block">
                          <div className="progress-block-label"><span>Progress</span><span className="val">0%</span></div>
                          <div className="progress-segmented"></div>
                        </div>
                        <div className="row-actions">
                          <button className="icon-btn" onClick={(e) => { e.stopPropagation(); router.push('/admin'); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {inProgress.length > 0 && (
                <>
                  <h3 className="section-heading" style={{ marginTop: needsTesters.length ? 28 : 0 }}>In Progress <span className="count">{inProgress.length}</span></h3>
                  <div className="section-group">
                    {inProgress.map((p, idx) => {
                      const isLive = p.activeTesters.some((t: any) => !t.isCompleted && Object.keys(t.results || {}).length > 0);
                      return (
                        <div className="project-row status-active" key={p.name} onClick={() => router.push('/admin')}>
                          <div className="row-number">{(needsTesters.length + idx + 1).toString().padStart(2, '0')}</div>
                          <div className="project-main">
                            <div className="project-name-row">
                              <span className="project-name">{p.name}</span>
                              {isLive && <span className="tag live">Live</span>}
                            </div>
                            <div className="project-story">In progress <span className="dot-sep">·</span> {p.totalSteps} steps</div>
                          </div>
                          <div className="avatar-block">
                            <div className="avatar-block-label">Testers {isLive ? '· Live' : ''}</div>
                            <div className="avatar-stack">
                              <div className="avatars">
                                {p.activeTesters.slice(0, 3).map((t: any, i: number) => {
                                  const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
                                  const c = colors[t.testerName.length % colors.length];
                                  const testerIsLive = !t.isCompleted && Object.keys(t.results || {}).length > 0;
                                  return <div key={i} className={`mini-avatar ${testerIsLive ? 'live' : ''}`} style={{background: c}} title={t.testerName}>{t.testerName.charAt(0).toUpperCase()}</div>
                                })}
                                {p.testerCount > 3 && <div className="mini-avatar more">+{p.testerCount - 3}</div>}
                              </div>
                            </div>
                          </div>
                          <div className="progress-block">
                            <div className="progress-block-label"><span>Progress</span><span className="val">{p.pct}%</span></div>
                            <div className="progress-segmented">
                              <div className="seg pass" style={{ flex: p.pct }}></div>
                              <div style={{ flex: 100 - p.pct }}></div>
                            </div>
                          </div>
                          <div className="row-actions">
                            <button className="icon-btn" onClick={(e) => { e.stopPropagation(); router.push('/admin'); }}>
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}

              {complete.length > 0 && (
                <>
                  <h3 className="section-heading" style={{ marginTop: (needsTesters.length || inProgress.length) ? 28 : 0 }}>Complete <span className="count">{complete.length}</span></h3>
                  <div className="section-group">
                    {complete.map((p, idx) => (
                      <div className="project-row status-done" key={p.name} onClick={() => router.push('/admin')}>
                        <div className="row-number">{(needsTesters.length + inProgress.length + idx + 1).toString().padStart(2, '0')}</div>
                        <div className="project-main">
                          <div className="project-name-row">
                            <span className="project-name">{p.name}</span>
                          </div>
                          <div className="project-story">Completed <span className="dot-sep">·</span> 100% passed</div>
                        </div>
                        <div className="avatar-block">
                          <div className="avatar-block-label">Testers</div>
                          <div className="avatar-stack">
                            <div className="avatars">
                              {p.activeTesters.slice(0, 3).map((t: any, i: number) => {
                                const colors = ['#3d5a80', '#a6421f', '#6a4a7c', '#b8860b', '#4a7c59'];
                                const c = colors[t.testerName.length % colors.length];
                                return <div key={i} className="mini-avatar" style={{background: c}} title={t.testerName}>{t.testerName.charAt(0).toUpperCase()}</div>
                              })}
                            </div>
                          </div>
                        </div>
                        <div className="progress-block">
                          <div className="progress-block-label"><span>Progress</span><span className="val">100%</span></div>
                          <div className="progress-segmented"><div className="seg pass" style={{ flex: 100 }}></div></div>
                        </div>
                        <div className="row-actions">
                          <button className="icon-btn" onClick={(e) => { e.stopPropagation(); router.push('/admin'); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
              
            </div>
          </section>
        </main>

        <div className={`toast ${toastMsg ? 'show' : ''}`}>
          <svg className="check" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
          <span>{toastMsg}</span>
        </div>
      </div>
    </div>
  );
}