"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'next/navigation';
import { doc, updateDoc, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/lib/firebase';
import { TestRunData } from '@/types';
import { QRCodeSVG } from 'qrcode.react';

// Added 'RESULTS' to the stages
type TesterStage = 'LOADING' | 'WELCOME' | 'TESTING' | 'COMPLETE' | 'RESULTS';

const getMediaType = (url: string) => {
  const lowerUrl = url.toLowerCase();
  if (lowerUrl.match(/\.(mp4|webm|ogg|mov)(?=\?|$)/i)) return 'video';
  if (lowerUrl.match(/\.(pdf)(?=\?|$)/i)) return 'pdf';
  return 'image'; 
};

// --- ISOLATED TIMER COMPONENT ---
const TimerChip = ({ cumulativeMs, sessionStartTime, isRunning }: { cumulativeMs: number, sessionStartTime: number, isRunning: boolean }) => {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      setElapsed(Date.now() - sessionStartTime);
    }, 1000);
    return () => clearInterval(interval);
  }, [isRunning, sessionStartTime]);

  const totalMs = cumulativeMs + (isRunning ? elapsed : 0);
  const sec = Math.floor(totalMs / 1000);
  const mm = Math.floor(sec / 60);
  const ss = String(sec % 60).padStart(2, '0');

  return <span style={{ fontVariantNumeric: 'tabular-nums', minWidth: '36px', display: 'inline-block', textAlign: 'center' }}>{mm}:{ss}</span>;
};

// --- STRICTLY MEMOIZED CSS ---
const GlobalTesterStyles = React.memo(() => (
  <style dangerouslySetInnerHTML={{__html: `
    @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500;1,9..144,600&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
    
    .tester-v2 {
      --bg: #0f1410; --surface: #171d18; --surface-lift: #1d2420; --surface-high: #242b26;
      --ink: #f4f3ef; --ink-soft: #c4c0b4; --ink-mute: #7a7a72;
      --line: rgba(255,255,255,0.08); --line-strong: rgba(255,255,255,0.15);
      --accent: #7ab28a; --accent-ink: #4a7c59; --accent-soft: rgba(122,178,138,0.12);
      --coral: #e8a385; --coral-soft: rgba(232,163,133,0.12);
      --warm: #f0d4a1; --warm-soft: rgba(240,212,161,0.12);
      --rose: #d88a90; --rose-soft: rgba(216,138,144,0.14);
      --radius: 12px;
      font-family: 'IBM Plex Sans', system-ui, sans-serif;
      color: var(--ink); font-size: 15px; line-height: 1.5;
      min-height: 100vh; background: radial-gradient(ellipse at 15% 0%, rgba(122,178,138,0.12) 0%, transparent 50%), radial-gradient(ellipse at 85% 100%, rgba(232,163,133,0.08) 0%, transparent 50%), linear-gradient(180deg, #0d1210 0%, #10160f 100%);
      background-attachment: fixed; position: relative; overflow-x: hidden;
    }

    .tester-v2 * { box-sizing: border-box; }
    
    .tester-v2::before { content: ''; position: fixed; inset: 0; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.06 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E"); pointer-events: none; z-index: 1; opacity: 0.6; }
    .tester-v2::after { content: ''; position: fixed; top: -200px; left: 50%; transform: translateX(-50%); width: 800px; height: 800px; background: radial-gradient(circle, rgba(122,178,138,0.06) 0%, transparent 60%); pointer-events: none; z-index: 0; animation: orbFloat 12s ease-in-out infinite; }
    @keyframes orbFloat { 0%, 100% { transform: translateX(-50%) translateY(0); } 50% { transform: translateX(-50%) translateY(30px); } }

    .wrap { position: relative; z-index: 2; min-height: 100vh; display: flex; flex-direction: column; padding: 32px 24px; max-width: 600px; margin: 0 auto; }

    /* WELCOME STYLES */
    .top-chip { display: inline-flex; align-items: center; gap: 10px; padding: 8px 14px; background: rgba(255,255,255,0.04); border: 1px solid var(--line); border-radius: 999px; font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-soft); align-self: flex-start; margin-bottom: 28px; backdrop-filter: blur(10px); animation: slideDown 0.6s cubic-bezier(.2,.6,.2,1); }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
    .brand-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); animation: dotPulse 2s ease-in-out infinite; }
    @keyframes dotPulse { 0%, 100% { box-shadow: 0 0 0 0 rgba(122,178,138,0.6); } 50% { box-shadow: 0 0 0 4px rgba(122,178,138,0); } }

    .hero { margin-bottom: 36px; animation: fadeSlide 0.8s 0.15s both cubic-bezier(.2,.6,.2,1); }
    @keyframes fadeSlide { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
    .greeting { font-family: 'Fraunces', serif; font-size: 52px; font-weight: 500; line-height: 1.02; letter-spacing: -0.03em; margin: 0 0 16px; color: var(--ink); }
    .greeting em { font-style: italic; color: var(--accent); font-weight: 500; }
    .hero-sub { font-size: 16px; color: var(--ink-soft); margin: 0; max-width: 440px; line-height: 1.5; }
    .hero-sub b { color: var(--ink); font-weight: 500; }

    .journey { background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius); padding: 22px 24px; margin-bottom: 28px; backdrop-filter: blur(20px); animation: fadeSlide 0.8s 0.3s both cubic-bezier(.2,.6,.2,1); }
    .journey-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 14px; font-weight: 500; }
    .journey-stats { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }
    .j-stat .j-value { font-family: 'Fraunces', serif; font-size: 28px; font-weight: 600; line-height: 1; letter-spacing: -0.01em; color: var(--ink); margin-bottom: 4px; }
    .j-stat .j-value em { font-style: italic; color: var(--accent); font-weight: 500; }
    .j-stat .j-label { font-size: 11px; color: var(--ink-mute); font-family: 'JetBrains Mono', monospace; text-transform: uppercase; letter-spacing: 0.1em; }

    .form-section { animation: fadeSlide 0.8s 0.45s both cubic-bezier(.2,.6,.2,1); }
    .form-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 14px; font-weight: 500; display: flex; align-items: center; gap: 10px; }
    .form-label::after { content: ''; flex: 1; height: 1px; background: var(--line); }
    .detected-badge { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.08em; color: var(--accent); padding: 3px 8px; background: var(--accent-soft); border-radius: 4px; }

    .field-stack { display: flex; flex-direction: column; gap: 12px; margin-bottom: 28px; }
    .field { position: relative; }
    .field-input-wrap { position: relative; display: flex; align-items: center; }
    .field-icon { position: absolute; left: 16px; color: var(--ink-mute); transition: color 0.2s ease; pointer-events: none; }
    .field:focus-within .field-icon { color: var(--accent); }
    .field input { box-sizing: border-box; width: 100%; height: 56px; padding: 0 16px 0 50px; font-family: inherit; font-size: 15px; color: var(--ink); background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius); transition: all 0.2s ease; }
    .field input::placeholder { color: var(--ink-mute); }
    .field input:hover { border-color: var(--line-strong); background: var(--surface-lift); }
    .field input:focus { outline: none; border-color: var(--accent); background: var(--surface-lift); box-shadow: 0 0 0 4px var(--accent-soft); }
    .field-confirm { position: absolute; right: 16px; top: 50%; transform: translateY(-50%); opacity: 0; transition: opacity 0.3s ease; color: var(--accent); }
    .field.valid .field-confirm { opacity: 1; }

    .start-btn { width: 100%; height: 60px; border: none; background: var(--ink); color: var(--bg); font-family: 'Fraunces', serif; font-size: 18px; font-weight: 500; letter-spacing: -0.01em; border-radius: var(--radius); cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; position: relative; overflow: hidden; transition: all 0.3s cubic-bezier(.2,.6,.2,1); opacity: 0.3; pointer-events: none; }
    .start-btn.ready { opacity: 1; pointer-events: auto; box-shadow: 0 8px 30px rgba(122,178,138,0.25); }
    .start-btn.ready:hover { background: var(--accent); transform: translateY(-2px); box-shadow: 0 12px 40px rgba(122,178,138,0.4); }
    .start-btn .arrow { transition: transform 0.3s cubic-bezier(.2,.6,.2,1); }
    .start-btn.ready:hover .arrow { transform: translateX(4px); }
    .start-btn.ready::before { content: ''; position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(122,178,138,0.2), transparent); animation: btnShimmer 3s ease-in-out infinite; }
    @keyframes btnShimmer { 0%, 100% { left: -100%; } 50% { left: 100%; } }

    .trust-strip { display: flex; justify-content: center; align-items: center; gap: 20px; margin-top: 28px; font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--ink-mute); animation: fadeSlide 0.8s 0.6s both cubic-bezier(.2,.6,.2,1); }
    .trust-item { display: inline-flex; align-items: center; gap: 6px; }
    .trust-item svg { color: var(--accent); }

    /* TESTING STYLES */
    .top-bar { position: sticky; top: 0; z-index: 10; padding: 20px 28px; display: flex; align-items: center; justify-content: space-between; gap: 20px; background: rgba(15,20,16,0.8); backdrop-filter: blur(20px); border-bottom: 1px solid var(--line); }
    .top-left { display: flex; align-items: center; gap: 14px; min-width: 0; }
    .top-title { font-family: 'Fraunces', serif; font-size: 17px; font-weight: 600; letter-spacing: -0.01em; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .top-sub { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.1em; }
    .top-right { display: flex; align-items: center; gap: 14px; }
    .time-chip { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; background: rgba(255,255,255,0.04); border: 1px solid var(--line); border-radius: 999px; font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--ink-soft); }

    .progress-trail { padding: 16px 28px 0; display: flex; gap: 8px; max-width: 900px; margin: 0 auto; position: relative; z-index: 2; }
    .trail-node { flex: 1; height: 5px; background: rgba(255,255,255,0.08); border-radius: 999px; position: relative; overflow: hidden; transition: transform 0.15s ease; cursor: pointer; }
    .trail-node:hover { transform: translateY(-1px); }
    .trail-node.pass { background: var(--accent); }
    .trail-node.fail { background: var(--rose); }
    .trail-node.current { background: rgba(255,255,255,0.15); }
    .trail-node.current::after { content: ''; position: absolute; inset: 0; background: linear-gradient(90deg, transparent, var(--accent), transparent); animation: trailPulse 1.8s ease-in-out infinite; }
    @keyframes trailPulse { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }

    .stage { position: relative; z-index: 2; max-width: 720px; margin: 0 auto; padding: 32px 24px 160px; }
    
    .step-card { background: var(--surface); border: 1px solid var(--line); border-radius: 20px; padding: 32px; margin-bottom: 16px; position: relative; animation: stepIn 0.5s cubic-bezier(.2,.6,.2,1) both; backdrop-filter: blur(20px); }
    @keyframes stepIn { from { opacity: 0; transform: translateY(20px) scale(0.98); } to { opacity: 1; transform: translateY(0) scale(1); } }
    .step-card.passing { animation: stepPass 0.6s cubic-bezier(.5,.0,.8,.3) forwards; }
    @keyframes stepPass { 0% { transform: translateY(0) scale(1); } 30% { transform: translateY(0) scale(1.02); box-shadow: 0 0 60px rgba(122,178,138,0.4); } 100% { transform: translateY(-40px) scale(0.95); opacity: 0; } }
    .step-card.failing { animation: stepFail 0.5s cubic-bezier(.3,0,.5,.3) forwards; }
    @keyframes stepFail { 0% { transform: translateX(0); } 20% { transform: translateX(-8px); } 40% { transform: translateX(8px); } 60% { transform: translateX(-4px); } 80% { transform: translateX(4px); } 100% { transform: translateX(0); } }

    .step-meta { display: flex; align-items: center; gap: 10px; margin-bottom: 20px; }
    .step-number { font-family: 'JetBrains Mono', monospace; font-size: 11px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); padding: 4px 10px; background: rgba(255,255,255,0.04); border: 1px solid var(--line); border-radius: 4px; font-weight: 500; }
    .step-priority { display: inline-flex; align-items: center; gap: 5px; font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; padding: 3px 8px; border-radius: 4px; font-weight: 500; }
    .step-priority.high { color: var(--rose); background: var(--rose-soft); }
    .step-priority.high::before { content: ''; width: 5px; height: 5px; border-radius: 50%; background: var(--rose); }

    .step-action { font-family: 'Fraunces', serif; font-size: 28px; font-weight: 500; line-height: 1.2; letter-spacing: -0.02em; margin: 0 0 20px; }
    .step-expected-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--accent); margin-bottom: 8px; font-weight: 500; display: flex; align-items: center; gap: 6px; }
    .step-expected-label::before { content: ''; width: 16px; height: 1px; background: var(--accent); }
    .step-expected { font-size: 16px; color: var(--ink-soft); margin: 0 0 24px; line-height: 1.5; padding-left: 22px; border-left: 2px solid var(--accent-soft); }

    .step-attachments { display: flex; gap: 10px; flex-wrap: wrap; padding-top: 20px; border-top: 1px dashed var(--line); }
    .attachment { position: relative; border-radius: 8px; overflow: hidden; cursor: pointer; transition: transform 0.2s ease; }
    .attachment:hover { transform: translateY(-3px); }
    .attachment.image { width: 110px; height: 78px; border: 1px solid var(--line-strong); background-size: cover; background-position: center; }
    .attachment.link { display: inline-flex; align-items: center; gap: 10px; padding: 12px 14px; height: 78px; background: rgba(255,255,255,0.04); border: 1px solid var(--line-strong); color: var(--ink); font-size: 13px; font-weight: 500; max-width: 260px; }
    .attachment.link .link-ico { width: 28px; height: 28px; border-radius: 6px; background: #f24e1e; color: #fff; display: flex; align-items: center; justify-content: center; font-family: 'JetBrains Mono', monospace; font-size: 11px; font-weight: 700; flex-shrink: 0; }
    .attachment.link .link-info { min-width: 0; }
    .attachment.link .link-title { color: var(--ink); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .attachment.link .link-host { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--ink-mute); margin-top: 2px; }

    .peek-card { background: var(--surface); border: 1px solid var(--line); border-radius: 16px; padding: 20px 24px; margin-top: 12px; transform: scale(0.95); opacity: 0.55; transition: all 0.3s cubic-bezier(.2,.6,.2,1); cursor: default; position: relative; }
    .peek-card::before { content: 'UP NEXT'; position: absolute; top: -9px; left: 24px; font-family: 'JetBrains Mono', monospace; font-size: 9px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); background: var(--bg); padding: 2px 8px; border: 1px solid var(--line); border-radius: 4px; }
    .peek-step-num { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 6px; }
    .peek-action { font-family: 'Fraunces', serif; font-size: 17px; font-weight: 500; color: var(--ink-soft); margin: 0; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

    .action-bar { position: fixed; bottom: 0; left: 0; right: 0; z-index: 20; padding: 20px 24px calc(20px + env(safe-area-inset-bottom)); background: linear-gradient(180deg, transparent 0%, rgba(15,20,16,0.95) 40%); backdrop-filter: blur(20px); transition: opacity 0.3s; }
    .action-row { max-width: 720px; margin: 0 auto; display: grid; grid-template-columns: 1fr 2fr; gap: 10px; }
    .abtn { height: 64px; border: none; border-radius: 16px; font-family: 'Fraunces', serif; font-size: 17px; font-weight: 500; letter-spacing: -0.01em; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.2s cubic-bezier(.2,.6,.2,1); position: relative; overflow: hidden; }
    .btn-fail { background: var(--surface-lift); color: var(--ink-soft); border: 1px solid var(--line-strong); }
    .btn-fail:hover { background: var(--rose-soft); color: var(--rose); border-color: var(--rose); transform: translateY(-2px); }
    .btn-pass { background: var(--accent); color: var(--bg); box-shadow: 0 10px 30px rgba(122,178,138,0.3); }
    .btn-pass:hover { transform: translateY(-2px); box-shadow: 0 14px 40px rgba(122,178,138,0.45); background: #8fc49e; }

    .fail-panel { position: fixed; bottom: 0; left: 0; right: 0; z-index: 30; background: var(--surface-high); border-top: 1px solid var(--line-strong); border-radius: 24px 24px 0 0; padding: 24px 24px calc(24px + env(safe-area-inset-bottom)); transform: translateY(100%); transition: transform 0.35s cubic-bezier(.2,.6,.2,1); max-height: 85vh; overflow-y: auto; box-shadow: 0 -20px 60px rgba(0,0,0,0.4); }
    .fail-panel.open { transform: translateY(0); }
    .fail-panel-inner { max-width: 720px; margin: 0 auto; }
    .fail-handle { width: 40px; height: 4px; background: var(--line-strong); border-radius: 2px; margin: 0 auto 20px; }
    .fail-title { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 500; letter-spacing: -0.01em; margin: 0 0 6px; }
    .fail-sub { color: var(--ink-mute); font-size: 13px; margin: 0 0 20px; }
    .reason-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 10px; font-weight: 500; }
    .reason-chips { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 24px; }
    .reason-chip { padding: 10px 16px; background: var(--surface); border: 1px solid var(--line); border-radius: 999px; font-family: inherit; font-size: 13px; color: var(--ink-soft); cursor: pointer; transition: all 0.15s ease; }
    .reason-chip:hover { border-color: var(--line-strong); color: var(--ink); }
    .reason-chip.selected { background: var(--rose-soft); border-color: var(--rose); color: var(--rose); }
    .fail-notes { box-sizing: border-box; width: 100%; min-height: 100px; padding: 14px 16px; background: var(--surface); border: 1px solid var(--line); border-radius: 12px; font-family: inherit; font-size: 14px; color: var(--ink); resize: vertical; margin-bottom: 16px; }
    .fail-notes:focus { outline: none; border-color: var(--accent); }
    .fail-notes::placeholder { color: var(--ink-mute); }
    .fail-attach-row { display: flex; gap: 10px; margin-bottom: 24px; flex-wrap: wrap; align-items: center; }
    .attach-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 14px; background: var(--surface); border: 1px dashed var(--line-strong); border-radius: 10px; font-family: inherit; font-size: 13px; color: var(--ink-soft); cursor: pointer; transition: all 0.15s ease; }
    .attach-btn:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); border-style: solid; }
    .fail-actions { display: grid; grid-template-columns: 1fr 2fr; gap: 10px; }
    .btn-cancel, .btn-submit { height: 56px; border: none; border-radius: 14px; font-family: 'Fraunces', serif; font-size: 16px; font-weight: 500; cursor: pointer; transition: all 0.2s ease; }
    .btn-cancel { background: var(--surface); color: var(--ink-soft); border: 1px solid var(--line-strong); }
    .btn-cancel:hover { color: var(--ink); }
    .btn-submit { background: var(--rose); color: var(--bg); }
    .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 10px 24px rgba(216,138,144,0.35); }

    .pass-flash { position: fixed; inset: 0; pointer-events: none; z-index: 40; display: flex; align-items: center; justify-content: center; opacity: 0; }
    .pass-flash.show { animation: passFlash 1s cubic-bezier(.2,.6,.2,1) forwards; }
    @keyframes passFlash { 0% { opacity: 0; backdrop-filter: blur(0); } 15% { opacity: 1; backdrop-filter: blur(20px); } 60% { opacity: 1; } 100% { opacity: 0; backdrop-filter: blur(0); } }
    .pass-flash-content { text-align: center; transform: scale(0.5); opacity: 0; }
    .pass-flash.show .pass-flash-content { animation: passPop 0.8s 0.1s cubic-bezier(.3,1.6,.5,1) forwards; }
    @keyframes passPop { to { transform: scale(1); opacity: 1; } }
    .pass-tick { width: 100px; height: 100px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; color: var(--bg); box-shadow: 0 0 60px rgba(122,178,138,0.6); }
    .pass-text { font-family: 'Fraunces', serif; font-size: 36px; font-weight: 500; letter-spacing: -0.02em; color: var(--ink); }

    .overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); opacity: 0; pointer-events: none; transition: opacity 0.25s ease; z-index: 25; backdrop-filter: blur(4px); }
    .overlay.show { opacity: 1; pointer-events: auto; }

    /* COMPLETE STYLES */
    .medal-wrap { position: relative; margin-bottom: 28px; animation: medalIn 0.9s cubic-bezier(.3,1.6,.5,1) both; }
    @keyframes medalIn { 0% { opacity: 0; transform: scale(0.3) rotate(-20deg); } 60% { opacity: 1; transform: scale(1.1) rotate(5deg); } 100% { opacity: 1; transform: scale(1) rotate(0); } }
    .medal { width: 110px; height: 110px; border-radius: 50%; background: linear-gradient(135deg, var(--accent) 0%, var(--accent-ink) 100%); display: flex; align-items: center; justify-content: center; color: var(--bg); box-shadow: 0 0 0 8px rgba(122,178,138,0.15), 0 0 0 16px rgba(122,178,138,0.08), 0 20px 50px rgba(122,178,138,0.35); position: relative; }
    .big-stats { width: 100%; background: var(--surface); border: 1px solid var(--line); border-radius: 20px; padding: 28px; margin-bottom: 16px; display: grid; grid-template-columns: 1fr 1px 1fr; gap: 20px; backdrop-filter: blur(20px); animation: fadeSlide 0.8s 0.35s both cubic-bezier(.2,.6,.2,1); }
    .stat-divider { background: var(--line); width: 1px; height: 100%; }
    .big-stat { text-align: center; }
    .big-stat .bs-value { font-family: 'Fraunces', serif; font-size: 48px; font-weight: 600; line-height: 1; letter-spacing: -0.02em; color: var(--ink); margin-bottom: 6px; }
    .big-stat .bs-value em { font-style: italic; font-weight: 500; color: var(--accent); }
    .big-stat .bs-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); }
    
    .percentile { width: 100%; background: linear-gradient(135deg, rgba(122,178,138,0.15) 0%, rgba(232,163,133,0.1) 100%); border: 1px solid rgba(122,178,138,0.2); border-radius: 16px; padding: 20px 24px; display: flex; align-items: center; gap: 16px; margin-bottom: 28px; backdrop-filter: blur(20px); animation: fadeSlide 0.8s 0.5s both cubic-bezier(.2,.6,.2,1); }
    .pct-badge { width: 56px; height: 56px; border-radius: 50%; background: var(--accent); color: var(--bg); display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 6px 20px rgba(122,178,138,0.35); }
    .pct-text { flex: 1; min-width: 0; }
    .pct-headline { font-family: 'Fraunces', serif; font-size: 22px; font-weight: 500; letter-spacing: -0.01em; line-height: 1.2; margin: 0 0 4px; }
    .pct-headline em { font-style: italic; color: var(--accent); font-weight: 600; }
    .pct-sub { font-size: 12px; color: var(--ink-mute); margin: 0; font-family: 'JetBrains Mono', monospace; }

    .results { width: 100%; background: var(--surface); border: 1px solid var(--line); border-radius: 16px; padding: 20px 24px; margin-bottom: 28px; backdrop-filter: blur(20px); animation: fadeSlide 0.8s 0.6s both cubic-bezier(.2,.6,.2,1); }
    .results-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 14px; font-weight: 500; }
    .results-bar { height: 10px; background: rgba(255,255,255,0.05); border-radius: 999px; overflow: hidden; display: flex; margin-bottom: 14px; }
    .results-bar .seg { height: 100%; }
    .results-legend { display: flex; justify-content: space-between; font-size: 12px; }
    .legend-item { display: inline-flex; align-items: center; gap: 6px; color: var(--ink-soft); font-family: 'JetBrains Mono', monospace; }
    .legend-dot { width: 8px; height: 8px; border-radius: 50%; }
    .legend-dot.pass { background: var(--accent); } .legend-dot.fail { background: var(--rose); }

    .c-actions { width: 100%; display: flex; flex-direction: column; gap: 10px; animation: fadeSlide 0.8s 0.75s both cubic-bezier(.2,.6,.2,1); }
    .c-btn { height: 56px; padding: 0 22px; border: none; border-radius: 14px; font-family: 'Fraunces', serif; font-size: 16px; font-weight: 500; letter-spacing: -0.01em; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.2s cubic-bezier(.2,.6,.2,1); }
    .c-btn-primary { background: var(--accent); color: var(--bg); box-shadow: 0 10px 30px rgba(122,178,138,0.3); }
    .c-btn-primary:hover { transform: translateY(-2px); background: #8fc49e; box-shadow: 0 14px 40px rgba(122,178,138,0.45); }
    .c-btn-secondary { background: rgba(255,255,255,0.04); color: var(--ink-soft); border: 1px solid var(--line-strong); }
    .c-btn-secondary:hover { background: rgba(255,255,255,0.08); color: var(--ink); }

    .thank-you { margin-top: 32px; text-align: center; color: var(--ink-mute); font-size: 13px; font-family: 'JetBrains Mono', monospace; animation: fadeSlide 0.8s 0.9s both cubic-bezier(.2,.6,.2,1); }
    .thank-you svg { color: var(--rose); vertical-align: -2px; margin: 0 4px; }

    .confetti-layer { position: fixed; inset: 0; pointer-events: none; z-index: 5; overflow: hidden; }
    .confetti { position: absolute; width: 8px; height: 14px; border-radius: 2px; opacity: 0; }
    .confetti.fire { animation: confettiFall 4s cubic-bezier(.2,.6,.4,1) forwards; }
    @keyframes confettiFall { 0% { opacity: 0; transform: translateY(-30px) rotate(0); } 10% { opacity: 1; } 85% { opacity: 1; } 100% { opacity: 0; transform: translateY(110vh) rotate(720deg); } }

    /* QR MODAL (from PM page style) */
    .qr-full { position: fixed; inset: 0; background: rgba(18,26,23,0.6); backdrop-filter: blur(6px); display: none; align-items: center; justify-content: center; z-index: 50; }
    .qr-full.show { display: flex; animation: fadeIn 0.2s ease; }
    .qr-full-card { background: var(--surface); border-radius: 16px; padding: 32px; text-align: center; max-width: 400px; box-shadow: 0 24px 60px rgba(0,0,0,0.5); }
    .qr-full-eyebrow { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--ink-mute); margin-bottom: 4px; }
    .qr-full-title { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 600; letter-spacing: -0.01em; margin: 0 0 20px; }
    .qr-full-img { width: 260px; height: 260px; background: var(--surface); border: 2px solid var(--ink); border-radius: 12px; margin: 0 auto 20px; padding: 18px; position: relative; display: flex; align-items: center; justify-content: center; }
    .qr-close-btn { background: var(--surface); border: 1px solid var(--line-strong); color: var(--ink-soft); height: 40px; padding: 0 20px; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 13px; font-weight: 500; width: 100%; }
    .qr-close-btn:hover { background: var(--surface-lift); color: var(--ink); }

    /* =========================================
       NEW RESULTS STAGE STYLES 
       ========================================= */
    .results-hero { text-align: center; padding: 48px 24px 32px; animation: fadeSlide 0.6s cubic-bezier(.2,.6,.2,1) both; }
    .results-hero-title { font-family: 'Fraunces', serif; font-size: 40px; font-weight: 600; letter-spacing: -0.02em; margin: 0 0 12px; color: var(--ink); }
    .results-hero-sub { font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--ink-mute); text-transform: uppercase; letter-spacing: 0.1em; }

    .timeline { max-width: 720px; margin: 0 auto; padding: 0 24px 60px; display: flex; flex-direction: column; gap: 16px; }
    
    .timeline-card { background: var(--surface); border: 1px solid var(--line); border-radius: 16px; padding: 24px; position: relative; overflow: hidden; opacity: 0; animation: fadeSlide 0.5s cubic-bezier(.2,.6,.2,1) forwards; }
    .timeline-card::before { content: ''; position: absolute; top: 0; bottom: 0; left: 0; width: 4px; }
    .timeline-card.t-pass { border-color: rgba(122,178,138,0.2); }
    .timeline-card.t-pass::before { background: var(--accent); }
    .timeline-card.t-fail { border-color: rgba(216,138,144,0.2); }
    .timeline-card.t-fail::before { background: var(--rose); }
    
    .timeline-meta { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
    .t-step-num { font-family: 'JetBrains Mono', monospace; font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-mute); }
    .t-status { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 500; display: flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 999px; }
    .t-status.pass { background: var(--accent-soft); color: var(--accent); }
    .t-status.fail { background: var(--rose-soft); color: var(--rose); }

    .timeline-action { font-size: 16px; font-weight: 500; color: var(--ink); margin: 0 0 8px; line-height: 1.4; }
    .timeline-expected { font-size: 14px; color: var(--ink-soft); margin: 0; padding-left: 14px; border-left: 2px solid var(--line-strong); }

    .timeline-notes { margin-top: 20px; padding: 16px; background: rgba(255,255,255,0.03); border: 1px solid var(--line); border-radius: 8px; }
    .t-notes-label { font-family: 'JetBrains Mono', monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--rose); margin-bottom: 8px; }
    .t-notes-text { font-size: 13px; color: var(--ink-soft); line-height: 1.5; margin-bottom: 12px; }
    
    .t-evidence-row { display: flex; gap: 8px; flex-wrap: wrap; }
    .t-evidence-item { width: 60px; height: 60px; border-radius: 6px; border: 1px solid var(--line); background-size: cover; background-position: center; cursor: pointer; transition: transform 0.2s ease; }
    .t-evidence-item:hover { transform: translateY(-2px); border-color: var(--rose); }
    
    .t-evidence-vid { width: 60px; height: 60px; border-radius: 6px; border: 1px solid var(--line); background: #333; display: flex; align-items: center; justify-content: center; color: #fff; cursor: pointer; }

    @media (max-width: 600px) {
      .step-card { padding: 24px 20px; border-radius: 16px; }
      .step-action { font-size: 24px; }
      .top-bar { padding: 14px 16px; }
      .top-title { font-size: 15px; }
      .time-chip { padding: 5px 10px; font-size: 10px; }
      .stage { padding: 20px 16px 140px; }
      .progress-trail { padding: 12px 16px 0; }
      .action-bar { padding: 16px 16px calc(16px + env(safe-area-inset-bottom)); }
      .btn { height: 56px; font-size: 15px; }
      .action-row { grid-template-columns: 1fr 1.6fr; }
      .hero-title { font-size: 40px; }
      .medal { width: 90px; height: 90px; }
      .big-stat .bs-value { font-size: 36px; }
      .big-stats { padding: 22px; }
      .pct-headline { font-size: 18px; }
      .pct-badge { width: 48px; height: 48px; }
    }
  `}} />
));

export default function TesterExecutionEngine() {
  const params = useParams();
  const runId = (params?.id || params?.testRunId || '') as string;
  
  const [runData, setRunData] = useState<TestRunData | null>(null);
  const [stage, setStage] = useState<TesterStage>('LOADING');
  const [errorMsg, setErrorMsg] = useState('');
  
  // Welcome State
  const [device, setDevice] = useState('');
  const [os, setOs] = useState('');
  const [browser, setBrowser] = useState('');
  const [autoDetected, setAutoDetected] = useState(false);

  // Testing & Timer State
  const [currentIdx, setCurrentIdx] = useState(0);
  const [sessionStartTime, setSessionStartTime] = useState(Date.now());
  const [cumulativeTimeMs, setCumulativeTimeMs] = useState(0);
  const cumulativeTimeRef = useRef(0);
  const sessionStartRef = useRef(Date.now());
  
  // Animations & Overlays
  const [animatingState, setAnimatingState] = useState<'pass' | 'fail' | null>(null);
  const [showPassFlash, setShowPassFlash] = useState(false);
  const [passFlashMsg, setPassFlashMsg] = useState('Nice.');
  
  // Fail Panel State
  const [failPanelOpen, setFailPanelOpen] = useState(false);
  const [failChips, setFailChips] = useState<string[]>([]);
  const [failNotes, setFailNotes] = useState('');
  const [failMediaUrls, setFailMediaUrls] = useState<string[]>([]);
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);

  // QR Mobile Upload State
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [uploadToken, setUploadToken] = useState('');
  const [uploadUrl, setUploadUrl] = useState('');

  const confettiContainerRef = useRef<HTMLDivElement>(null);

  // 1. Fetch Data
  useEffect(() => {
    if (!runId) return;
    const docRef = doc(db, 'testRuns', runId);
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as TestRunData;
        setRunData({ id: docSnap.id, ...data });
        
        if (data.cumulativeTimeMs && cumulativeTimeRef.current === 0) {
          setCumulativeTimeMs(data.cumulativeTimeMs);
          cumulativeTimeRef.current = data.cumulativeTimeMs;
        }

        if (data.isCompleted && stage === 'LOADING') {
          setStage('COMPLETE');
        } else if (stage === 'LOADING') {
          const firstUncompleted = data.steps?.findIndex(s => !data.results?.[s.id]);
          setCurrentIdx(firstUncompleted === -1 ? 0 : (firstUncompleted || 0));
          setStage('WELCOME');
        }
      } else {
        setErrorMsg("Test run not found or link has expired.");
      }
    }, (err) => {
      setErrorMsg("Unable to connect to database.");
    });
    return () => unsubscribe();
  }, [runId, stage]);

  // 2. Background Timer Sync
  useEffect(() => {
    if (stage !== 'TESTING' || !runId) return;
    sessionStartRef.current = Date.now();
    const syncInterval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - sessionStartRef.current;
      cumulativeTimeRef.current += elapsed;
      sessionStartRef.current = now;
      updateDoc(doc(db, 'testRuns', runId), { cumulativeTimeMs: cumulativeTimeRef.current }).catch(() => {});
      setCumulativeTimeMs(cumulativeTimeRef.current);
      setSessionStartTime(now);
    }, 10000);
    return () => clearInterval(syncInterval);
  }, [stage, runId]);

  // 3. Auto-detect environment
  useEffect(() => {
    if (stage === 'WELCOME' && runData) {
      if (runData.deviceInfo?.device) {
        setDevice(runData.deviceInfo.device);
        setOs(runData.deviceInfo.os);
        setBrowser(runData.deviceInfo.browser);
      } else {
        setTimeout(() => {
          const ua = navigator.userAgent;
          let d = '', o = '', b = '';
          if (/iPhone|iPad|iPod/.test(ua)) { d = /iPad/.test(ua) ? 'iPad' : 'iPhone'; const m = ua.match(/OS (\d+[_\.]\d+)/); o = m ? `iOS ${m[1].replace('_', '.')}` : 'iOS'; }
          else if (/Android/.test(ua)) { d = 'Android device'; const m = ua.match(/Android (\d+(\.\d+)?)/); o = m ? `Android ${m[1]}` : 'Android'; }
          else if (/Macintosh/.test(ua)) { d = 'Mac'; const m = ua.match(/Mac OS X (\d+[_\.]\d+)/); o = m ? `macOS ${m[1].replace('_', '.')}` : 'macOS'; }
          else if (/Windows/.test(ua)) { d = 'Windows PC'; o = /Windows NT 10/.test(ua) ? 'Windows 10/11' : 'Windows'; }
          
          if (/Edg\//.test(ua)) b = 'Edge';
          else if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) b = 'Chrome';
          else if (/Firefox\//.test(ua)) b = 'Firefox';
          else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) b = 'Safari';

          if (d || o || b) setAutoDetected(true);
          if (d) setDevice(d);
          if (o) setOs(o);
          if (b) setBrowser(b);
        }, 500);
      }
    }
  }, [stage, runData]);

  // 4. Mobile QR Upload Listener
  useEffect(() => {
    if (!qrModalOpen || !uploadToken) return;
    const docRef = doc(db, 'mobileUploads', uploadToken);
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists() && docSnap.data().url) {
        setFailMediaUrls(prev => [...prev, docSnap.data().url]);
        setQrModalOpen(false);
      }
    });
    return () => unsubscribe();
  }, [qrModalOpen, uploadToken]);

  // --- EARLY RETURNS ---
  if (errorMsg) return <div style={{ background: '#0f1410', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'system-ui, sans-serif' }}><div style={{ textAlign: 'center' }}><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{color: '#a6421f', marginBottom: '16px'}}><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><h2 style={{fontWeight: 500, fontSize: '24px', margin: '0 0 8px'}}>{errorMsg}</h2><p style={{ color: '#7a7a72' }}>Please check the URL or contact your PM.</p></div></div>;
  if (!runData || stage === 'LOADING') return <div style={{ background: '#0f1410', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7ab28a', fontFamily: 'system-ui, sans-serif', fontSize: '14px' }}>Loading test environment...</div>;

  const currentStep = runData.steps?.[currentIdx];
  const nextStep = runData.steps?.[currentIdx + 1];
  const isReadyToStart = device.trim() && os.trim() && browser.trim();
  const isResuming = currentIdx > 0;

  // --- CORE ACTIONS ---
  const handleStart = async () => {
    await updateDoc(doc(db, 'testRuns', runId), { deviceInfo: { device, os, browser } });
    setSessionStartTime(Date.now());
    sessionStartRef.current = Date.now();
    setStage('TESTING');
  };

  const saveResultAndAdvance = async (status: 'Passed' | 'Failed') => {
    if (!currentStep) return;
    
    const notesStr = failChips.length > 0 ? `[${failChips.join(', ')}] ${failNotes}` : failNotes;
    
    const now = Date.now();
    const elapsedSinceSync = now - sessionStartRef.current;
    cumulativeTimeRef.current += elapsedSinceSync;
    sessionStartRef.current = now;

    await updateDoc(doc(db, 'testRuns', runId), {
      [`results.${currentStep.id}`]: {
        status, notes: status === 'Failed' ? notesStr : '', evidenceUrls: status === 'Failed' ? failMediaUrls : []
      },
      cumulativeTimeMs: cumulativeTimeRef.current
    });

    setCumulativeTimeMs(cumulativeTimeRef.current);
    setSessionStartTime(now);

    if (currentIdx >= runData.steps.length - 1) {
      await updateDoc(doc(db, 'testRuns', runId), { isCompleted: true, completedAt: serverTimestamp() });
      setStage('COMPLETE');
      triggerConfetti();
    } else {
      setCurrentIdx(prev => prev + 1);
      setFailChips([]); setFailNotes(''); setFailMediaUrls([]);
    }
  };

  const handlePass = () => {
    const msgs = ['Nice.', 'Sweet.', 'Smashing.', 'Lovely.', 'Top-notch.'];
    setPassFlashMsg(msgs[Math.floor(Math.random() * msgs.length)]);
    setAnimatingState('pass');
    setShowPassFlash(true);
    
    setTimeout(() => {
      setShowPassFlash(false);
      setAnimatingState(null);
      saveResultAndAdvance('Passed');
    }, 900);
  };

  const handleFailSubmit = () => {
    setFailPanelOpen(false);
    setAnimatingState('fail');
    setTimeout(() => {
      setAnimatingState(null);
      saveResultAndAdvance('Failed');
    }, 400);
  };

  const handleDesktopUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingMedia(true);
    try {
      const storageRef = ref(storage, `tester_evidence/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadedUrl = await getDownloadURL(storageRef);
      setFailMediaUrls(prev => [...prev, downloadedUrl]);
    } catch (error) { 
      alert("Upload failed."); 
    } finally { 
      setIsUploadingMedia(false); 
    }
  };

  const openQrScanner = () => {
    const token = Math.random().toString(36).substring(2, 15);
    setUploadToken(token);
    setUploadUrl(`${window.location.origin}/mobile-upload/${token}`);
    setQrModalOpen(true);
  };

  const triggerConfetti = () => {
    setTimeout(() => {
      if (!confettiContainerRef.current) return;
      const colors = ['#7ab28a', '#e8a385', '#f0d4a1', '#d88a90', '#c4c0b4'];
      const waves = [{ count: 30, delay: 200 }, { count: 20, delay: 900 }, { count: 16, delay: 1700 }, { count: 12, delay: 2500 }];
      
      waves.forEach(w => {
        setTimeout(() => {
          for (let i = 0; i < w.count; i++) {
            const el = document.createElement('div');
            el.className = 'confetti fire';
            el.style.background = colors[Math.floor(Math.random() * colors.length)];
            el.style.left = Math.random() * 100 + '%';
            el.style.top = '-20px';
            el.style.width = 7 + Math.random() * 5 + 'px';
            el.style.height = 12 + Math.random() * 8 + 'px';
            el.style.animationDelay = Math.random() * 0.5 + 's';
            el.style.animationDuration = 3.5 + Math.random() * 2.5 + 's';
            confettiContainerRef.current?.appendChild(el);
            setTimeout(() => el.remove(), 7000);
          }
        }, w.delay);
      });
    }, 500);
  };

  // --- STATS ---
  const passedCount = (runData.steps || []).filter(s => runData.results?.[s.id]?.status === 'Passed').length;
  const failedCount = (runData.steps || []).filter(s => runData.results?.[s.id]?.status === 'Failed').length;
  const totalStepsCount = runData.steps?.length || 0;
  const passPct = totalStepsCount > 0 ? (passedCount / totalStepsCount) * 100 : 0;
  const failPct = totalStepsCount > 0 ? (failedCount / totalStepsCount) * 100 : 0;
  
  const secTotal = Math.floor(cumulativeTimeMs / 1000);
  const finalMin = Math.floor(secTotal / 60);
  const finalSec = String(secTotal % 60).padStart(2, '0');

  let pct = 25;
  if (secTotal < 120) pct = 95;
  else if (secTotal < 180) pct = 88;
  else if (secTotal < 240) pct = 82;
  else if (secTotal < 360) pct = 65;
  else if (secTotal < 600) pct = 45;

  return (
    <div className="tester-v2">
      <GlobalTesterStyles />

      {stage === 'WELCOME' && (
        <div className="wrap">
          <div className="top-chip">
            <span className="brand-dot"></span>
            QA Triage · Test Invitation
          </div>

          <div className="hero">
            <h1 className="greeting">
              {isResuming ? 'Welcome back, ' : 'Hey '}<em>{(runData.testerName || 'Tester').split(' ')[0]}</em>,<br/>
              {isResuming ? 'ready to resume?' : 'ready to test?'}
            </h1>
            <p className="hero-sub">
              {isResuming 
                ? `You have ${runData.steps.length - currentIdx} steps remaining for ${runData.projectName}. Let's pick up right where you left off.`
                : `You've been invited to test <b>${runData.projectName}</b>. It's a short one — about ${Math.ceil((runData.steps?.length || 0) * 1.5)} minutes of your time. Your feedback goes straight to the PM.`
              }
            </p>
          </div>

          <div className="journey">
            <div className="journey-label">Your journey</div>
            <div className="journey-stats">
              <div className="j-stat">
                <div className="j-value">{runData.steps?.length || 0} <em>steps</em></div>
                <div className="j-label">To complete</div>
              </div>
              <div className="j-stat">
                <div className="j-value">~{Math.ceil((runData.steps?.length || 0) * 1.5)} <em>min</em></div>
                <div className="j-label">Estimated time</div>
              </div>
              <div className="j-stat">
                <div className="j-value">{runData.testCycle || 'UAT'}</div>
                <div className="j-label">Cycle</div>
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-label">
              <span>Confirm your setup</span>
              {autoDetected && <span className="detected-badge">Auto-detected</span>}
            </div>

            <div className="field-stack">
              <div className={`field ${device.trim() ? 'valid' : ''}`}>
                <div className="field-input-wrap">
                  <svg className="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                  <input type="text" placeholder="Device (e.g. MacBook Pro, iPhone 15)" value={device} onChange={e => setDevice(e.target.value)} />
                  <svg className="field-confirm" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div className="field-hint">What you're testing on</div>
              </div>
              <div className={`field ${os.trim() ? 'valid' : ''}`}>
                <div className="field-input-wrap">
                  <svg className="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                  <input type="text" placeholder="Operating system (e.g. macOS 14, iOS 17)" value={os} onChange={e => setOs(e.target.value)} />
                  <svg className="field-confirm" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div className="field-hint">OS + version if you know it</div>
              </div>
              <div className={`field ${browser.trim() ? 'valid' : ''}`}>
                <div className="field-input-wrap">
                  <svg className="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>
                  <input type="text" placeholder="Browser (e.g. Chrome, Safari)" value={browser} onChange={e => setBrowser(e.target.value)} />
                  <svg className="field-confirm" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div className="field-hint">The browser you're testing in</div>
              </div>
            </div>

            <button className={`start-btn ${isReadyToStart ? 'ready' : ''}`} onClick={handleStart} disabled={!isReadyToStart}>
              {isResuming ? 'Resume testing' : 'Start testing'}
              <svg className="arrow" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </button>
          </div>

          <div className="trust-strip">
            <div className="trust-item"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg> Private link</div>
            <div className="trust-item"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> Saves automatically</div>
            <div className="trust-item"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg> No login needed</div>
          </div>
        </div>
      )}

      {stage === 'TESTING' && (
        <>
          <header className="top-bar">
            <div className="top-left">
              <span className="top-dot"></span>
              <div style={{minWidth: 0}}>
                <div className="top-title">{runData.projectName}</div>
                <div className="top-sub">Step {currentIdx + 1} of {runData.steps.length} · {runData.testCycle || 'UAT'}</div>
              </div>
            </div>
            <div className="top-right">
              <div className="time-chip">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                <TimerChip cumulativeMs={cumulativeTimeMs} sessionStartTime={sessionStartTime} isRunning={stage === 'TESTING' && animatingState === null} />
              </div>
            </div>
          </header>

          <div className="progress-trail">
            {runData.steps.map((s, i) => {
              const res = runData.results?.[s.id]?.status;
              let cls = '';
              if (res === 'Passed') cls = 'pass';
              else if (res === 'Failed') cls = 'fail';
              else if (i === currentIdx) cls = 'current';
              return <div key={s.id} className={`trail-node ${cls}`} onClick={() => { if (i < currentIdx || res) setCurrentIdx(i); }}></div>
            })}
          </div>

          <main className="stage">
            {currentStep && (
              <div className={`step-card ${animatingState === 'pass' ? 'passing' : animatingState === 'fail' ? 'failing' : ''}`}>
                <div className="step-meta">
                  <span className="step-number">Step {currentIdx + 1 < 10 ? '0'+(currentIdx+1) : currentIdx+1}</span>
                  {currentStep.priority && (
                    <span className={`step-priority ${currentStep.priority.toLowerCase().includes('high') ? 'high' : ''}`}>{currentStep.priority}</span>
                  )}
                </div>
                <h1 className="step-action">{currentStep.action}</h1>
                <div className="step-expected-label">Expected result</div>
                <p className="step-expected">{currentStep.expectedResult}</p>
                
                {(currentStep.mediaUrls?.length || currentStep.referenceLinks?.length) ? (
                  <div className="step-attachments">
                    {currentStep.mediaUrls?.map((url, i) => (
                      <div className={`attachment ${getMediaType(url)}`} key={i} onClick={() => window.open(url, '_blank')}>
                        {getMediaType(url) === 'video' ? <div style={{width:'110px', height:'78px', background: '#333', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>Video</div>
                        : getMediaType(url) === 'pdf' ? <div style={{width:'110px', height:'78px', background: '#e2e8f0', color: '#3b82f6', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold'}}>PDF</div>
                        : <div className="img-bg img-1" style={{backgroundImage: `url(${url})`}}></div>}
                      </div>
                    ))}
                    {currentStep.referenceLinks?.map((url, i) => (
                      <div className="attachment link" key={i} onClick={() => window.open(url, '_blank')}>
                        <div className="link-ico">URL</div>
                        <div className="link-info">
                          <div className="link-title">{url.split('://')[1]?.substring(0,20) || url.substring(0,20)}</div>
                          <div className="link-host">External Link</div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            )}
            {nextStep && (
              <div className="peek-card">
                <div className="peek-step-num">Step {currentIdx + 2 < 10 ? '0'+(currentIdx+2) : currentIdx+2}</div>
                <p className="peek-action">{nextStep.action}</p>
              </div>
            )}
          </main>

          <div className="action-bar" style={{ opacity: failPanelOpen ? 0 : 1, pointerEvents: failPanelOpen ? 'none' : 'auto' }}>
            <div className="action-row">
              <button className="abtn btn-fail" onClick={() => setFailPanelOpen(true)}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                Fail
              </button>
              <button className="abtn btn-pass" onClick={handlePass}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                Pass
              </button>
            </div>
          </div>

          <div className={`overlay ${failPanelOpen ? 'show' : ''}`} onClick={() => setFailPanelOpen(false)}></div>
          <div className={`fail-panel ${failPanelOpen ? 'open' : ''}`}>
            <div className="fail-panel-inner">
              <div className="fail-handle"></div>
              <h2 className="fail-title">What went wrong?</h2>
              <p className="fail-sub">Your feedback helps the team fix it fast. Optional but really appreciated.</p>

              <div className="reason-label">Common reasons</div>
              <div className="reason-chips">
                {['Didn\'t load', 'Looks different', 'Broken/error', 'Slow', 'Unclear', 'Something else'].map(reason => (
                  <button 
                    key={reason} 
                    className={`reason-chip ${failChips.includes(reason) ? 'selected' : ''}`}
                    onClick={() => setFailChips(prev => prev.includes(reason) ? prev.filter(r => r !== reason) : [...prev, reason])}
                  >
                    {reason}
                  </button>
                ))}
              </div>

              <div className="reason-label">Describe it (optional)</div>
              <textarea className="fail-notes" placeholder="What did you expect? What happened instead?" value={failNotes} onChange={e => setFailNotes(e.target.value)}></textarea>

              <div className="fail-attach-row">
                <label className="attach-btn">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                  {isUploadingMedia ? 'Uploading...' : 'Screenshot / Photo'}
                  <input type="file" accept="image/*" hidden onChange={handleDesktopUpload} />
                </label>
                <label className="attach-btn">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
                  {isUploadingMedia ? 'Uploading...' : 'Video'}
                  <input type="file" accept="video/*" hidden onChange={handleDesktopUpload} />
                </label>
                <button className="attach-btn" onClick={openQrScanner}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><line x1="14" y1="14" x2="14" y2="14.01"/><line x1="21" y1="14" x2="21" y2="14.01"/><line x1="14" y1="21" x2="14" y2="21.01"/><line x1="21" y1="21" x2="21" y2="21.01"/></svg>
                  Upload from Phone
                </button>
                {failMediaUrls.length > 0 && <span style={{fontSize: '12px', color: 'var(--accent)'}}>{failMediaUrls.length} file(s) attached</span>}
              </div>

              <div className="fail-actions">
                <button className="btn-cancel" onClick={() => setFailPanelOpen(false)}>Cancel</button>
                <button className="btn-submit" onClick={handleFailSubmit}>Submit &amp; continue</button>
              </div>
            </div>
          </div>

          <div className={`pass-flash ${showPassFlash ? 'show' : ''}`}>
            <div className="pass-flash-content">
              <div className="pass-tick"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg></div>
              <div className="pass-text">{passFlashMsg}</div>
            </div>
          </div>
          
          <div className={`qr-full ${qrModalOpen ? 'show' : ''}`} onClick={(e) => { if(e.target === e.currentTarget) setQrModalOpen(false); }}>
            <div className="qr-full-card">
              <div className="qr-full-eyebrow">Step {currentIdx + 1 < 10 ? '0'+(currentIdx+1) : currentIdx+1} · Evidence Upload</div>
              <h3 className="qr-full-title">Scan to upload from phone</h3>
              <div className="qr-full-img" style={{display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                {uploadUrl ? <QRCodeSVG value={uploadUrl} size={220} /> : <div className="qr-full-pattern"></div>}
                <div className="qr-corner tl"></div><div className="qr-corner tr"></div><div className="qr-corner bl"></div>
              </div>
              <div className="qr-instructions">
                <div className="qr-step-item"><div className="qr-step-num">1</div><div>Open your phone's camera and point it at the code</div></div>
                <div className="qr-step-item"><div className="qr-step-num">2</div><div>Tap the notification to open the upload page</div></div>
                <div className="qr-step-item"><div className="qr-step-num">3</div><div>Take photos or videos — they attach here automatically</div></div>
              </div>
              <div className="qr-waiting">Waiting for device...</div>
              <button className="qr-close-btn" onClick={() => setQrModalOpen(false)}>Cancel</button>
            </div>
          </div>
        </>
      )}

      {stage === 'COMPLETE' && (
        <>
          <div className="wrap">
            <div className="top-chip">
              <span className="check-dot">
                <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              </span>
              Test run complete
            </div>

            <div className="medal-wrap">
              <div className="medal">
                <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
            </div>

            <div className="hero">
              <h1 className="hero-title">Thank you, <em>{(runData.testerName || 'Tester').split(' ')[0]}</em>.</h1>
              <p className="hero-sub">You've tested <b>{runData.projectName}</b> end to end. Your results are on their way to the PM right now.</p>
            </div>

            <div className="big-stats">
              <div className="big-stat">
                <div className="bs-value"><em>{totalStepsCount}</em></div>
                <div className="bs-label">Steps tested</div>
              </div>
              <div className="stat-divider"></div>
              <div className="big-stat">
                <div className="bs-value">{finalMin}:{finalSec}</div>
                <div className="bs-label">Time taken</div>
              </div>
            </div>

            <div className="percentile">
              <div className="pct-badge">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="13 2 13 13 21 13"/><path d="M13 2A10 10 0 103 12"/></svg>
              </div>
              <div className="pct-text">
                <h3 className="pct-headline">Faster than <em>{pct}%</em> of testers</h3>
                <p className="pct-sub">On projects this size · {runData.testCycle || 'UAT'} cycles</p>
              </div>
            </div>

            <div className="results">
              <div className="results-label">Your results</div>
              <div className="results-bar">
                <div className="seg pass" style={{flex: passPct}}></div>
                <div className="seg fail" style={{flex: failPct}}></div>
              </div>
              <div className="results-legend">
                <span className="legend-item"><span className="legend-dot pass"></span> {passedCount} passed</span>
                {failedCount > 0 && <span className="legend-item"><span className="legend-dot fail"></span> {failedCount} needs attention</span>}
              </div>
            </div>

            <div className="c-actions">
              <button className="c-btn c-btn-primary" onClick={() => setStage('RESULTS')}>
                View my results
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </button>
              <button className="c-btn c-btn-secondary" onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                alert("Link copied!");
              }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-1 1"/><path d="M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l1-1"/></svg>
                Copy a link to this run
              </button>
            </div>

            <div className="thank-you">
              Built with <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg> for testers by QA Triage
            </div>
          </div>
          
          <div className="confetti-layer" id="confetti-root" ref={confettiContainerRef}></div>
        </>
      )}

      {stage === 'RESULTS' && (
        <div style={{ paddingBottom: '80px', position: 'relative', zIndex: 2 }}>
          <div className="results-hero">
            <h1 className="results-hero-title">Test <em>Report</em></h1>
            <div className="results-hero-sub">{runData.projectName} · {runData.testCycle || 'UAT'}</div>
          </div>

          <div className="timeline">
            {runData.steps.map((step, index) => {
              const res = runData.results?.[step.id];
              const isPass = res?.status === 'Passed';
              const isFail = res?.status === 'Failed';
              
              return (
                <div 
                  key={step.id} 
                  className={`timeline-card ${isPass ? 't-pass' : isFail ? 't-fail' : ''}`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="timeline-meta">
                    <span className="t-step-num">Step {index + 1 < 10 ? '0'+(index+1) : index+1}</span>
                    {isPass && <span className="t-status pass"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg> Passed</span>}
                    {isFail && <span className="t-status fail"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Failed</span>}
                  </div>
                  
                  <h3 className="timeline-action">{step.action}</h3>
                  <p className="timeline-expected">{step.expectedResult}</p>
                  
                  {isFail && (res.notes || (res.evidenceUrls && res.evidenceUrls.length > 0)) && (
                    <div className="timeline-notes">
                      {res.notes && (
                        <>
                          <div className="t-notes-label">Tester Notes</div>
                          <div className="t-notes-text">{res.notes}</div>
                        </>
                      )}
                      
                      {res.evidenceUrls && res.evidenceUrls.length > 0 && (
                        <div className="t-evidence-row">
                          {res.evidenceUrls.map((url, i) => (
                            <div key={i} onClick={() => window.open(url, '_blank')}>
                              {getMediaType(url) === 'video' ? (
                                <div className="t-evidence-vid"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></div>
                              ) : (
                                <div className="t-evidence-item" style={{ backgroundImage: `url(${url})` }}></div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <button className="c-btn c-btn-secondary" style={{ display: 'inline-flex', margin: '0 auto' }} onClick={() => setStage('COMPLETE')}>
              ← Back to summary
            </button>
          </div>
        </div>
      )}

    </div>
  );
}